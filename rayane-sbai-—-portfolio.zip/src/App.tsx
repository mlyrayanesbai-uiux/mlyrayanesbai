import React from 'react';
import { PortfolioProvider, usePortfolio } from './context/PortfolioContext';
import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { CVModal } from './components/CVModal';
import { ChecklistModal } from './components/ChecklistModal';
import { HomePage } from './pages/HomePage';
import { ProjectsPage } from './pages/ProjectsPage';
import { CaseStudyPage } from './pages/CaseStudyPage';
import { AboutPage } from './pages/AboutPage';
import { ContactPage } from './pages/ContactPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { PageTransition } from './components/PageTransition';

const PortfolioContent: React.FC = () => {
  const { currentPage, currentSlug, locale } = usePortfolio();

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage />;
      case 'projects':
        return <ProjectsPage />;
      case 'case-study':
        return <CaseStudyPage slug={currentSlug || 'startup-hub-maroc'} />;
      case 'about':
        return <AboutPage />;
      case 'contact':
        return <ContactPage />;
      default:
        return <NotFoundPage />;
    }
  };

  return (
    <div className="relative min-h-screen flex flex-col bg-[#FBFBF9] text-[#18181B] dark:bg-[#09090B] dark:text-[#F4F4F5] transition-colors duration-200">
      
      {/* Background Gradient & Grid Backdrop Layers */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        {/* Ambient Gradient Flares */}
        <div className="absolute inset-0 bg-radial-ambient-light dark:bg-radial-ambient-dark opacity-100 transition-opacity duration-300" />
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] sm:w-[1200px] h-[650px] bg-gradient-to-b from-blue-500/15 via-indigo-500/8 to-transparent blur-3xl dark:from-blue-600/25 dark:via-blue-950/15 dark:to-transparent" />
        <div className="absolute top-1/3 -right-20 w-[450px] h-[450px] bg-gradient-to-br from-amber-400/10 via-blue-500/6 to-transparent blur-3xl dark:from-indigo-600/15 dark:to-transparent" />
        <div className="absolute bottom-1/4 -left-20 w-[400px] h-[400px] bg-gradient-to-tr from-sky-400/8 via-emerald-500/5 to-transparent blur-3xl dark:from-blue-900/15 dark:to-transparent" />
        
        {/* Crisp Hairline Grid Pattern */}
        <div className="absolute inset-0 bg-grid-editorial opacity-100" />
      </div>

      <div className="relative z-10 flex min-h-screen flex-col">
        <Header />
        <main className="flex-1 w-full max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
          <PageTransition transitionKey={`${currentPage}-${currentSlug || ''}-${locale}`}>
            {renderCurrentPage()}
          </PageTransition>
        </main>
        <Footer />
        <CVModal />
        <ChecklistModal />
      </div>
    </div>
  );
};

export default function App() {
  return (
    <PortfolioProvider>
      <PortfolioContent />
    </PortfolioProvider>
  );
}
