import React from 'react';
import { X, Printer, Download, MapPin, Mail, ExternalLink, GraduationCap, Briefcase, Award } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { siteTranslations, verifiedExperiences, verifiedLanguages } from '../data/translations';

export const CVModal: React.FC = () => {
  const { isCvModalOpen, closeCvModal, locale } = usePortfolio();
  const t = siteTranslations.cvModal;

  if (!isCvModalOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleDownloadText = () => {
    const cvContent = `RAYANE SBAI — UI/UX DESIGNER & FRONTEND DEVELOPER
Email: rayanesbai667@gmail.com
Location: Rabat, Morocco (Ready to relocate to Germany)
Focus: Junior Position / Dual Ausbildung (Mediengestalter / Fachinformatiker)

PROFESSIONAL SUMMARY:
UI/UX Designer and Frontend Developer combining user research, wireframing, and design systems with modern frontend implementation (React, Tailwind CSS, TypeScript). Focused on practical, accessible, and user-friendly digital products.

EDUCATION:
Technicien Spécialisé en UX Design (2022 - 2024)
ISTA NTIC Rabat, Morocco
- State technical diploma covering user research, usability audits, wireframing, and Figma prototyping.

PRACTICAL EXPERIENCE & PROJECTS:
1. Startup Hub Maroc — ADD (2023 - 2024)
   - UX Audit, Information Architecture, and interactive Figma prototyping for the national startup ecosystem directory.
2. Deutsch Maak — Collaborative Project (2024)
   - Interactive educational web platform for German language learners. Led UI/UX and responsive frontend component implementation.
3. FOS-MATNUHPV Portal Redesign (2023 - 2024)
   - Public sector social services portal modernization with WCAG AA accessibility standards.
4. RH Manager Dashboard (2024)
   - Enterprise data table and employee management system with optimized workflow states.

LANGUAGES:
- Arabic: Native
- French: Fluent / C1
- English: Professional Working Proficiency / B2-C1
- German: B1 in active preparation (Targeting Goethe/Telc certification)

TECHNICAL SKILLS:
- UX/UI: Figma, User Flows, Wireframing, Design Tokens, WCAG AA Accessibility
- Frontend: HTML5, CSS3, Tailwind CSS, JavaScript (ES6+), TypeScript, React, Git
- No-Code / CMS: WordPress, Elementor, Framer
`;
    const blob = new Blob([cvContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Rayane_Sbai_CV_${locale.toUpperCase()}.txt`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="cv-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-stone-900/60 backdrop-blur-xs overflow-y-auto"
    >
      <div className="relative my-auto w-full max-w-3xl rounded-2xl bg-white shadow-2xl border border-stone-200 dark:border-zinc-800 dark:bg-zinc-900 overflow-hidden">
        
        {/* Modal Toolbar (hidden when printing) */}
        <div className="flex items-center justify-between border-b border-stone-200 bg-stone-50/90 px-6 py-3.5 print:hidden dark:border-zinc-800 dark:bg-zinc-800/50">
          <div>
            <h3 id="cv-modal-title" className="text-sm font-bold text-stone-900 dark:text-zinc-100">
              {t.title[locale]}
            </h3>
            <p className="text-xs text-stone-500 dark:text-zinc-400">
              {t.subtitle[locale]}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 rounded-lg border border-stone-300 bg-white px-3 py-1.5 text-xs font-semibold text-stone-700 hover:bg-stone-50 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-200 cursor-pointer"
            >
              <Printer className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">{t.print[locale]}</span>
            </button>

            <button
              type="button"
              onClick={handleDownloadText}
              className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer"
            >
              <Download className="h-3.5 w-3.5" />
              <span>{t.downloadPdf[locale]}</span>
            </button>

            <button
              type="button"
              onClick={closeCvModal}
              aria-label="Close CV preview"
              className="rounded-lg p-1.5 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:text-zinc-500 dark:hover:bg-zinc-800 dark:hover:text-zinc-200 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Printable CV Content */}
        <div className="max-h-[80vh] overflow-y-auto p-6 sm:p-10 text-stone-800 dark:text-zinc-200">
          
          {/* Header */}
          <div className="border-b border-stone-200 pb-6 dark:border-zinc-800">
            <h1 className="text-2xl font-bold tracking-tight text-stone-900 dark:text-white">
              Rayane Sbai
            </h1>
            <p className="text-sm font-semibold text-blue-600 dark:text-blue-400 mt-0.5">
              UI/UX Designer & Frontend Developer
            </p>

            <div className="mt-3 flex flex-wrap items-center gap-y-1.5 gap-x-4 text-xs text-stone-600 dark:text-zinc-400">
              <span className="flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5 text-stone-400" />
                <span>Rabat, Marokko · Bereit für Umzug nach Deutschland</span>
              </span>
              <span className="flex items-center gap-1">
                <Mail className="h-3.5 w-3.5 text-stone-400" />
                <span>rayanesbai667@gmail.com</span>
              </span>
            </div>

            <div className="mt-3 rounded-lg bg-blue-50/70 p-3 text-xs text-blue-900 dark:bg-blue-950/30 dark:text-blue-300">
              <span className="font-semibold">Bewerbungsfokus: </span>
              <span>Offen für Einstiegsposition (Junior UI/UX / Frontend) oder duale Ausbildung (z.B. Mediengestalter Digital & Print / Fachinformatiker) in Deutschland.</span>
            </div>
          </div>

          {/* Education */}
          <div className="mt-6">
            <h2 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-stone-900 dark:text-zinc-100">
              <GraduationCap className="h-4 w-4 text-blue-600" />
              <span>{locale === 'de' ? 'Berufliche Ausbildung' : locale === 'fr' ? 'Formation Professionnelle' : 'Education'}</span>
            </h2>
            <div className="mt-3 border-l-2 border-stone-200 pl-4 space-y-2 dark:border-zinc-700">
              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-stone-900 dark:text-zinc-100">
                    Diplôme de Technicien Spécialisé en UX Design
                  </span>
                  <span className="text-stone-500 font-mono">2022 — 2024</span>
                </div>
                <div className="text-xs text-stone-600 dark:text-zinc-400">
                  ISTA NTIC Rabat, Marokko
                </div>
                <p className="mt-1 text-xs text-stone-600 dark:text-zinc-400">
                  Zweijährige Ausbildung mit Schwerpunkt auf User Research, Informationsarchitektur, Wireframing, interaktivem Figma-Prototyping und Frontend-Grundlagen.
                </p>
              </div>
            </div>
          </div>

          {/* Experience & Practical Projects */}
          <div className="mt-6">
            <h2 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-stone-900 dark:text-zinc-100">
              <Briefcase className="h-4 w-4 text-blue-600" />
              <span>{locale === 'de' ? 'Praktische Projekterfahrung' : locale === 'fr' ? 'Expériences & Projets' : 'Practical Experience'}</span>
            </h2>
            <div className="mt-3 space-y-4">
              {verifiedExperiences.map((exp, idx) => (
                <div key={idx} className="border-l-2 border-stone-200 pl-4 dark:border-zinc-700">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-stone-900 dark:text-zinc-100">
                      {exp.role[locale]}
                    </span>
                    <span className="text-stone-500 font-mono">{exp.period}</span>
                  </div>
                  <div className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                    {exp.organization} · {exp.location}
                  </div>
                  <p className="mt-1 text-xs text-stone-600 dark:text-zinc-400">
                    {exp.description[locale]}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Skills Grid */}
          <div className="mt-6 pt-6 border-t border-stone-200 dark:border-zinc-800">
            <h2 className="flex items-center gap-2 text-sm font-bold uppercase tracking-wider text-stone-900 dark:text-zinc-100">
              <Award className="h-4 w-4 text-blue-600" />
              <span>{locale === 'de' ? 'Kompetenzen & Technologien' : 'Skills & Tools'}</span>
            </h2>
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div className="rounded-lg border border-stone-200 p-3 dark:border-zinc-800 bg-stone-50/50 dark:bg-zinc-800/30">
                <span className="font-bold text-stone-900 dark:text-zinc-100 block mb-1">UX/UI Design:</span>
                <p className="text-stone-600 dark:text-zinc-400">
                  Figma, Auto Layout, Wireframing, UX Audits, Design Tokens, WCAG AA Barrierefreiheit, Informationsarchitektur.
                </p>
              </div>
              <div className="rounded-lg border border-stone-200 p-3 dark:border-zinc-800 bg-stone-50/50 dark:bg-zinc-800/30">
                <span className="font-bold text-stone-900 dark:text-zinc-100 block mb-1">Frontend & No-Code:</span>
                <p className="text-stone-600 dark:text-zinc-400">
                  HTML5, CSS3, Tailwind CSS, JavaScript (ES6+), TypeScript, React, Git, WordPress, Elementor, Framer.
                </p>
              </div>
            </div>
          </div>

          {/* Languages */}
          <div className="mt-6 pt-6 border-t border-stone-200 dark:border-zinc-800">
            <h2 className="text-sm font-bold uppercase tracking-wider text-stone-900 dark:text-zinc-100 mb-3">
              {locale === 'de' ? 'Sprachen' : locale === 'fr' ? 'Langues' : 'Languages'}
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              {verifiedLanguages.map((lang, idx) => (
                <div key={idx} className="rounded-md border border-stone-200 p-2.5 dark:border-zinc-800">
                  <div className="font-semibold text-stone-900 dark:text-zinc-100">{lang.name[locale]}</div>
                  <div className="text-[11px] text-stone-500 dark:text-zinc-400 mt-0.5">{lang.level[locale]}</div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
