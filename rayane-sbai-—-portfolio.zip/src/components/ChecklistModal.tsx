import React from 'react';
import { X, CheckCircle2, Clock, AlertTriangle, FileCode, Check } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { siteTranslations } from '../data/translations';

export const ChecklistModal: React.FC = () => {
  const { isChecklistOpen, closeChecklist, locale } = usePortfolio();
  const t = siteTranslations.checklist;

  if (!isChecklistOpen) return null;

  const verifiedItems = [
    {
      title: locale === 'de' ? 'Berufsbezeichnung & Positionierung' : 'Professional Title & Positioning',
      desc: locale === 'de' ? '„Rayane Sbai — UI/UX Designer & Frontend Developer“ (Authentische duale Ausrichtung auf Einstieg und Ausbildung in Deutschland).' : 'Accurate title reflecting design thinking and frontend execution.'
    },
    {
      title: locale === 'de' ? 'Staatliches Fachdiplom (ISTA NTIC)' : 'Specialist Diploma (ISTA NTIC Rabat)',
      desc: locale === 'de' ? 'Zweijährige Ausbildung zum Technicien Spécialisé en UX Design verifiziert.' : 'Official 2-year diploma in UX Design confirmed.'
    },
    {
      title: locale === 'de' ? 'Praxisprojekte (ADD, Deutsch Maak, FOS)' : 'Practical Projects (ADD, Deutsch Maak, FOS)',
      desc: locale === 'de' ? 'Projektschwerpunkte klar nach persönlichem Beitrag, Teamkontext und Reifegrad (Prototyp vs. Implementierung) gegliedert.' : 'Clearly separated personal contributions from team initiatives.'
    },
    {
      title: locale === 'de' ? 'Verifizierte Kontakt-E-Mail' : 'Verified Contact Email',
      desc: 'rayanesbai667@gmail.com — direkt mit Ein-Klick-Kopierfunktion und Mail-Link verknüpft.'
    },
    {
      title: locale === 'de' ? 'Keine erfundenen Metriken oder Fake-Kunden' : 'Zero Fake Metrics or Testimonials',
      desc: locale === 'de' ? 'Keine künstlichen Zahlen wie „+300% Conversion“ oder gefälschte Zitate — nur reale Beobachtungen und Arbeitsergebnisse.' : 'No inflated claims or simulated social proof.'
    }
  ];

  const pendingItems = [
    {
      title: locale === 'de' ? 'Offizielles Porträt-Foto' : 'Authentic Studio Portrait',
      desc: locale === 'de' ? 'Aktuell ist ein neutrales KI-Studio-Porträt als Platzhalter eingebunden. Vor Live-Deployment durch Rayanes eigenes hochauflösendes Foto ersetzen.' : 'Currently using studio photography preview. Replace with Rayane’s personal portrait file.',
      action: '/src/assets/images/rayane_portrait_*.jpg'
    },
    {
      title: locale === 'de' ? 'Reale Projekt-Screenshots / Screencasts' : 'Original Project Screenshots & Figma Links',
      desc: locale === 'de' ? 'Eigene Original-Screenshots aus Figma oder dem Code-Editor hinterlegen.' : 'Attach exact Figma URLs and production build screencasts.',
      action: 'src/data/projectsData.ts'
    },
    {
      title: locale === 'de' ? 'Goethe / Telc Sprachzertifikat (Deutsch B1/B2)' : 'Official German Language Certificate',
      desc: locale === 'de' ? 'Sobald die B1/B2-Prüfung abgelegt ist, Datum und Zertifikat ergänzen.' : 'Update with official Goethe-Zertifikat completion date.',
      action: 'src/data/translations.ts -> verifiedLanguages'
    },
    {
      title: locale === 'de' ? 'Original-PDFs für den Lebenslauf' : 'Signed PDF Resumes (DE / EN / FR)',
      desc: locale === 'de' ? 'Eigene PDF-Dateien für den Lebenslauf im /public Ordner ablegen (z.B. Lebenslauf_Rayane_Sbai_DE.pdf).' : 'Upload signed locale-specific PDF files to /public.',
      action: '/public/cv/'
    },
    {
      title: locale === 'de' ? 'GitHub & LinkedIn Profile URLs' : 'GitHub & LinkedIn Links',
      desc: locale === 'de' ? 'Sobald die öffentlichen Profil-Links vorliegen, in src/data/translations.ts hinterlegen.' : 'Add URLs once public repositories and profiles are confirmed.',
      action: 'src/data/translations.ts'
    }
  ];

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="checklist-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-stone-900/60 backdrop-blur-xs overflow-y-auto"
    >
      <div className="relative my-auto w-full max-w-2xl rounded-2xl bg-white shadow-2xl border border-stone-200 dark:border-zinc-800 dark:bg-zinc-900 overflow-hidden">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-200 bg-stone-50/80 px-6 py-4 dark:border-zinc-800 dark:bg-zinc-800/40">
          <div>
            <h3 id="checklist-title" className="text-base font-bold text-stone-900 dark:text-zinc-100">
              {t.title[locale]}
            </h3>
            <p className="text-xs text-stone-500 dark:text-zinc-400">
              {t.subtitle[locale]}
            </p>
          </div>
          <button
            type="button"
            onClick={closeChecklist}
            aria-label="Close dialog"
            className="rounded-lg p-1.5 text-stone-400 hover:bg-stone-200 hover:text-stone-700 dark:text-zinc-500 dark:hover:bg-zinc-800 dark:hover:text-zinc-200 cursor-pointer"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Content list */}
        <div className="max-h-[75vh] overflow-y-auto p-6 space-y-6">
          
          {/* Verified section */}
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 mb-3">
              <CheckCircle2 className="h-4 w-4" />
              <span>{t.verifiedTitle[locale]}</span>
            </div>
            <div className="space-y-2.5">
              {verifiedItems.map((item, idx) => (
                <div
                  key={idx}
                  className="rounded-xl border border-stone-200 bg-stone-50/50 p-3.5 dark:border-zinc-800 dark:bg-zinc-900/40"
                >
                  <div className="text-xs font-semibold text-stone-900 dark:text-zinc-100 flex items-center gap-1.5">
                    <Check className="h-3.5 w-3.5 text-emerald-600" />
                    <span>{item.title}</span>
                  </div>
                  <p className="mt-1 text-xs text-stone-600 dark:text-zinc-400 pl-5">
                    {item.desc}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Pending checklist for Rayane */}
          <div>
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 mb-3">
              <Clock className="h-4 w-4" />
              <span>{t.missingTitle[locale]}</span>
            </div>
            <div className="space-y-3">
              {pendingItems.map((item, idx) => (
                <div
                  key={idx}
                  className="rounded-xl border border-amber-200 bg-amber-50/40 p-3.5 dark:border-amber-900/40 dark:bg-amber-950/20"
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="text-xs font-semibold text-amber-950 dark:text-amber-200">
                      {item.title}
                    </span>
                    <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-mono text-amber-800 dark:bg-amber-900/50 dark:text-amber-300 shrink-0">
                      Pending
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-amber-900/80 dark:text-amber-300/80">
                    {item.desc}
                  </p>
                  <div className="mt-2 flex items-center gap-1 text-[11px] text-stone-500 font-mono dark:text-zinc-400">
                    <FileCode className="h-3 w-3" />
                    <span>Datei: {item.action}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="border-t border-stone-200 bg-stone-50 px-6 py-3 text-right dark:border-zinc-800 dark:bg-zinc-800/40">
          <button
            type="button"
            onClick={closeChecklist}
            className="rounded-lg bg-stone-900 px-4 py-2 text-xs font-semibold text-white hover:bg-stone-800 dark:bg-zinc-100 dark:text-zinc-900 cursor-pointer"
          >
            {siteTranslations.cvModal.close[locale]}
          </button>
        </div>

      </div>
    </div>
  );
};
