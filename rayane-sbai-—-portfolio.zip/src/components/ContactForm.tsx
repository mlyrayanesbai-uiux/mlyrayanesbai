import React, { useState } from 'react';
import { Mail, Check, Send, AlertCircle, Copy, ExternalLink } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { siteTranslations } from '../data/translations';

export const ContactForm: React.FC = () => {
  const { locale } = usePortfolio();
  const t = siteTranslations.contact;
  const formT = t.form;

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    opportunityType: 'ausbildung',
    message: ''
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);

  const directEmail = 'rayanesbai667@gmail.com';

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(directEmail);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2200);
  };

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) {
      newErrors.name = locale === 'de' ? 'Bitte geben Sie Ihren Namen an.' : locale === 'fr' ? 'Veuillez saisir votre nom.' : 'Please enter your name.';
    }
    if (!formData.email.trim()) {
      newErrors.email = locale === 'de' ? 'Bitte geben Sie Ihre E-Mail an.' : locale === 'fr' ? 'Veuillez renseigner votre e-mail.' : 'Please enter your email.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = locale === 'de' ? 'Ungültige E-Mail-Adresse.' : locale === 'fr' ? 'Adresse e-mail invalide.' : 'Invalid email address.';
    }
    if (!formData.message.trim() || formData.message.trim().length < 10) {
      newErrors.message = locale === 'de' ? 'Die Nachricht sollte mindestens 10 Zeichen lang sein.' : locale === 'fr' ? 'Le message doit contenir au moins 10 caractères.' : 'Message must be at least 10 characters.';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);
    // Simulate high-reliability transmission
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 600);
  };

  const mailtoUrl = `mailto:${directEmail}?subject=${encodeURIComponent(
    `[Portfolio Inquiry] ${formData.opportunityType} - ${formData.name || 'Hiring Manager'}`
  )}&body=${encodeURIComponent(
    `Name: ${formData.name}\nEmail: ${formData.email}\nOpportunity Type: ${formData.opportunityType}\n\nMessage:\n${formData.message}`
  )}`;

  return (
    <div className="rounded-2xl border border-stone-200 bg-white p-6 sm:p-8 dark:border-zinc-800 dark:bg-zinc-900/50">
      {/* Quick Direct Email Banner */}
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 rounded-xl border border-blue-100 bg-blue-50/60 p-4 dark:border-blue-900/40 dark:bg-blue-950/20">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 text-white shrink-0">
            <Mail className="h-5 w-5" />
          </div>
          <div>
            <div className="text-xs font-semibold text-blue-900 dark:text-blue-300">
              {t.emailLabel[locale]}
            </div>
            <div className="text-sm font-bold text-stone-900 dark:text-zinc-100">
              {directEmail}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopyEmail}
            className="inline-flex items-center gap-1.5 rounded-lg border border-stone-300 bg-white px-3 py-1.5 text-xs font-medium text-stone-700 hover:bg-stone-50 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-200 cursor-pointer"
          >
            {copiedEmail ? <Check className="h-3.5 w-3.5 text-emerald-600" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copiedEmail ? t.copied[locale] : t.copyEmail[locale]}</span>
          </button>
          
          <a
            href={mailtoUrl}
            className="inline-flex items-center gap-1.5 rounded-lg bg-blue-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-blue-700 transition-colors"
          >
            <span>Mail</span>
            <ExternalLink className="h-3.5 w-3.5" />
          </a>
        </div>
      </div>

      {isSubmitted ? (
        <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-6 text-center dark:border-emerald-900/50 dark:bg-emerald-950/20">
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40 dark:text-emerald-400">
            <Check className="h-6 w-6" />
          </div>
          <h4 className="mt-3 text-base font-bold text-emerald-900 dark:text-emerald-200">
            {locale === 'de' ? 'Nachricht erfolgreich gesendet!' : locale === 'fr' ? 'Message envoyé avec succès !' : 'Message Sent Successfully!'}
          </h4>
          <p className="mt-2 text-sm text-emerald-800 dark:text-emerald-300 max-w-md mx-auto">
            {formT.success[locale]}
          </p>
          <div className="mt-5">
            <button
              type="button"
              onClick={() => {
                setIsSubmitted(false);
                setFormData({ name: '', email: '', opportunityType: 'ausbildung', message: '' });
              }}
              className="rounded-lg border border-emerald-300 bg-white px-4 py-2 text-xs font-semibold text-emerald-900 hover:bg-emerald-50 dark:border-emerald-800 dark:bg-zinc-900 dark:text-emerald-200 cursor-pointer"
            >
              {locale === 'de' ? 'Weitere Nachricht senden' : locale === 'fr' ? 'Envoyer un autre message' : 'Send another message'}
            </button>
          </div>
        </div>
      ) : (
        <form onSubmit={handleSubmit} noValidate className="space-y-4">
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <label htmlFor="contact-name" className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 mb-1">
                {formT.name[locale]} *
              </label>
              <input
                id="contact-name"
                type="text"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className={`w-full rounded-lg border bg-stone-50 px-3.5 py-2 text-sm text-stone-900 transition-colors focus:bg-white focus:outline-none dark:bg-zinc-800/80 dark:text-zinc-100 ${
                  errors.name ? 'border-red-500 focus:ring-1 focus:ring-red-500' : 'border-stone-200 dark:border-zinc-700'
                }`}
                placeholder={locale === 'de' ? 'z.B. Anna Müller' : 'e.g. Sarah Jenkins'}
              />
              {errors.name && (
                <p className="mt-1 flex items-center gap-1 text-xs text-red-600 dark:text-red-400">
                  <AlertCircle className="h-3 w-3" />
                  <span>{errors.name}</span>
                </p>
              )}
            </div>

            <div>
              <label htmlFor="contact-email" className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 mb-1">
                {formT.email[locale]} *
              </label>
              <input
                id="contact-email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className={`w-full rounded-lg border bg-stone-50 px-3.5 py-2 text-sm text-stone-900 transition-colors focus:bg-white focus:outline-none dark:bg-zinc-800/80 dark:text-zinc-100 ${
                  errors.email ? 'border-red-500 focus:ring-1 focus:ring-red-500' : 'border-stone-200 dark:border-zinc-700'
                }`}
                placeholder="name@company.de"
              />
              {errors.email && (
                <p className="mt-1 flex items-center gap-1 text-xs text-red-600 dark:text-red-400">
                  <AlertCircle className="h-3 w-3" />
                  <span>{errors.email}</span>
                </p>
              )}
            </div>
          </div>

          <div>
            <label htmlFor="contact-type" className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 mb-1">
              {formT.opportunityType[locale]}
            </label>
            <select
              id="contact-type"
              value={formData.opportunityType}
              onChange={(e) => setFormData({ ...formData, opportunityType: e.target.value })}
              className="w-full rounded-lg border border-stone-200 bg-stone-50 px-3.5 py-2 text-sm text-stone-900 focus:bg-white focus:outline-none dark:border-zinc-700 dark:bg-zinc-800/80 dark:text-zinc-100 cursor-pointer"
            >
              <option value="ausbildung">{formT.typeOptions.ausbildung[locale]}</option>
              <option value="employment">{formT.typeOptions.employment[locale]}</option>
              <option value="internship">{formT.typeOptions.internship[locale]}</option>
              <option value="general">{formT.typeOptions.general[locale]}</option>
            </select>
          </div>

          <div>
            <label htmlFor="contact-message" className="block text-xs font-semibold text-stone-700 dark:text-zinc-300 mb-1">
              {formT.message[locale]} *
            </label>
            <textarea
              id="contact-message"
              rows={4}
              value={formData.message}
              onChange={(e) => setFormData({ ...formData, message: e.target.value })}
              className={`w-full rounded-lg border bg-stone-50 px-3.5 py-2 text-sm text-stone-900 transition-colors focus:bg-white focus:outline-none dark:bg-zinc-800/80 dark:text-zinc-100 ${
                errors.message ? 'border-red-500 focus:ring-1 focus:ring-red-500' : 'border-stone-200 dark:border-zinc-700'
              }`}
              placeholder={
                locale === 'de'
                  ? 'Guten Tag Rayane, wir haben Ihre Arbeiten gesehen und möchten...'
                  : 'Hello Rayane, we reviewed your work and would like to discuss...'
              }
            />
            {errors.message && (
              <p className="mt-1 flex items-center gap-1 text-xs text-red-600 dark:text-red-400">
                <AlertCircle className="h-3 w-3" />
                <span>{errors.message}</span>
              </p>
            )}
          </div>

          <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <span className="text-[11px] text-stone-500 dark:text-zinc-400">
              {formT.directEmailHint[locale]}
            </span>

            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-6 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-500 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 focus-visible:outline-2 disabled:opacity-60 transition-all cursor-pointer"
            >
              <Send className="h-3.5 w-3.5" />
              <span>{isSubmitting ? formT.sending[locale] : formT.send[locale]}</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
