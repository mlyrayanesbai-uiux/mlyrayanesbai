import React, { useState } from 'react';
import { Mail, Check, ShieldCheck, FileText, ArrowUp } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { siteTranslations } from '../data/translations';
import { LanguageSwitcher } from './LanguageSwitcher';
import { PageType } from '../types/portfolio';

export const Footer: React.FC = () => {
  const { locale, navigateTo, openChecklist, openCvModal } = usePortfolio();
  const [copied, setCopied] = useState(false);
  const t = siteTranslations.footer;
  const nav = siteTranslations.nav;
  const email = 'rayanesbai667@gmail.com';

  const copyEmail = () => {
    navigator.clipboard.writeText(email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="mt-20 border-t border-stone-200 bg-[#F5F5F0] transition-colors dark:border-zinc-800/80 dark:bg-[#0C0C0E]">
      <div className="mx-auto max-w-6xl px-4 py-12 sm:px-6 lg:px-8">
        
        {/* Top footer row: Professional Title, Location, and Email */}
        <div className="grid grid-cols-1 gap-8 md:grid-cols-12 pb-10 border-b border-stone-200/80 dark:border-zinc-800/80">
          <div className="md:col-span-6 space-y-3">
            <h3 className="text-base font-bold text-stone-900 dark:text-zinc-100">
              {t.tagline[locale]}
            </h3>
            <p className="text-sm text-stone-600 dark:text-zinc-400 max-w-md">
              {siteTranslations.sections.opportunity.locationLabel[locale]}
            </p>
            <div className="pt-2 flex items-center gap-3">
              <button
                type="button"
                onClick={copyEmail}
                className="inline-flex items-center gap-2 rounded-lg border border-stone-300 bg-white px-3.5 py-1.5 text-xs font-medium text-stone-800 shadow-xs hover:border-stone-400 hover:bg-stone-50 hover:shadow-sm hover:-translate-y-0.5 transition-all dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-200 dark:hover:border-zinc-600 cursor-pointer"
              >
                {copied ? <Check className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" /> : <Mail className="h-3.5 w-3.5 text-stone-500" />}
                <span>{email}</span>
                <span className="text-[10px] text-stone-600 dark:text-zinc-400">
                  {copied ? siteTranslations.contact.copied[locale] : siteTranslations.contact.copyEmail[locale]}
                </span>
              </button>
            </div>
          </div>

          {/* Quick Navigation links */}
          <div className="md:col-span-3 space-y-2 text-xs">
            <div className="font-semibold text-stone-900 dark:text-zinc-200 mb-2">
              Navigation
            </div>
            <ul className="space-y-1.5 text-stone-600 dark:text-zinc-400">
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('home')}
                  className="hover:text-stone-900 dark:hover:text-zinc-100 cursor-pointer"
                >
                  {nav.home[locale]}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('projects')}
                  className="hover:text-stone-900 dark:hover:text-zinc-100 cursor-pointer"
                >
                  {nav.projects[locale]}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('about')}
                  className="hover:text-stone-900 dark:hover:text-zinc-100 cursor-pointer"
                >
                  {nav.about[locale]}
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => navigateTo('contact')}
                  className="hover:text-stone-900 dark:hover:text-zinc-100 cursor-pointer"
                >
                  {nav.contact[locale]}
                </button>
              </li>
            </ul>
          </div>

          {/* Actions: CV & Content Checklist */}
          <div className="md:col-span-3 space-y-2 text-xs">
            <div className="font-semibold text-stone-900 dark:text-zinc-200 mb-2">
              {siteTranslations.checklist.triggerButton[locale]}
            </div>
            <div className="flex flex-col gap-2">
              <button
                type="button"
                onClick={openCvModal}
                className="inline-flex items-center gap-1.5 text-stone-600 hover:text-stone-900 dark:text-zinc-400 dark:hover:text-zinc-100 cursor-pointer"
              >
                <FileText className="h-3.5 w-3.5" />
                <span>{siteTranslations.cvModal.title[locale]}</span>
              </button>
              <button
                type="button"
                onClick={openChecklist}
                className="inline-flex items-center gap-1.5 text-stone-600 hover:text-stone-900 dark:text-zinc-400 dark:hover:text-zinc-100 cursor-pointer"
              >
                <ShieldCheck className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                <span>{siteTranslations.checklist.title[locale]}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Bottom footer: Language selection, copyright, and scroll-to-top */}
        <div className="mt-8 flex flex-col items-center justify-between gap-4 text-xs text-stone-500 sm:flex-row dark:text-zinc-500">
          <div className="flex items-center gap-3">
            <span>© {new Date().getFullYear()} Rayane Sbai · {t.rights[locale]}</span>
          </div>

          <div className="flex items-center gap-4">
            <LanguageSwitcher isCompact />
            <button
              type="button"
              onClick={scrollToTop}
              aria-label="Back to top"
              className="inline-flex items-center gap-1 text-stone-500 hover:text-stone-900 dark:text-zinc-400 dark:hover:text-zinc-200 cursor-pointer"
            >
              <span>Top</span>
              <ArrowUp className="h-3 w-3" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
