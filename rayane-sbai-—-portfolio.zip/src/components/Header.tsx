import React, { useState } from 'react';
import { Menu, X, ArrowUpRight, MapPin, Mail, Check, Copy } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { siteTranslations } from '../data/translations';
import { LanguageSwitcher } from './LanguageSwitcher';
import { ThemeToggle } from './ThemeToggle';
import { PageType } from '../types/portfolio';

export const Header: React.FC = () => {
  const { locale, currentPage, navigateTo, openCvModal } = usePortfolio();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [copiedEmail, setCopiedEmail] = useState(false);
  const t = siteTranslations.nav;

  const navItems: { page: PageType; label: string }[] = [
    { page: 'home', label: t.home[locale] },
    { page: 'projects', label: t.projects[locale] },
    { page: 'about', label: t.about[locale] },
    { page: 'contact', label: t.contact[locale] }
  ];

  const handleNavClick = (page: PageType) => {
    navigateTo(page);
    setMobileMenuOpen(false);
  };

  const handleCopyEmail = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText('rayanesbai667@gmail.com');
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2000);
  };

  const topBarText = {
    de: 'Standort: Marokko (Rabat) · Offen für Berufseinstieg oder Ausbildung in Deutschland',
    en: 'Location: Morocco (Rabat) · Open for Junior Employment or Ausbildung in Germany',
    fr: 'Localisation : Maroc (Rabat) · Ouvert pour un emploi junior ou une Ausbildung en Allemagne'
  }[locale];

  const emailTooltip = {
    de: copiedEmail ? 'E-Mail kopiert!' : 'E-Mail kopieren',
    en: copiedEmail ? 'Email copied!' : 'Copy email address',
    fr: copiedEmail ? 'E-mail copié !' : 'Copier l\'e-mail'
  }[locale];

  return (
    <header className="sticky top-0 z-40 w-full transition-colors">
      {/* 1. TOP BAR STRIP (Location, Dual Opportunity & Direct Recruiter Contact) */}
      <div className="w-full border-b border-stone-200/90 bg-stone-100/90 py-1.5 px-4 text-xs font-medium text-stone-600 transition-colors dark:border-zinc-800/90 dark:bg-zinc-950/95 dark:text-zinc-400 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4">
          
          {/* Status & Target info */}
          <div className="flex items-center gap-2.5 truncate">
            <span className="flex h-2 w-2 relative shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="truncate text-[11px] sm:text-xs text-stone-700 dark:text-zinc-300 font-medium">
              {topBarText}
            </span>
          </div>

          {/* Quick Recruiter Links */}
          <div className="hidden sm:flex items-center gap-3 shrink-0 text-[11px]">
            {/* Quick Email Copy Button with Hover */}
            <button
              type="button"
              onClick={handleCopyEmail}
              title={emailTooltip}
              className="inline-flex items-center gap-1.5 rounded-md px-2 py-0.5 text-stone-600 hover:text-stone-900 hover:bg-stone-200/60 dark:text-zinc-400 dark:hover:text-zinc-200 dark:hover:bg-zinc-800/80 transition-all cursor-pointer"
            >
              {copiedEmail ? (
                <>
                  <Check className="h-3 w-3 text-emerald-600 dark:text-emerald-400" />
                  <span className="text-emerald-600 dark:text-emerald-400 font-medium">{emailTooltip}</span>
                </>
              ) : (
                <>
                  <Mail className="h-3 w-3" />
                  <span className="font-mono">rayanesbai667@gmail.com</span>
                </>
              )}
            </button>

            <span className="text-stone-300 dark:text-zinc-700">|</span>

            {/* Quick CV Button with Hover */}
            <button
              type="button"
              onClick={openCvModal}
              className="inline-flex items-center gap-1 font-semibold text-blue-600 hover:text-blue-700 hover:underline dark:text-blue-400 dark:hover:text-blue-300 transition-colors cursor-pointer"
            >
              <span>{t.cv[locale]} PDF</span>
              <ArrowUpRight className="h-3 w-3" />
            </button>
          </div>
        </div>
      </div>

      {/* 2. MAIN NAVIGATION BAR */}
      <div className="w-full border-b border-stone-200/90 bg-white/90 backdrop-blur-md transition-colors dark:border-zinc-800/90 dark:bg-[#0c0c0e]/95">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-8 px-4 sm:px-6 lg:px-8">
          
          {/* Zone 1: Wordmark with hover glow */}
          <button
            type="button"
            onClick={() => handleNavClick('home')}
            className="group flex items-center gap-2.5 text-left transition-all hover:opacity-95 cursor-pointer whitespace-nowrap shrink-0"
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-stone-900 text-white font-bold text-sm shadow-xs transition-transform duration-300 group-hover:scale-105 group-hover:bg-blue-600 dark:bg-blue-600 dark:text-white dark:group-hover:bg-blue-500">
              RS
            </div>
            <div className="flex flex-col">
              <span className="font-serif font-bold text-base tracking-tight text-stone-900 dark:text-zinc-100 leading-tight transition-colors group-hover:text-blue-600 dark:group-hover:text-blue-400">
                Rayane Sbai
              </span>
              <span className="text-[10px] text-stone-500 dark:text-zinc-400 font-mono tracking-tight hidden sm:inline">
                UI/UX & Frontend
              </span>
            </div>
          </button>

          {/* Zone 2: Navigation Links with Hover and Active Indicator */}
          <nav
            aria-label="Main Navigation"
            className="hidden md:flex items-center gap-8 text-sm font-medium"
          >
            {navItems.map((item) => {
              const isActive = currentPage === item.page;
              return (
                <button
                  key={item.page}
                  type="button"
                  onClick={() => handleNavClick(item.page)}
                  className={`relative py-1 whitespace-nowrap shrink-0 transition-all duration-200 hover:-translate-y-0.5 cursor-pointer ${
                    isActive
                      ? 'text-stone-900 font-bold dark:text-white'
                      : 'text-stone-600 hover:text-stone-900 dark:text-zinc-400 dark:hover:text-zinc-200'
                  }`}
                >
                  {item.label}
                  {isActive && (
                    <span
                      aria-hidden="true"
                      className="absolute -bottom-2 left-0 right-0 h-0.5 bg-blue-600 dark:bg-blue-500 rounded-full shadow-xs"
                    />
                  )}
                </button>
              );
            })}
          </nav>

          {/* Zone 3: Actions (Language, Theme, Primary Contact Button with Hover) */}
          <div className="flex items-center gap-3 shrink-0">
            <LanguageSwitcher />
            <ThemeToggle />

            <button
              type="button"
              onClick={() => handleNavClick('contact')}
              className="hidden sm:inline-flex items-center justify-center rounded-xl bg-stone-900 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-stone-800 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 dark:bg-blue-600 dark:hover:bg-blue-500 dark:text-white transition-all duration-200 whitespace-nowrap shrink-0 cursor-pointer"
            >
              {t.contact[locale]}
            </button>

            {/* Mobile hamburger button with hover */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle mobile menu"
              className="inline-flex md:hidden h-9 w-9 items-center justify-center rounded-lg border border-stone-200 bg-white text-stone-700 hover:bg-stone-100 hover:border-stone-300 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-300 dark:hover:bg-zinc-800 transition-colors cursor-pointer"
            >
              {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile navigation sheet with hover items */}
      {mobileMenuOpen && (
        <div className="border-b border-stone-200 bg-white/95 px-4 py-4 md:hidden dark:border-zinc-800 dark:bg-[#0c0c0e]/95 backdrop-blur-md">
          <div className="flex flex-col gap-2">
            {navItems.map((item) => {
              const isActive = currentPage === item.page;
              return (
                <button
                  key={item.page}
                  type="button"
                  onClick={() => handleNavClick(item.page)}
                  className={`flex items-center justify-between rounded-lg px-3 py-2 text-left text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 font-semibold dark:bg-blue-950/40 dark:text-blue-400'
                      : 'text-stone-700 hover:bg-stone-100 dark:text-zinc-300 dark:hover:bg-zinc-900'
                  }`}
                >
                  <span>{item.label}</span>
                  {isActive && <span className="h-1.5 w-1.5 rounded-full bg-blue-600" />}
                </button>
              );
            })}

            <div className="mt-2 pt-2 border-t border-stone-200 dark:border-zinc-800 flex items-center justify-between gap-2">
              <button
                type="button"
                onClick={() => {
                  openCvModal();
                  setMobileMenuOpen(false);
                }}
                className="flex items-center gap-1.5 text-xs text-stone-600 hover:text-stone-900 dark:text-zinc-400 dark:hover:text-zinc-200 font-medium py-1 px-2 hover:bg-stone-100 dark:hover:bg-zinc-800 rounded-md transition-colors"
              >
                <span>{t.cv[locale]} (PDF)</span>
                <ArrowUpRight className="h-3.5 w-3.5" />
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('contact')}
                className="rounded-lg bg-blue-600 px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-blue-500 transition-colors"
              >
                {t.contact[locale]}
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
