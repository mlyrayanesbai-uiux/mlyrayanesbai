import React from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { Locale } from '../types/portfolio';

export const LanguageSwitcher: React.FC<{ isCompact?: boolean }> = ({ isCompact = false }) => {
  const { locale, changeLocale } = usePortfolio();

  const locales: { code: Locale; label: string }[] = [
    { code: 'de', label: 'DE' },
    { code: 'en', label: 'EN' },
    { code: 'fr', label: 'FR' }
  ];

  return (
    <div
      role="group"
      aria-label="Language selection"
      className="inline-flex items-center rounded-lg border border-stone-200 bg-stone-100/80 p-0.5 text-xs dark:border-zinc-800 dark:bg-zinc-900"
    >
      {locales.map((item) => {
        const isActive = locale === item.code;
        return (
          <button
            key={item.code}
            type="button"
            onClick={() => changeLocale(item.code)}
            aria-pressed={isActive}
            className={`cursor-pointer rounded-md px-2.5 py-1 font-medium transition-all duration-150 ${
              isActive
                ? 'bg-white text-stone-900 shadow-xs font-semibold dark:bg-zinc-800 dark:text-zinc-100'
                : 'text-stone-500 hover:text-stone-900 hover:bg-stone-200/60 dark:text-zinc-400 dark:hover:text-zinc-200 dark:hover:bg-zinc-800/60'
            } ${isCompact ? 'text-[11px] px-2 py-0.5' : ''}`}
          >
            {item.label}
          </button>
        );
      })}
    </div>
  );
};
