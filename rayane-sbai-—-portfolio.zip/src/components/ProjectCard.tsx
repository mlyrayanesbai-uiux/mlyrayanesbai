import React, { useState } from 'react';
import { ArrowUpRight, FolderGit2 } from 'lucide-react';
import { ProjectData } from '../types/portfolio';
import { usePortfolio } from '../context/PortfolioContext';

interface ProjectCardProps {
  project: ProjectData;
  isPriority?: boolean;
}

export const ProjectCard: React.FC<ProjectCardProps> = ({ project, isPriority = false }) => {
  const { locale, navigateTo } = usePortfolio();
  const [imgError, setImgError] = useState(false);

  const handleClick = () => {
    navigateTo('case-study', project.slug);
  };

  return (
    <div
      onClick={handleClick}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          handleClick();
        }
      }}
      role="button"
      tabIndex={0}
      className="group flex flex-col justify-between overflow-hidden rounded-2xl border border-stone-200/90 bg-white/95 backdrop-blur-xs p-5 text-left transition-all duration-300 hover:-translate-y-2 hover:border-blue-500/50 hover:shadow-2xl hover:shadow-blue-500/10 dark:border-zinc-800/90 dark:bg-zinc-900/80 dark:hover:border-blue-500/40 dark:hover:shadow-blue-950/30 focus-visible:outline-2 cursor-pointer"
    >
      <div>
        {/* Preview Image with Zero-Broken-Image Fallback */}
        <div className="relative mb-5 aspect-video w-full overflow-hidden rounded-xl bg-stone-100 dark:bg-zinc-800">
          {!imgError && project.image ? (
            <img
              src={project.image}
              alt={project.title}
              referrerPolicy="no-referrer"
              loading={isPriority ? 'eager' : 'lazy'}
              onError={() => setImgError(true)}
              className="h-full w-full object-cover object-top transition-transform duration-500 ease-out group-hover:scale-105"
            />
          ) : (
            <div className="flex h-full w-full flex-col items-center justify-center p-6 text-stone-400 dark:text-zinc-600 bg-linear-to-br from-stone-50 to-stone-100 dark:from-zinc-900 dark:to-zinc-800">
              <FolderGit2 className="h-10 w-10 stroke-1 mb-2" />
              <span className="text-xs font-medium">{project.title}</span>
            </div>
          )}
        </div>

        {/* Clean Unboxed Metadata with Typographic Separator (NO PILLS) */}
        <div className="mb-2 flex flex-wrap items-center gap-1.5 text-xs text-stone-500 dark:text-zinc-400">
          <span className="font-medium text-stone-700 dark:text-zinc-300">
            {project.categoryLabel[locale]}
          </span>
          <span aria-hidden="true">·</span>
          <span>{project.statusLabel[locale]}</span>
          {project.timeline && (
            <>
              <span aria-hidden="true">·</span>
              <span>{project.timeline}</span>
            </>
          )}
        </div>

        {/* Primary Title with Hover Accent */}
        <h3 className="text-xl font-bold tracking-tight text-stone-900 group-hover:text-blue-600 dark:text-zinc-100 dark:group-hover:text-blue-400 transition-colors">
          {project.title}
        </h3>

        {/* One-sentence summary */}
        <p className="mt-2 text-sm leading-relaxed text-stone-600 dark:text-zinc-400 line-clamp-2">
          {project.summary[locale]}
        </p>

        {/* Personal Role (Distinguishing contribution) */}
        <div className="mt-3 text-xs text-stone-500 dark:text-zinc-400">
          <span className="font-semibold text-stone-700 dark:text-zinc-300">
            {locale === 'de' ? 'Rolle: ' : locale === 'fr' ? 'Rôle : ' : 'Role: '}
          </span>
          <span>{project.role[locale]}</span>
        </div>
      </div>

      {/* Card bottom: Unboxed Tags & Action Link */}
      <div className="mt-5 pt-4 border-t border-stone-100 dark:border-zinc-800/80 flex items-center justify-between">
        <div className="flex flex-wrap items-center gap-2 text-[11px] text-stone-500 dark:text-zinc-400">
          {project.tags.slice(0, 3).map((tag, idx) => (
            <span key={tag} className="inline-flex items-center">
              {tag}
              {idx < 2 && idx < project.tags.length - 1 && (
                <span className="ml-2 text-stone-300 dark:text-zinc-700">/</span>
              )}
            </span>
          ))}
        </div>

        <span className="inline-flex items-center gap-1 text-xs font-semibold text-blue-600 dark:text-blue-400 group-hover:translate-x-0.5 transition-transform">
          <span>{locale === 'de' ? 'Fallstudie' : locale === 'fr' ? 'Étude' : 'Case Study'}</span>
          <ArrowUpRight className="h-3.5 w-3.5" />
        </span>
      </div>
    </div>
  );
};
