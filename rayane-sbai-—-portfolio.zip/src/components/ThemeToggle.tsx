import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const ThemeToggle: React.FC = () => {
  const { theme, toggleTheme, locale } = usePortfolio();

  const label = {
    de: theme === 'dark' ? 'Helles Design aktivieren' : 'Dunkles Design aktivieren',
    en: theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode',
    fr: theme === 'dark' ? 'Activer le mode clair' : 'Activer le mode sombre'
  }[locale];

  return (
    <button
      type="button"
      onClick={toggleTheme}
      aria-label={label}
      title={label}
      className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-stone-200 bg-white text-stone-600 transition-all duration-200 hover:scale-105 active:scale-95 hover:border-blue-400 hover:text-stone-900 hover:shadow-xs focus-visible:outline-2 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-400 dark:hover:border-blue-500 dark:hover:text-zinc-100 cursor-pointer"
    >
      {theme === 'dark' ? (
        <Sun className="h-4 w-4 text-amber-400 transition-transform duration-300 hover:rotate-90" />
      ) : (
        <Moon className="h-4 w-4 text-stone-700 transition-transform duration-300 hover:-rotate-45" />
      )}
    </button>
  );
};
