import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Locale, PageType } from '../types/portfolio';

interface PortfolioContextType {
  locale: Locale;
  theme: 'light' | 'dark';
  currentPage: PageType;
  currentSlug: string | null;
  isChecklistOpen: boolean;
  isCvModalOpen: boolean;
  setLocale: (locale: Locale) => void;
  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;
  navigateTo: (page: PageType, slug?: string) => void;
  changeLocale: (newLocale: Locale) => void;
  openChecklist: () => void;
  closeChecklist: () => void;
  openCvModal: () => void;
  closeCvModal: () => void;
  getLocalizedPath: (page: PageType, slug?: string, targetLocale?: Locale) => string;
}

const PortfolioContext = createContext<PortfolioContextType | undefined>(undefined);

// Route segment maps
const routeSegments: Record<Locale, Record<PageType, string>> = {
  de: {
    home: '',
    projects: 'projekte',
    'case-study': 'projekte',
    about: 'ueber-mich',
    contact: 'kontakt'
  },
  en: {
    home: '',
    projects: 'projects',
    'case-study': 'projects',
    about: 'about',
    contact: 'contact'
  },
  fr: {
    home: '',
    projects: 'projets',
    'case-study': 'projets',
    about: 'a-propos',
    contact: 'contact'
  }
};

export const PortfolioProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Locale State
  const [locale, setLocaleState] = useState<Locale>(() => {
    const saved = localStorage.getItem('portfolio_lang');
    if (saved === 'de' || saved === 'en' || saved === 'fr') return saved;
    return 'de'; // German is default as requested
  });

  // Theme State
  const [theme, setThemeState] = useState<'light' | 'dark'>(() => {
    const saved = localStorage.getItem('portfolio_theme');
    if (saved === 'light' || saved === 'dark') return saved;
    if (typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  });

  // Page Routing State
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [currentSlug, setCurrentSlug] = useState<string | null>(null);

  // Modals
  const [isChecklistOpen, setIsChecklistOpen] = useState(false);
  const [isCvModalOpen, setIsCvModalOpen] = useState(false);

  // Sync theme with DOM
  useEffect(() => {
    const root = document.documentElement;
    const body = document.body;
    if (theme === 'dark') {
      root.classList.add('dark');
      body.classList.add('dark');
      root.setAttribute('data-theme', 'dark');
      root.style.colorScheme = 'dark';
    } else {
      root.classList.remove('dark');
      body.classList.remove('dark');
      root.setAttribute('data-theme', 'light');
      root.style.colorScheme = 'light';
    }
    localStorage.setItem('portfolio_theme', theme);
  }, [theme]);

  // Sync HTML lang and Title
  useEffect(() => {
    document.documentElement.lang = locale;
    localStorage.setItem('portfolio_lang', locale);
    
    const titles: Record<Locale, string> = {
      de: 'Rayane Sbai — UI/UX Designer & Frontend Developer',
      en: 'Rayane Sbai — UI/UX Designer & Frontend Developer',
      fr: 'Rayane Sbai — Designer UI/UX & Développeur Frontend'
    };
    document.title = titles[locale];
  }, [locale]);

  // Parse path to route
  const parsePath = (pathname: string) => {
    const clean = pathname.replace(/^\/+|\/+$/g, '');
    if (!clean) {
      return { loc: locale, page: 'home' as PageType, slug: null };
    }

    const segments = clean.split('/');
    const first = segments[0];
    let loc: Locale = locale;
    let rest = segments;

    if (first === 'de' || first === 'en' || first === 'fr') {
      loc = first;
      rest = segments.slice(1);
    }

    if (rest.length === 0) {
      return { loc, page: 'home' as PageType, slug: null };
    }

    const pageSeg = rest[0];
    const slug = rest.length > 1 ? rest[1] : null;

    if (pageSeg === 'projekte' || pageSeg === 'projects' || pageSeg === 'projets') {
      return { loc, page: slug ? ('case-study' as PageType) : ('projects' as PageType), slug };
    }

    if (pageSeg === 'ueber-mich' || pageSeg === 'about' || pageSeg === 'a-propos') {
      return { loc, page: 'about' as PageType, slug: null };
    }

    if (pageSeg === 'kontakt' || pageSeg === 'contact') {
      return { loc, page: 'contact' as PageType, slug: null };
    }

    return { loc, page: 'home' as PageType, slug: null };
  };

  // Initial parse on load
  useEffect(() => {
    const parsed = parsePath(window.location.pathname);
    setLocaleState(parsed.loc);
    setCurrentPage(parsed.page);
    setCurrentSlug(parsed.slug);

    const handlePopState = () => {
      const p = parsePath(window.location.pathname);
      setLocaleState(p.loc);
      setCurrentPage(p.page);
      setCurrentSlug(p.slug);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  // Helper to generate localized URL
  const getLocalizedPath = (page: PageType, slug?: string, targetLoc: Locale = locale) => {
    const seg = routeSegments[targetLoc][page];
    if (page === 'home') {
      return `/${targetLoc}`;
    }
    if (page === 'case-study' && slug) {
      return `/${targetLoc}/${seg}/${slug}`;
    }
    return `/${targetLoc}/${seg}`;
  };

  // Navigate to page
  const navigateTo = (page: PageType, slug?: string) => {
    setCurrentPage(page);
    setCurrentSlug(slug || null);
    const newPath = getLocalizedPath(page, slug, locale);
    window.history.pushState({}, '', newPath);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Change locale while preserving current page & project
  const changeLocale = (newLocale: Locale) => {
    setLocaleState(newLocale);
    const newPath = getLocalizedPath(currentPage, currentSlug || undefined, newLocale);
    window.history.pushState({}, '', newPath);
  };

  const toggleTheme = () => {
    setThemeState(prev => (prev === 'light' ? 'dark' : 'light'));
  };

  return (
    <PortfolioContext.Provider
      value={{
        locale,
        theme,
        currentPage,
        currentSlug,
        isChecklistOpen,
        isCvModalOpen,
        setLocale: setLocaleState,
        setTheme: setThemeState,
        toggleTheme,
        navigateTo,
        changeLocale,
        openChecklist: () => setIsChecklistOpen(true),
        closeChecklist: () => setIsChecklistOpen(false),
        openCvModal: () => setIsCvModalOpen(true),
        closeCvModal: () => setIsCvModalOpen(false),
        getLocalizedPath
      }}
    >
      {children}
    </PortfolioContext.Provider>
  );
};

export const usePortfolio = () => {
  const context = useContext(PortfolioContext);
  if (!context) {
    throw new Error('usePortfolio must be used within a PortfolioProvider');
  }
  return context;
};
