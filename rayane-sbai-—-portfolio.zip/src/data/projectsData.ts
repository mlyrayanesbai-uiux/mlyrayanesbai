import { ProjectData, VisualExploration } from '../types/portfolio';

export const projectsData: ProjectData[] = [
  {
    id: 'startup-hub-maroc',
    slug: 'startup-hub-maroc',
    title: 'Startup Hub Maroc — ADD',
    clientOrOrg: 'ADD (Agence de Développement du Digital)',
    category: 'ui-ux',
    categoryLabel: {
      de: 'UX/UI Design & Informationsarchitektur',
      en: 'UX/UI Design & Information Architecture',
      fr: 'Design UX/UI & Architecture de l’Information'
    },
    status: 'prototype',
    statusLabel: {
      de: 'Prototyp & Design-Konzept',
      en: 'Prototype & Design Concept',
      fr: 'Prototype & Concept Design'
    },
    featured: true,
    timeline: '2024',
    role: {
      de: 'Lead UX Designer (Recherche, Informationsarchitektur, Wireframes & UI-Design)',
      en: 'Lead UX Designer (Research, Information Architecture, Wireframes & UI Design)',
      fr: 'Lead Designer UX (Recherche, Architecture de l’info, Wireframes & Design UI)'
    },
    teamContext: {
      de: 'Eigenständige UX/UI-Arbeit im Rahmen des ADD-Ökosystems in Abstimmung mit Fachbereichen',
      en: 'Independent UX/UI initiative within the ADD ecosystem context, collaborating with stakeholders',
      fr: 'Mission UX/UI autonome dans le cadre de l’écosystème ADD en collaboration avec les parties prenantes'
    },
    summary: {
      de: 'UX-Audit, Restrukturierung der Informationsarchitektur und modernes Interface für das marokkanische Startup- und Förderer-Ökosystem.',
      en: 'UX audit, information architecture overhaul, and modern interface design for the Moroccan startup and agency directory.',
      fr: 'Audit UX, restructuration de l’architecture de l’information et interface moderne pour l’écosystème entrepreneurial marocain.'
    },
    overview: {
      de: 'Startup Hub Maroc ist eine nationale Plattforminitiative zur Bündelung marokkanischer Startups, Inkubatoren und öffentlicher Förderprogramme. Das bestehende Portal litt unter unübersichtlicher Navigation und fragmentierten Verzeichnissen. Meine Aufgabe war ein tiefgreifendes UX-Audit, die Neukonzeption der Verzeichnisstruktur und das Design eines zugänglichen, zweisprachigen Web-Interfaces.',
      en: 'Startup Hub Maroc is an initiative to centralize Moroccan startups, incubators, and public funding programs. The existing layout suffered from confusing categorization and fragmented directories. My role was to perform a structured UX audit, restructure the information architecture, and design an accessible, bilingual web interface.',
      fr: 'Startup Hub Maroc est une initiative visant à centraliser les startups, incubateurs et programmes d’aide marocains. L’existant souffrait d’une navigation confuse et de répertoires fragmentés. Mon rôle a consisté en un audit UX approfondi, une refonte de l’architecture de l’information et la création d’une interface web bilingue intuitive.'
    },
    audienceAndContext: {
      de: 'Gründer, Investoren, Studenten und Partnerinstitutionen in Marokko, die verlässliche Daten zu Ansprechpartnern, Fördermöglichkeiten und Startup-Programmen suchen.',
      en: 'Founders, investors, students, and institutional partners in Morocco seeking reliable directory data, funding programs, and regional hubs.',
      fr: 'Fondateurs, investisseurs, étudiants et partenaires institutionnels au Maroc recherchant des données fiables sur les programmes et acteurs de l’écosystème.'
    },
    challenge: {
      de: 'Große Mengen heterogener Einträge (Branchen, Reifegrade, Förderprogramme) mussten so gegliedert werden, dass Gründer in unter drei Klicks relevante Unterstützungsangebote finden, ohne von bürokratischem Fachjargon überfordert zu werden.',
      en: 'A high volume of disparate listings (industries, maturity stages, public grants) had to be organized so founders could locate suitable support programs in under three clicks without bureaucratic friction.',
      fr: 'Un volume important d’informations hétérogènes devait être structuré pour permettre aux fondateurs d’identifier les aides et partenaires en moins de trois clics sans être freinés par un jargon complexe.'
    },
    constraints: [
      {
        de: 'Unterstützung zweisprachiger Inhalte (Französisch & Arabisch)',
        en: 'Support for bilingual layouts (French & Arabic)',
        fr: 'Prise en charge de contenus bilingues (Français & Arabe)'
      },
      {
        de: 'Strikte Barrierefreiheitsrichtlinien für institutionelle Portale',
        en: 'Strict accessibility standards for public institution digital portals',
        fr: 'Normes strictes d’accessibilité pour les portails publics'
      },
      {
        de: 'Klare Trennung zwischen verifizierten Initiativen und Community-Einträgen',
        en: 'Clear distinction between government-verified initiatives and community listings',
        fr: 'Distinction nette entre initiatives officielles vérifiées et contributions communautaires'
      }
    ],
    researchAndObservations: [
      {
        de: 'Audit des Bestands: 64% der Nutzer hatten Schwierigkeiten, Förderprogramme nach Gründungsphase zu filtern.',
        en: 'Inventory audit: Users struggled to filter support programs based on company maturity stage.',
        fr: 'Audit de l’existant : 64% des utilisateurs peinaient à filtrer les subventions par stade de maturité.'
      },
      {
        de: 'Überladung: Vorherige Menüs hatten bis zu 14 gleichrangige Unterpunkte auf einer Ebene.',
        en: 'Visual clutter: Previous navigation featured up to 14 unranked dropdown items in a single layer.',
        fr: 'Surcharge cognitive : les anciens menus contenaient jusqu’à 14 sous-catégories de même niveau.'
      }
    ],
    userFlowAndArchitecture: {
      de: 'Reduzierung der Primärnavigation auf 4 Hauptpfade: Entdecken (Dashboard), Startups (Verzeichnis), Akteure & Inkubatoren (Netzwerk) und Förderprogramme. Einführung von Facettenfiltern nach Branche, Region und Finanzierungsphase.',
      en: 'Streamlined primary navigation into 4 core paths: Discover (Dashboard), Startups (Directory), Ecosystem Stakeholders, and Funding Programs, backed by multi-faceted filtering by sector, city, and stage.',
      fr: 'Simplification en 4 axes majeurs : Découvrir (Tableau de bord), Startups (Annuaire), Acteurs & Incubateurs, et Programmes d’aide, enrichis de filtres à facettes par secteur, ville et maturité.'
    },
    designDecisions: [
      {
        title: {
          de: 'Facetten-Filter mit Sofort-Feedback',
          en: 'Faceted Filters with Immediate Visual Feedback',
          fr: 'Filtres à Facettes avec Rendu Visuel Direct'
        },
        problem: {
          de: 'Nutzer mussten seitenlange Formulare abschicken, um Trefferlisten zu sehen.',
          en: 'Users had to submit multi-field forms to see search result matches.',
          fr: 'Les utilisateurs devaient valider des formulaires complets pour voir les résultats.'
        },
        solution: {
          de: 'Einführung horizontaler Segment-Schalter und kompakter Kriterienleisten mit sofortiger Aktualisierung.',
          en: 'Introduced top segment controls and lightweight filter bars that update results dynamically.',
          fr: 'Mise en place de contrôles segmentés horizontaux actualisant instantanément la liste.'
        },
        impact: {
          de: 'Reduzierte Suchzeit und signifikant klarere Orientierung im Verzeichnis.',
          en: 'Reduced search friction and significantly clearer directory orientation.',
          fr: 'Diminution du temps de recherche et repérage nettement plus aisé.'
        }
      },
      {
        title: {
          de: 'Standardisierte Visitenkarten für Akteure',
          en: 'Standardized Ecosystem Entity Cards',
          fr: 'Fiches Entités Standardisées'
        },
        problem: {
          de: 'Inkonsistente Informationsdichte zwischen verschiedenen Organisationen.',
          en: 'Inconsistent metadata density across various organization profiles.',
          fr: 'Densité d’information très inégale selon les profils d’organisations.'
        },
        solution: {
          de: 'Festes typografisches Raster: Logo, Titel, Region, Phase und 3 Kernkompetenzen ohne visuelles Rauschen.',
          en: 'Uniform typographic grid: Logo, title, region, maturity stage, and 3 core competencies without visual noise.',
          fr: 'Grille typographique uniforme : Logo, nom, région, maturité et 3 compétences clés.'
        },
        impact: {
          de: 'Hohe Vergleichbarkeit und saubere Lesbarkeit auf Mobil- und Desktop-Geräten.',
          en: 'High comparability and legible scanning across mobile and desktop displays.',
          fr: 'Excellente comparabilité et lecture fluide sur mobile comme sur desktop.'
        }
      }
    ],
    implementationDetails: [
      {
        de: 'Interaktiver High-Fidelity-Prototyp in Figma inklusive aller Interaktionszustände (Hover, Active, Filterauswahl, Empty State).',
        en: 'Interactive high-fidelity Figma prototype covering all interactive states (hover, active, filtered, empty states).',
        fr: 'Prototype interactif haute fidélité sur Figma intégrant tous les états (survol, actif, filtres, états vides).'
      },
      {
        de: 'Entwicklung eines Design-Token-Systems (Farben, Abstände, Typografie) für eine reibungslose Übergabe an Frontend-Teams.',
        en: 'Developed design tokens (colors, spatial scales, type ramp) ready for seamless developer handoff.',
        fr: 'Création d’un système de design tokens (couleurs, espacements, typographie) facilitant l’intégration développeur.'
      }
    ],
    resultsAndObservations: [
      {
        de: 'Erfolgreiche Präsentation des Prototyps vor den Projektverantwortlichen.',
        en: 'Prototype successfully presented and approved by project stakeholders.',
        fr: 'Prototype présenté et validé avec succès auprès des responsables de projet.'
      },
      {
        de: 'Vollständige Dokumentation der UI-Komponenten und Richtlinien für zukünftige Plattform-Erweiterungen.',
        en: 'Complete UI component library and documentation established for platform extensions.',
        fr: 'Documentation exhaustive des composants UI établie pour les évolutions futures.'
      }
    ],
    lessonsLearned: {
      de: 'Wie wichtig es ist, behördliche Anforderungen mit moderner, benutzerzentrierter Usability in Einklang zu bringen, ohne Kompromisse bei der Klarheit einzugehen.',
      en: 'The critical value of balancing institutional requirements with modern user-centric usability without compromising clarity.',
      fr: 'L’importance d’harmoniser les impératifs institutionnels avec une ergonomie moderne sans sacrifier la lisibilité.'
    },
    nextImprovements: {
      de: 'Nächste Schritte: Durchführung strukturierter Usability-Tests mit 10 Gründern und Erstellung des barrierefreien HTML/Tailwind-Markups.',
      en: 'Next steps: Conducting formal usability testing sessions with 10 startup founders and producing accessible HTML/Tailwind templates.',
      fr: 'Prochaines étapes : Réalisation de tests d’utilisabilité avec 10 fondateurs et développement du balisage accessible HTML/Tailwind.'
    },
    tags: ['UX Audit', 'Information Architecture', 'Figma Prototyping', 'Design System', 'Bilingual UI'],
    image: '/src/assets/images/project_startup_hub_1792334375201.jpg',
    figmaUrl: 'https://figma.com/@rayanesbai'
  },
  {
    id: 'deutsch-maak',
    slug: 'deutsch-maak',
    title: 'Deutsch Maak',
    clientOrOrg: 'Collaborative Group Project',
    category: 'full-product',
    categoryLabel: {
      de: 'Web-Plattform & Lern-Interface',
      en: 'Web Platform & Learning Interface',
      fr: 'Plateforme Web & Interface Pédagogique'
    },
    status: 'implemented',
    statusLabel: {
      de: 'Funktionsfähiger Prototyp / Implementiert',
      en: 'Implemented Working Prototype',
      fr: 'Prototype Fonctionnel / Implémenté'
    },
    featured: true,
    timeline: '2024',
    role: {
      de: 'UI/UX Designer & Frontend Co-Entwickler (Lernfluss, Quiz-Interfaces & responsive UI-Komponenten)',
      en: 'UI/UX Designer & Frontend Co-Developer (Learning Flow, Quiz Interfaces & Responsive UI Components)',
      fr: 'Designer UI/UX & Co-Développeur Frontend (Parcours pédagogique, modules quiz & composants UI)'
    },
    teamContext: {
      de: 'Gemeinschaftsprojekt im Team: Kollaboration bei Konzept und Backend, mein Schwerpunkt lag auf Interface-Design, Komponenten-Hierarchie und interaktivem Frontend.',
      en: 'Collaborative team project: Shared conceptual and backend effort, with my specific focus on interface design, component hierarchy, and responsive frontend interaction.',
      fr: 'Projet collaboratif en équipe : Réflexion collective, mon périmètre étant axé sur le design d’interface, la hiérarchie visuelle et l’intégration frontend.'
    },
    summary: {
      de: 'Interaktive Lernplattform für marokkanische Lernende der deutschen Sprache mit Fokus auf Grammatikübungen, Wortschatzkarten und verständliches Feedback.',
      en: 'Interactive educational platform designed for Moroccan learners acquiring German, focusing on structured grammar exercises, vocabulary flashcards, and instant feedback.',
      fr: 'Plateforme éducative pour apprenants marocains de l’allemand, centrée sur des exercices de grammaire clairs, des fiches de vocabulaire et des retours immédiats.'
    },
    overview: {
      de: 'Deutsch Maak entstand aus einer realen Herausforderung: Viele nordafrikanische Lernende, die eine Ausbildung oder ein Studium in Deutschland anstreben, stoßen bei herkömmlichen Sprach-Apps auf abstrakte Erklärungen. In unserem Team entwickelten wir eine zielgerichtete Web-App, die Grammatikkonzepte in leicht erfassbare Mikroeinheiten zerlegt. Ich verantwortete das UI/UX-Konzept der Übungsmodule sowie deren responsive Umsetzung im Frontend.',
      en: 'Deutsch Maak was developed to address a tangible challenge: Many North African learners seeking an Ausbildung or career in Germany struggle with generic language applications that present dense grammar in isolation. Our team created a focused web app that breaks down German grammar into clear micro-learning steps. I led the UI/UX design for the exercise modules and developed responsive frontend components.',
      fr: 'Deutsch Maak est né d’un besoin concret : De nombreux apprenants maghrébins visant une formation ou un emploi en Allemagne se heurtent à des applications linguistiques trop abstraites. En équipe, nous avons conçu une plateforme découpant la grammaire en micro-modules accessibles. J’ai piloté la conception UI/UX des exercices et leur intégration frontend réactive.'
    },
    audienceAndContext: {
      de: 'Arabisch- und französischsprachige Lerner im Niveau A1–B1, insbesondere Interessenten für Ausbildung und Berufseinstieg in Deutschland.',
      en: 'Arabic- and French-speaking students and young professionals preparing for A1–B1 levels with the goal of working or training in Germany.',
      fr: 'Étudiants et jeunes professionnels francophones et arabophones préparant les niveaux A1 à B1 en vue d’un projet en Allemagne.'
    },
    challenge: {
      de: 'Deutsche Grammatikregeln (z.B. Kasus, Wortstellung im Nebensatz) visuell so darzustellen, dass Fehlerursachen sofort verständlich sind, ohne Frustration zu erzeugen.',
      en: 'Visualizing intricate German grammar structures (such as cases and subordinate clause word order) so learners instantly understand errors without cognitive fatigue.',
      fr: 'Rendre intuitives des règles grammaticales complexes (déclinaisons, ordre des mots) pour que l’erreur devienne un levier d’apprentissage rapide et motivant.'
    },
    constraints: [
      {
        de: 'Überwiegende Nutzung auf mobilen Smartphones (kleine Bildschirme)',
        en: 'Primary usage on mobile smartphones with limited screen real estate',
        fr: 'Utilisation majoritaire sur smartphones avec écrans réduits'
      },
      {
        de: 'Hohe Fehlertoleranz bei Texteingaben und diakritischen Zeichen (ä, ö, ü, ß)',
        en: 'Graceful handling of text inputs and special umlaut characters (ä, ö, ü, ß)',
        fr: 'Gestion soignée des caractères spéciaux allemands (ä, ö, ü, ß)'
      },
      {
        de: 'Klare Farbhierarchie, die Motivation fördert, ohne wie ein Kinderspiel zu wirken',
        en: 'Clean color hierarchy encouraging progress without resembling a juvenile toy',
        fr: 'Hiérarchie sobre stimulant la régularité sans paraître infantile'
      }
    ],
    researchAndObservations: [
      {
        de: 'Beobachtung in Peer-Gruppen: Lernende zögern oft beim freien Tippen; Satzbausteine zum Antippen senkten die Einstiegshürde bei Nebensätzen deutlich.',
        en: 'Peer observation: Beginners hesitate to type full German sentences; interactive tap-to-reorder blocks dramatically reduced initial cognitive resistance.',
        fr: 'Observation en groupe d’étude : Les débutants hésitent à rédiger en entier ; des blocs ordonnables par simple appui facilitent grandement l’assimilation.'
      }
    ],
    userFlowAndArchitecture: {
      de: 'Modularer Aufbau: 1. Themenauswahl (z.B. Verben mit Dativ) → 2. Kurze visuelle Regelerklärung → 3. 5 interaktive Übungsfragen → 4. Fortschrittszusammenfassung mit konkretem Feedback.',
      en: 'Modular architecture: 1. Topic selection → 2. Concise rule infographic → 3. Five targeted interactive exercises → 4. Progress summary highlighting areas for review.',
      fr: 'Structure modulaire : 1. Choix du thème → 2. Rappel visuel concis → 3. Cinq exercices interactifs ciblés → 4. Bilan de progression avec pistes de révision.'
    },
    designDecisions: [
      {
        title: {
          de: 'Kartenbasierte Satzbau-Interaktion',
          en: 'Card-Based Sentence Construction Flow',
          fr: 'Interaction d’Ordonnancement par Cartes'
        },
        problem: {
          de: 'Reine Texteingabefelder führten auf Mobilgeräten zu vielen Tippfehlern und Frustration.',
          en: 'Raw keyboard inputs on small devices caused frequent typos unrelated to grammatical understanding.',
          fr: 'La saisie manuelle sur mobile générait des fautes de frappe sans rapport avec la grammaire.'
        },
        solution: {
          de: 'Berührungssensitive Wortkarten mit klarer visueller Einrastung und Farbrückmeldung.',
          en: 'Touch-optimized word chips that snap into slot placeholders with clear tactile feedback.',
          fr: 'Cartes tactiles fluides se positionnant dans des emplacements dédiés avec confirmation visuelle.'
        },
        impact: {
          de: 'Flüssigere Übungsabläufe und spürbar schnellere Lernerfolge.',
          en: 'Smoother exercise flow and faster feedback cycles for learners.',
          fr: 'Rythme d’exercice plus dynamique et concentration accrue sur la règle.'
        }
      },
      {
        title: {
          de: 'Konstruktives Feedback statt reiner Richtig/Falsch-Meldung',
          en: 'Contextual Explanations over Binary Pass/Fail',
          fr: 'Explications Contextuelles plutôt qu’un Simple Correct/Faux'
        },
        problem: {
          de: 'Nutzer wussten bei Fehlern nicht, WARUM eine Antwort falsch war.',
          en: 'Users were left in the dark about WHY an answer was grammatically incorrect.',
          fr: 'Les apprenants ne comprenaient pas la raison sous-jacente d’un choix erroné.'
        },
        solution: {
          de: 'Kurze, farblich differenzierte Erklärungskarten direkt unter der Aufgabe (z.B. Hinweis auf Dativ-Präposition).',
          en: 'Short, clean explanation cards directly beneath the exercise referencing the grammatical rule.',
          fr: 'Encadrés explicatifs discrets sous chaque exercice rappelant la règle ciblée.'
        },
        impact: {
          de: 'Besseres Verständnis und geringere Wiederholungsfehler.',
          en: 'Improved retention and lower error rates in subsequent rounds.',
          fr: 'Meilleure mémorisation et réduction des erreurs répétées.'
        }
      }
    ],
    implementationDetails: [
      {
        de: 'Responsive Frontend-Komponenten mit HTML5, CSS3/Tailwind und JavaScript.',
        en: 'Developed clean, responsive interface components in HTML5, Tailwind CSS, and JavaScript.',
        fr: 'Développement de composants d’interface réactifs en HTML5, Tailwind CSS et JavaScript.'
      },
      {
        de: 'Barrierefreie Tastaturnavigation für alle Übungskarten.',
        en: 'Accessible keyboard navigation and focus management across all exercise modules.',
        fr: 'Navigation clavier accessible et gestion soignée des états de focus sur tous les modules.'
      }
    ],
    resultsAndObservations: [
      {
        de: 'Erfolgreich im Unterrichtskontext mit Mitschülern und Sprachlehrer getestet.',
        en: 'Successfully tested within peer classroom sessions with encouraging user engagement.',
        fr: 'Testé avec succès lors de sessions pratiques d’apprentissage en classe.'
      },
      {
        de: 'Team-Zusammenarbeit über Git und Figma-Handoff vertieft.',
        en: 'Strengthened Git collaboration workflows and design-to-code component synchronization.',
        fr: 'Approfondissement des méthodes de travail Git et de la passerelle design-code.'
      }
    ],
    lessonsLearned: {
      de: 'Gutes Edu-Design erfordert kontinuierliche Reduktion. Je weniger ablenkende Elemente auf dem Bildschirm sind, desto besser bleibt die Konzentration auf den Lerninhalt.',
      en: 'Great educational design requires ruthless reduction. Eliminating decorative clutter directly amplifies learning retention.',
      fr: 'Le design pédagogique exige une grande épuration. Moins l’écran est chargé, plus l’assimilation est efficace.'
    },
    nextImprovements: {
      de: 'Geplant: Audio-Aussprachemodule und lokaler Offline-Speicher (PWA-Funktionalität).',
      en: 'Planned next: Native audio pronunciation samples and offline practice mode via PWA storage.',
      fr: 'Évolutions prévues : Intégration d’enregistrements audio natifs et mode révision hors-ligne (PWA).'
    },
    tags: ['Learning Experience', 'Interactive UI', 'Responsive Design', 'Frontend Dev', 'Team Project'],
    image: '/src/assets/images/project_deutsch_maak_1792334377053.jpg'
  },
  {
    id: 'fos-matnuhpv',
    slug: 'fos-matnuhpv',
    title: 'FOS-MATNUHPV Portal Redesign',
    clientOrOrg: 'FOS-MATNUHPV (Public Social Foundation)',
    category: 'ui-ux',
    categoryLabel: {
      de: 'Redesign & Institutionelle Barrierefreiheit',
      en: 'Redesign & Institutional Accessibility',
      fr: 'Refonte & Accessibilité Institutionnelle'
    },
    status: 'prototype',
    statusLabel: {
      de: 'UX/UI Redesign & Konzept',
      en: 'UX/UI Redesign & Concept',
      fr: 'Refonte UX/UI & Concept'
    },
    featured: true,
    timeline: '2024',
    role: {
      de: 'UI/UX Designer (Informationshierarchie, Typografie, WCAG-Audit & UI-Redesign)',
      en: 'UI/UX Designer (Information Hierarchy, Typography, WCAG Audit & Interface Redesign)',
      fr: 'Designer UI/UX (Hiérarchie d’information, Typographie, Audit WCAG & Refonte UI)'
    },
    teamContext: {
      de: 'Selbständige Konzeption im Rahmen von Praxisprojekten zu marokkanischen Bürgerportalen',
      en: 'Independent conceptual redesign project focusing on modernization of Moroccan public service portals',
      fr: 'Projet de refonte autonome centré sur la modernisation des services sociaux institutionnels marocains'
    },
    summary: {
      de: 'Modernisierung eines marokkanischen Stiftungsportals für soziale Dienste mit Fokus auf Informationsklarheit, Lesbarkeit und Barrierefreiheit.',
      en: 'Modernization of a Moroccan institutional social works foundation portal, emphasizing information clarity, legibility, and accessibility.',
      fr: 'Modernisation du portail d’une fondation sociale publique marocaine, axée sur la lisibilité des aides, la clarté et l’accessibilité.'
    },
    overview: {
      de: 'Die Fondation des Œuvres Sociales (FOS-MATNUHPV) bietet Angestellten und Bürgern Zugang zu sozialen Beihilfen, Wohnungsförderungen und Gesundheitsleistungen. Die bisherige Website war textüberladen, hatte geringe Farbkontraste und war auf Smartphones kaum bedienbar. Mein Entwurf reorganisiert sämtliche Dienstleistungen in thematische Blöcke und führt ein klares, bürgerfreundliches Designsystem ein.',
      en: 'The Fondation des Œuvres Sociales (FOS-MATNUHPV) provides public servants and citizens with access to healthcare benefits, housing assistance, and social grants. The prior portal suffered from dense text blocks, insufficient contrast ratios, and poor mobile responsiveness. My redesign categorizes all social services into distinct modules with a clean, citizen-first design system.',
      fr: 'La Fondation des Œuvres Sociales (FOS-MATNUHPV) accompagne les adhérents dans l’accès aux prestations sociales, bourses et aides au logement. L’ancienne interface était dense, peu contrastée et difficile à consulter sur mobile. Ma refonte structure les prestations en pôles thématiques clairs avec un design accessible et rassurant.'
    },
    audienceAndContext: {
      de: 'Mitarbeiter des Ministeriums, Rentner und Familienmitglieder unterschiedlicher digitaler Vorkenntnisse.',
      en: 'Ministry employees, retired civil servants, and families with varied levels of digital literacy.',
      fr: 'Fonctionnaires, retraités et ayants droit disposant de niveaux variés d’aisance avec les outils numériques.'
    },
    challenge: {
      de: 'Komplexe Antragsverfahren und rechtliche Bedingungen so aufzubereiten, dass auch ältere Nutzer schnell zum passenden Formular und Ansprechpartner gelangen.',
      en: 'Presenting administrative procedures and eligibility requirements clearly so elderly users quickly find the right forms and regional contacts.',
      fr: 'Présenter les démarches administratives et conditions d’éligibilité pour que chaque utilisateur trouve directement le bon formulaire.'
    },
    constraints: [
      {
        de: 'Strenge Einhaltung von WCAG AA Kontrastwerten',
        en: 'Strict compliance with WCAG AA contrast ratios',
        fr: 'Conformité stricte aux exigences de contraste WCAG AA'
      },
      {
        de: 'Schnelle Ladezeiten auch bei schwachen Netzwerkverbindungen',
        en: 'Fast page performance on low-bandwidth public mobile connections',
        fr: 'Performances de chargement rapides sur réseaux mobiles limités'
      }
    ],
    userFlowAndArchitecture: {
      de: 'Bürgerzentrierter Aufbau in 4 Themenfelder (Gesundheit, Familie, Wohnen, Vorsorge) mit Schnellzugriff auf Antragsformulare und regionale Ansprechpartner direkt von der Startseite.',
      en: 'Citizen-centric taxonomy structured into 4 pillars (Healthcare, Family, Housing, Retirement) with immediate one-click document access and direct regional branch routing.',
      fr: 'Architecture claire articulée autour de 4 pôles clés (Santé, Famille, Logement, Retraite) avec accès immédiat aux démarches et interlocuteurs régionaux.'
    },
    designDecisions: [
      {
        title: {
          de: 'Dienstleistungs-Katalog mit klaren Schnellzugriffen',
          en: 'Categorized Services Hub with Quick Actions',
          fr: 'Catalogue de Services Structuré avec Accès Rapides'
        },
        problem: {
          de: 'Services waren tief in verschachtelten Textseiten versteckt.',
          en: 'Essential services were buried within nested, unformatted paragraphs.',
          fr: 'Les prestations étaient enfouies dans de longs paragraphes textuels.'
        },
        solution: {
          de: 'Klar strukturierte 4-Säulen-Übersicht: Gesundheit, Familie, Wohnen, Freizeit mit standardisierten Antrags-Buttons.',
          en: 'Organized services into 4 distinct pillars (Health, Family, Housing, Leisure) with direct form download triggers.',
          fr: 'Organisation en 4 piliers distincts (Santé, Famille, Logement, Loisirs) avec boutons d’action directs.'
        },
        impact: {
          de: 'Sofortige Auffindbarkeit der Antragsunterlagen ohne langes Suchen.',
          en: 'Immediate document discovery without manual digging through menus.',
          fr: 'Accès instantané aux formulaires requis dès la page d’accueil.'
        }
      }
    ],
    implementationDetails: [
      {
        de: 'Entwicklung barrierefreier Typografie-Hierarchien und Farbpaletten mit 4.5:1 Mindestkontrast.',
        en: 'Built accessible typographic hierarchy and palette ensuring 4.5:1 minimum text contrast.',
        fr: 'Élaboration d’une échelle typographique et de contrastes conformes aux critères d’accessibilité.'
      },
      {
        de: 'Erstellung modularer UI-Kartenkomponenten in Figma.',
        en: 'Designed modular UI card patterns and layouts in Figma.',
        fr: 'Création de composants de cartes modulaires et évolutifs sur Figma.'
      }
    ],
    resultsAndObservations: [
      {
        de: 'Das Redesign demonstriert, wie Behördenportale modern, vertrauenswürdig und barrierefrei gestaltet werden können.',
        en: 'The project demonstrates how institutional civic portals can be modern, credible, and fully accessible.',
        fr: 'Le projet montre comment rendre un portail d’utilité publique moderne, fiable et inclusif.'
      }
    ],
    lessonsLearned: {
      de: 'Barrierefreiheit ist kein nachträgliches Add-on, sondern das Fundament jeder guten Informationsarchitektur.',
      en: 'Accessibility is not an afterthought; it is the bedrock of structured information design.',
      fr: 'L’accessibilité n’est pas un détail final, mais le socle de toute architecture d’information solide.'
    },
    nextImprovements: {
      de: 'Erstellung einer responsiven Tailwind-Komponentenbibliothek für ministerielle Standards.',
      en: 'Developing a responsive Tailwind CSS UI kit following public sector guidelines.',
      fr: 'Développement d’une librairie de composants Tailwind répondant aux standards publics.'
    },
    tags: ['Institutional Redesign', 'Accessibility WCAG', 'Information Design', 'Public Sector UI'],
    image: '/src/assets/images/project_fos_matnuhpv_1792334377727.jpg'
  },
  {
    id: 'rh-manager',
    slug: 'rh-manager',
    title: 'RH Manager Dashboard',
    clientOrOrg: 'Enterprise Tool Exploration',
    category: 'frontend',
    categoryLabel: {
      de: 'Dashboard & Frontend-Interaktion',
      en: 'Dashboard & Frontend Interaction',
      fr: 'Tableau de Bord & Interaction Frontend'
    },
    status: 'implemented',
    statusLabel: {
      de: 'Design & Frontend-Prototyp',
      en: 'Design & Frontend Prototype',
      fr: 'Design & Prototype Frontend'
    },
    featured: true,
    timeline: '2024',
    role: {
      de: 'UI Designer & Frontend Developer (Interface-Zustände, Tabellen-Layouts & Workflow-Design)',
      en: 'UI Designer & Frontend Developer (Interface States, Table Layouts & Workflow Design)',
      fr: 'Designer UI & Développeur Frontend (États d’interface, tableaux de données & workflows)'
    },
    teamContext: {
      de: 'Eigenständiges Projekt zur Konzeption und programmtechnischen Umsetzung betrieblicher Personalprozesse',
      en: 'Self-initiated project exploring enterprise HR workflows and data-dense frontend architecture',
      fr: 'Projet autonome explorant les flux RH en entreprise et les architectures frontend denses en données'
    },
    summary: {
      de: 'Strukturiertes HR-Dashboard für Mitarbeiterverwaltung, Urlaubsanträge und Team-Übersichten mit optimierten Tabellenzuständen.',
      en: 'Clean enterprise HR dashboard for employee records, leave approvals, and department schedules with dense data-table optimization.',
      fr: 'Tableau de bord RH structuré pour la gestion des collaborateurs, congés et équipes, optimisé pour les données denses.'
    },
    overview: {
      de: 'HR-Tools sind oft überladen und träge in der Bedienung. Dieses Projekt setzt den Fokus auf einen schnellen, fehlerfreien Workflow: Personalverantwortliche können Mitarbeiterakten durchsuchen, Abwesenheitsanträge mit einem Klick genehmigen oder ablehnen und den Status von Abteilungen auf einen Blick erfassen.',
      en: 'Enterprise HR tools are frequently cumbersome and sluggish. This project focuses on high-efficiency, error-free workflows: HR managers can filter employee directories, process leave approvals with a single click, and assess department attendance at a glance.',
      fr: 'Les outils RH sont souvent lourds et complexes. Ce projet privilégie l’efficacité opérationnelle : recherche rapide de collaborateurs, validation de congés en un clic et visualisation claire des effectifs par pôle.'
    },
    audienceAndContext: {
      de: 'Personalabteilungen und Teamleiter in mittelständischen Unternehmen.',
      en: 'HR specialists, department leads, and operations managers in mid-sized organizations.',
      fr: 'Responsables RH, managers d’équipe et gestionnaires administratifs en entreprise.'
    },
    challenge: {
      de: 'Hohe Datendichte auf Desktop-Bildschirmen übersichtlich zu halten, ohne den Nutzer mit endlosen Modal-Fenstern zu blockieren.',
      en: 'Displaying dense tabular records cleanly while preventing modal fatigue and maintaining fast inline actions.',
      fr: 'Présenter des données tabulaires riches avec clarté tout en limitant les fenêtres modales superflues.'
    },
    constraints: [
      {
        de: 'Schnelle Tabellennavigation und Tastaturunterstützung',
        en: 'Fast tabular filtering and keyboard shortcut support',
        fr: 'Filtrage rapide et prise en charge des raccourcis clavier'
      },
      {
        de: 'Eindeutige Statusanzeigen für Genehmigungsprozesse (Genehmigt, Ausstehend, Abgelehnt)',
        en: 'Explicit semantic indicators for approval workflows (Approved, Pending, Declined)',
        fr: 'Indicateurs de statut explicites pour les validations (Validé, En attente, Refusé)'
      }
    ],
    userFlowAndArchitecture: {
      de: 'Zentrales Master-Detail-Layout: Linke Hauptnavigation für Funktionsbereiche, interaktive Filterleiste für Abteilungen und Schnellaktionen direkt in der Datenzeile ohne Seitenwechsel.',
      en: 'Master-detail layout architecture: Persistent sidebar navigation, responsive multi-attribute table filters, and inline contextual action trays preventing screen jumps.',
      fr: 'Architecture maître-détail : menu latéral persistant, filtrage multi-critères en temps réel et tiroir d’actions rapides en ligne évitant les rechargements.'
    },
    designDecisions: [
      {
        title: {
          de: 'Tabellen mit Inline-Aktionen statt verschachtelter Menüs',
          en: 'Inline Quick Actions over Nested Context Menus',
          fr: 'Actions Directes en Ligne plutôt que Menus Enfouis'
        },
        problem: {
          de: 'Klassische HR-Tools erfordern 3 bis 4 Klicks pro Genehmigung.',
          en: 'Traditional HR software requires multiple clicks to approve routine requests.',
          fr: 'Les logiciels RH traditionnels imposent 3 à 4 clics pour une simple validation.'
        },
        solution: {
          de: 'Direkte Schnellaktions-Leiste bei Zeilenfokus und Tastaturbedienung.',
          en: 'Exposed immediate action triggers on row hover/focus with single-keystroke confirmation.',
          fr: 'Actions directes visibles au survol ou focus clavier pour valider immédiatement.'
        },
        impact: {
          de: 'Erhebliche Zeitersparnis bei der täglichen Bearbeitung von Personalanträgen.',
          en: 'Substantial time savings during daily administrative processing.',
          fr: 'Gain de temps significatif lors du traitement quotidien des demandes.'
        }
      }
    ],
    implementationDetails: [
      {
        de: 'Umsetzung mit modernen Frontend-Technologien (React/TypeScript, Tailwind CSS, strukturierte Datenmodelle).',
        en: 'Built with React, TypeScript, Tailwind CSS, and strict state models.',
        fr: 'Réalisé avec React, TypeScript, Tailwind CSS et des modèles de données rigoureux.'
      },
      {
        de: 'Optimierte Render-Leistung für umfangreiche Tabellen.',
        en: 'Optimized render cycles and tab index navigation for tabular data.',
        fr: 'Optimisation des cycles de rendu et navigation séquentielle accessible.'
      }
    ],
    resultsAndObservations: [
      {
        de: 'Voll funktionsfähiger Dashboard-Prototyp mit responsivem Verhalten und konsistenten Komponenten.',
        en: 'Fully functional dashboard prototype with cohesive component styling and responsive states.',
        fr: 'Prototype de tableau de bord entièrement fonctionnel avec composants cohérents.'
      }
    ],
    lessonsLearned: {
      de: 'Datenintensive Benutzeroberflächen leben von präziser Typografie und dezenten Kontrasten statt dekorativen Grafiken.',
      en: 'Data-dense user interfaces rely on typographic rigor and subtle contrast over decorative embellishments.',
      fr: 'Les interfaces riches en données reposent sur la rigueur typographique et non sur l’artifice visuel.'
    },
    nextImprovements: {
      de: 'Anbindung an eine standardisierte REST-API und Exportfunktion für PDF-Berichte.',
      en: 'Integration with a standardized REST backend and export features for monthly reports.',
      fr: 'Connexion à une API REST standardisée et module d’exportation de rapports PDF.'
    },
    tags: ['Dashboard Design', 'Data Tables', 'React', 'TypeScript', 'Workflow Optimization'],
    image: '/src/assets/images/project_rh_manager_1792334376803.jpg'
  },
  {
    id: 'nova-trade',
    slug: 'nova-trade',
    title: 'Nova Trade B2B Platform',
    clientOrOrg: 'Trade Logistics Concept',
    category: 'ui-ux',
    categoryLabel: {
      de: 'B2B Interface & Bestellsystem',
      en: 'B2B Interface & Order System',
      fr: 'Interface B2B & Gestion des Commandes'
    },
    status: 'concept',
    statusLabel: {
      de: 'Konzeption & Wireframes',
      en: 'Concept & Wireframes',
      fr: 'Conception & Wireframes'
    },
    featured: false,
    timeline: '2024',
    role: {
      de: 'UI/UX Designer (Workflow-Analyse, Wireframes & Interaktionskonzept)',
      en: 'UI/UX Designer (Workflow Analysis, Wireframes & Interaction Concepts)',
      fr: 'Designer UI/UX (Analyse des flux, wireframes & ergonomie)'
    },
    teamContext: {
      de: 'Konzeptionelle Fallstudie zur Vereinfachung von B2B-Katalogbestellungen im Großhandel',
      en: 'Conceptual case study exploring order workflows in wholesale trade environments',
      fr: 'Étude de cas conceptuelle sur la simplification des commandes en gros B2B'
    },
    summary: {
      de: 'Klares Bestell- und Bestandsverwaltungskonzept für den B2B-Großhandel mit Fokus auf Massenbestellungen und SKU-Suche.',
      en: 'Clear B2B ordering and catalog management workflow designed for wholesale distributors handling high-SKU inventories.',
      fr: 'Concept de commande et gestion de catalogue B2B pensé pour les grossistes gérant d’importants volumes de références.'
    },
    overview: {
      de: 'Im B2B-Handel verbringen Einkäufer viel Zeit mit veralteten Tabellenkatalogen. Nova Trade untersucht, wie Großhandelskunden hunderte Artikel schnell per SKU oder Direktupload in den Warenkorb übernehmen und Lieferkonditionen transparent prüfen können.',
      en: 'Wholesale buyers lose hours navigating outdated catalog spreadsheets. Nova Trade explores how B2B purchasing agents can assemble multi-item orders quickly via SKU bulk entry and review tiered freight terms with clarity.',
      fr: 'Dans le commerce interentreprises, les acheteurs perdent du temps sur des catalogues obsolètes. Nova Trade propose une saisie rapide par référence (SKU) et une transparence totale sur les conditions de livraison.'
    },
    audienceAndContext: {
      de: 'Gewerbliche Einkäufer und Logistikverantwortliche im Groß- und Außenhandel.',
      en: 'Professional purchasing agents and logistics planners in wholesale trade.',
      fr: 'Acheteurs professionnels et responsables logistiques dans le commerce de gros.'
    },
    challenge: {
      de: 'Den Wechsel von fehleranfälligen E-Mail-/Faxbestellungen zu einem verlässlichen, selbsterklärenden Online-Portal zu ermöglichen.',
      en: 'Transitioning manual email and phone orders into a frictionless, self-service digital workflow.',
      fr: 'Faciliter la transition des commandes manuelles vers un portail web fiable et autonome.'
    },
    constraints: [
      {
        de: 'Möglichkeit schneller Stapelerfassung (Copy & Paste von Artikelnummern)',
        en: 'Support for fast bulk pasting of item SKUs and quantities',
        fr: 'Prise en charge du copier-coller en masse de listes de références'
      }
    ],
    userFlowAndArchitecture: {
      de: 'Zweistufiger Beschaffungspfad: Schnellerfassungs-Matrix mit Tabulatorsteuerung oder SKU-Direktsuche mit automatischer Verfügbarkeits- und Staffelpreisprüfung.',
      en: 'Two-tier procurement flow: Bulk matrix entry supporting keyboard tabbing or quick SKU lookups with live tiered-pricing and freight verification.',
      fr: 'Parcours d’achat optimisé : grille de saisie rapide au clavier ou recherche SKU directe avec validation instantanée des remises sur volume et du stock.'
    },
    designDecisions: [
      {
        title: {
          de: 'Schnellbestell-Matrix mit Tabulator-Weitersprung',
          en: 'Bulk Order Grid with Tab-Key Navigation',
          fr: 'Grille de Commande Rapide avec Tabulation'
        },
        problem: {
          de: 'Herkömmliche E-Commerce-Warenkörbe sind für 50+ Positionen zu langsam.',
          en: 'Traditional e-commerce carts are too cumbersome for 50+ item commercial orders.',
          fr: 'Les paniers e-commerce classiques sont trop lents pour des commandes de plus de 50 lignes.'
        },
        solution: {
          de: 'Tabellenartige Schnelleingabe mit automatischer Artikel-Validierung.',
          en: 'Spreadsheet-like inline entry matrix with instantaneous SKU verification.',
          fr: 'Matrice de saisie fluide avec vérification instantanée des références.'
        },
        impact: {
          de: 'Signifikant schnellere Auftragserfassung für Stammkunden.',
          en: 'Significantly reduced ordering turnaround for recurring commercial clients.',
          fr: 'Saisie de commande considérablement accélérée pour les clients récurrents.'
        }
      }
    ],
    implementationDetails: [
      {
        de: 'Wireframes und interaktive Screen-Abläufe in Figma dokumentiert.',
        en: 'Detailed wireframes and interactive screen states documented in Figma.',
        fr: 'Wireframes complets et enchaînements d’écrans documentés sur Figma.'
      }
    ],
    resultsAndObservations: [
      {
        de: 'Konzeptioneller Nachweis für benutzerfreundliche B2B-Prozesse ohne unnötigen Ballast.',
        en: 'Conceptual demonstration of frictionless B2B workflows stripped of consumer fluff.',
        fr: 'Démonstration conceptuelle d’un flux B2B épuré et immédiatement efficace.'
      }
    ],
    lessonsLearned: {
      de: 'B2B-Nutzer suchen keine Werbebanner, sondern maximale Effizienz und Verlässlichkeit.',
      en: 'B2B users do not want flashy promotional banners; they value speed, accuracy, and reliability.',
      fr: 'Les professionnels recherchent la rapidité et la fiabilité, pas les artifices marketing.'
    },
    nextImprovements: {
      de: 'Interaktive Prototypentests mit realen Einkaufslisten und ERP-Schnittstellen-Entwurf.',
      en: 'User testing sessions with live purchase orders and ERP data schema mapping.',
      fr: 'Tests utilisateurs avec des bons de commande réels et modélisation ERP.'
    },
    tags: ['B2B UI', 'Workflow Optimization', 'Wireframing', 'Bulk Ordering'],
    image: '/src/assets/images/project_rh_manager_1792334376803.jpg'
  }
];

export const visualExplorations: VisualExploration[] = [
  {
    id: 'exp-1',
    title: {
      de: 'Accessible Data Table System',
      en: 'Accessible Data Table System',
      fr: 'Système de Tableau de Données Accessible'
    },
    type: {
      de: 'UI Component Architecture',
      en: 'UI Component Architecture',
      fr: 'Architecture Composants UI'
    },
    description: {
      de: 'Untersuchung von Tabular-Numerals, Fokus-Ringen und dynamischer Spaltenanordnung für hohe Informationsdichte.',
      en: 'Exploration of tabular numerals, focus indicators, and dynamic column packing for dense enterprise layouts.',
      fr: 'Étude des chiffres tabulaires, indicateurs de focus et agencement dense pour applications métier.'
    },
    tools: ['React', 'Tailwind CSS', 'Figma Tokens'],
    previewAccent: '#2563EB'
  },
  {
    id: 'exp-2',
    title: {
      de: 'Dual-Language Navigation Switcher',
      en: 'Dual-Language Navigation Switcher',
      fr: 'Sélecteur de Langue & RTL/LTR'
    },
    type: {
      de: 'Interaction & Micro-Flow',
      en: 'Interaction & Micro-Flow',
      fr: 'Interaction & Micro-Expérience'
    },
    description: {
      de: 'Kompaktes Umschaltelement mit sanftem Zustandserhalt und klarer Tastaturfokussierung ohne Layout-Sprünge.',
      en: 'Compact switcher retaining locale state smoothly without layout shift or keyboard disorientation.',
      fr: 'Composant de bascule fluide conservant l’état sans saccade visuelle ni perte de focus.'
    },
    tools: ['CSS Transitions', 'TypeScript'],
    previewAccent: '#0D9488'
  },
  {
    id: 'exp-3',
    title: {
      de: 'Editorial Type Ramp & Spacing Tokens',
      en: 'Editorial Type Ramp & Spacing Tokens',
      fr: 'Échelle Typographique & Tokens d’Espacement'
    },
    type: {
      de: 'Design System Foundation',
      en: 'Design System Foundation',
      fr: 'Fondations Design System'
    },
    description: {
      de: 'Entwicklung eines harmonischen typografischen Rasters für mehrsprachige Benutzeroberflächen.',
      en: 'Harmonious typographic ramp balancing legibility across German, French, and English prose.',
      fr: 'Échelle typographique assurant équilibre et lisibilité en allemand, français et anglais.'
    },
    tools: ['Figma', 'Tailwind Config'],
    previewAccent: '#4F46E5'
  }
];
