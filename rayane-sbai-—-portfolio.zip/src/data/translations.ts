import { ExperienceItem, SkillCategory } from '../types/portfolio';

export const siteTranslations = {
  nav: {
    home: { de: 'Startseite', en: 'Home', fr: 'Accueil' },
    projects: { de: 'Projekte', en: 'Projects', fr: 'Projets' },
    about: { de: 'Über mich', en: 'About', fr: 'À propos' },
    contact: { de: 'Kontakt', en: 'Contact', fr: 'Contact' },
    cv: { de: 'Lebenslauf', en: 'CV', fr: 'CV' },
    viewProjects: { de: 'Projekte ansehen', en: 'View projects', fr: 'Voir les projets' },
    downloadCv: { de: 'CV ansehen / herunterladen', en: 'View / Download CV', fr: 'Consulter / Télécharger le CV' }
  },
  hero: {
    title: {
      de: 'Digitale Ideen. Klar gestaltet. Zum Leben gebracht.',
      en: 'Digital ideas. Clearly crafted. Brought to life.',
      fr: 'Idées numériques. Claires. Portées à la vie.'
    },
    role: {
      de: 'Rayane Sbai — UI/UX Designer & Frontend Developer',
      en: 'Rayane Sbai — UI/UX Designer & Frontend Developer',
      fr: 'Rayane Sbai — Designer UI/UX & Développeur Frontend'
    },
    intro: {
      de: 'Ich gestalte benutzerfreundliche digitale Oberflächen und setze Webprojekte um. Dabei verbinde ich UX/UI Design, Frontend-Entwicklung und moderne Tools. Ich möchte meine Erfahrungen in einem Team einbringen, Neues lernen und mich beruflich in Deutschland weiterentwickeln.',
      en: 'I design user-friendly digital interfaces and build web experiences. Combining UX/UI design, frontend development and modern tools, I want to contribute to a team, keep learning and grow professionally in Germany.',
      fr: 'Je conçois des interfaces numériques intuitives et développe des expériences web. En associant UX/UI design, développement frontend et outils modernes, je souhaite contribuer à une équipe, continuer à apprendre et évoluer professionnellement en Allemagne.'
    },
    supportingLine: {
      de: 'Offen für einen Berufseinstieg oder eine Ausbildung im digitalen Bereich in Deutschland.',
      en: 'Open for junior employment or an Ausbildung in digital design & development in Germany.',
      fr: 'Ouvert à un premier emploi ou à une formation en alternance (Ausbildung) dans le numérique en Allemagne.'
    },
    locationBadge: {
      de: 'Standort: Marokko · Bereit für Umzug nach Deutschland',
      en: 'Location: Morocco · Ready to relocate to Germany',
      fr: 'Localisation : Maroc · Prêt pour une mobilité en Allemagne'
    },
    quickHighlights: {
      focus1: { de: 'UX/UI & Informationsarchitektur', en: 'UX/UI & Information Architecture', fr: 'UX/UI & Architecture de l’info' },
      focus2: { de: 'Frontend mit React & Tailwind', en: 'Frontend with React & Tailwind', fr: 'Frontend avec React & Tailwind' },
      focus3: { de: 'Deutsch B1 in Vorbereitung', en: 'German B1 in preparation', fr: 'Allemand B1 en préparation' }
    }
  },
  sections: {
    featuredProjects: {
      kicker: { de: 'Ausgewählte Arbeiten', en: 'Selected Works', fr: 'Projets Sélectionnés' },
      title: { de: 'Praktische Design- und Web-Projekte', en: 'Practical Design & Web Implementations', fr: 'Projets Concrets de Design & Web' },
      description: {
        de: 'Echte Aufgabenstellungen: Von Informationsarchitektur und Nutzerführung bis hin zur Frontend-Realisierung.',
        en: 'Real problem-solving: From information architecture and user flows to responsive frontend builds.',
        fr: 'Cas concrets : De l’architecture de l’information à l’intégration frontend soignée.'
      },
      allProjectsLink: { de: 'Alle Projekte durchsuchen', en: 'Explore all projects', fr: 'Explorer tous les projets' }
    },
    whatIDo: {
      kicker: { de: 'Kompetenzbereiche', en: 'Core Disciplines', fr: 'Domaines d’Intervention' },
      title: { de: 'Was ich gestalte und umsetze', en: 'What I design and implement', fr: 'Ce que je conçois et réalise' },
      items: [
        {
          num: '01',
          title: { de: 'UX/UI Design', en: 'UX/UI Design', fr: 'Design UX/UI' },
          desc: {
            de: 'Analyse von Nutzerbedürfnissen, UX-Audits, Strukturierung von Informationsarchitekturen, Erstellung von Wireframes und interaktiven Figma-Prototypen mit klarem Designsystem.',
            en: 'User needs analysis, UX audits, structured information architectures, wireframes, and interactive Figma prototypes governed by clean design systems.',
            fr: 'Analyse des besoins utilisateurs, audits UX, architectures de l’information, wireframes et prototypes interactifs Figma régis par un design system cohérent.'
          },
          points: [
            { de: 'Nutzerführung & User Flows', en: 'User journeys & task flows', fr: 'Parcours et flux utilisateurs' },
            { de: 'Barrierefreie Typografie & Kontraste', en: 'Accessible typography & contrasts', fr: 'Typographie accessible et contrastes' },
            { de: 'Interaktive Prototypen in Figma', en: 'Interactive Figma prototypes', fr: 'Prototypes interactifs Figma' }
          ]
        },
        {
          num: '02',
          title: { de: 'Frontend Development', en: 'Frontend Development', fr: 'Développement Frontend' },
          desc: {
            de: 'Umsetzung sauberer, responsiver Weboberflächen mit modernem HTML, CSS/Tailwind, JavaScript und React. Fokus auf Performance, Barrierefreiheit und Wartbarkeit.',
            en: 'Crafting clean, responsive web interfaces using modern HTML, CSS/Tailwind, JavaScript, and React. Focused on performance, accessibility, and maintainable code.',
            fr: 'Intégration d’interfaces web soignées et réactives avec HTML moderne, CSS/Tailwind, JavaScript et React. Accent sur la fluidité et l’accessibilité.'
          },
          points: [
            { de: 'Responsive Layouts für alle Geräte', en: 'Responsive layouts across viewports', fr: 'Mises en page réactives tous écrans' },
            { de: 'Komponentenbasierte Architektur', en: 'Component-driven architecture', fr: 'Architecture modulaire par composants' },
            { de: 'Saubere Übergabe vom Design zum Code', en: 'Clean design-to-code translation', fr: 'Passerelle fluide du design au code' }
          ]
        },
        {
          num: '03',
          title: { de: 'No-Code & Website Implementation', en: 'No-Code & Site Implementation', fr: 'No-Code & Intégration de Sites' },
          desc: {
            de: 'Schnelle Realisierung von performanten Webseiten und Landingpages mit WordPress, Elementor und Framer für pragmatische und kundenorientierte Lösungen.',
            en: 'Fast turnaround of solid websites and landing pages using WordPress, Elementor, and Framer for practical, deadline-focused client requirements.',
            fr: 'Déploiement rapide de sites web et pages d’atterrissage avec WordPress, Elementor et Framer pour des solutions agiles et efficaces.'
          },
          points: [
            { de: 'WordPress & Elementor Strukturierung', en: 'WordPress & Elementor structuring', fr: 'Structuration WordPress & Elementor' },
            { de: 'Framer Layouts & Interaktionen', en: 'Framer layouts & interactive motion', fr: 'Mises en page Framer & micro-animations' },
            { de: 'SEO-Grundlagen & Ladezeit-Optimierung', en: 'Foundational SEO & speed tuning', fr: 'Bases SEO et optimisation de vitesse' }
          ]
        }
      ]
    },
    howIWork: {
      kicker: { de: 'Arbeitsweise', en: 'Methodology', fr: 'Méthodologie' },
      title: { de: 'Wie ich denke und arbeite', en: 'How I think and collaborate', fr: 'Comment je pense et collabore' },
      subtitle: {
        de: 'Vier klare Phasen von der ersten Anforderung bis zum fertigen digitalen Ergebnis.',
        en: 'Four structured stages from initial project brief to polished digital execution.',
        fr: 'Quatre étapes structurées du brief initial au résultat interactif final.'
      },
      steps: [
        {
          num: '01',
          name: { de: 'Verstehen', en: 'Understand', fr: 'Comprendre' },
          summary: {
            de: 'Zuhören, Zielgruppen analysieren und Kernprobleme präzise definieren. Keine voreiligen Annahmen.',
            en: 'Listen closely, analyze target user needs, and define the core problem without premature assumptions.',
            fr: 'Écouter, analyser les besoins utilisateurs et cerner le problème central sans présupposés.'
          }
        },
        {
          num: '02',
          name: { de: 'Gestalten', en: 'Design', fr: 'Concevoir' },
          summary: {
            de: 'Informationsarchitektur ordnen, Wireframes skizzieren und ein konsistentes Designsystem aufbauen.',
            en: 'Structure information architecture, sketch wireframes, and establish consistent visual design systems.',
            fr: 'Organiser l’architecture de l’information, tracer les wireframes et bâtir un design system cohérent.'
          }
        },
        {
          num: '03',
          name: { de: 'Implementieren', en: 'Implement', fr: 'Implémenter' },
          summary: {
            de: 'Sauberen, responsiven Code schreiben. Komponenten nachvollziehbar strukturieren und testen.',
            en: 'Write clean, responsive markup and code. Build modular components and verify cross-device behavior.',
            fr: 'Rédiger un code propre et réactif. Structurer les composants et valider le comportement multi-écrans.'
          }
        },
        {
          num: '04',
          name: { de: 'Verbessern', en: 'Improve', fr: 'Améliorer' },
          summary: {
            de: 'Feedback einholen, Barrierefreiheit überprüfen und Details kontinuierlich iterieren.',
            en: 'Solicit stakeholder feedback, audit accessibility contrast, and iterate on edge-case interactions.',
            fr: 'Recueillir les retours, vérifier l’accessibilité et itérer pour peaufiner chaque détail.'
          }
        }
      ]
    },
    aiWorkflow: {
      kicker: { de: 'Transparenz im Prozess', en: 'Process Transparency', fr: 'Transparence du Processus' },
      title: { de: 'KI-gestützte Entwicklung — Ehrlich erklärt', en: 'AI-Assisted Workflow — Transparently Explained', fr: 'Flux de Travail Assisté par IA — En Toute Transparence' },
      desc: {
        de: 'Ich nutze moderne KI-Werkzeuge gezielt zur Beschleunigung von Ideenfindung, Boilerplate-Erstellung und Fehlersuche. Die Verantwortung für Designentscheidungen, Informationsarchitektur, Codequalität und Nutzerführung liegt immer bei mir.',
        en: 'I leverage modern AI tools to accelerate ideation, scaffold initial code, and troubleshoot bugs. Crucially, all design decisions, architectural choices, code review, and accessibility checks remain strictly under my manual evaluation.',
        fr: 'J’utilise les outils d’IA modernes pour accélérer la recherche, générer des squelettes de code et faciliter le débogage. Toutes les décisions de conception, l’architecture, la revue de code et l’accessibilité sont rigoureusement vérifiées par mes soins.'
      },
      points: [
        { de: 'Schnellere Exploration verschiedener Layout-Ansätze', en: 'Rapid exploration of layout variations', fr: 'Exploration rapide de variantes de mise en page' },
        { de: 'Manuelle Verifikation aller HTML/CSS-Standards', en: 'Manual verification of all web standards', fr: 'Vérification manuelle de tous les standards web' },
        { de: 'Fokus auf echte Benutzerfreundlichkeit statt Trend-Hypes', en: 'Emphasis on genuine usability over aesthetic hype', fr: 'Priorité à la véritable ergonomie sur les effets de mode' }
      ]
    },
    opportunity: {
      kicker: { de: 'Bereit für den nächsten Schritt', en: 'Ready for the Next Step', fr: 'Prêt pour la Prochaine Étape' },
      title: {
        de: 'Sie suchen Unterstützung für Ihr Team oder bieten einen Ausbildungsplatz im digitalen Bereich an? Ich freue mich darauf, Sie kennenzulernen.',
        en: 'Looking for support for your team or offering an Ausbildung in digital design or web development? I look forward to connecting with you.',
        fr: 'Vous recherchez un renfort pour votre équipe ou proposez une place d’Ausbildung dans le numérique ? Au plaisir d’échanger avec vous.'
      },
      body: {
        de: 'Ich bringe fundierte Grundlagen im UX/UI Design, praktische Projekterfahrung und eine hohe Motivation mit, mich kontinuierlich in moderne Frontend-Technologien und deutsche Arbeitsabläufe einzuarbeiten. Gerne stelle ich mich in einem persönlichen Online-Gespräch vor.',
        en: 'I combine solid UX/UI design foundations, practical project experience, and high drive to adapt to modern frontend technologies and German workplace workflows. I would be delighted to introduce myself in a virtual interview.',
        fr: 'J’apporte de solides bases en design UX/UI, des expériences projets concrètes et une forte motivation à approfondir les technologies frontend modernes et les méthodes de travail allemandes. Je serais ravi d’échanger lors d’un entretien en visioconférence.'
      },
      locationLabel: {
        de: 'Standort: Marokko · Bereit für einen Umzug nach Deutschland',
        en: 'Location: Morocco · Ready to relocate to Germany',
        fr: 'Localisation : Maroc · Prêt pour une mobilité vers l’Allemagne'
      },
      ctaContact: { de: 'Kontakt aufnehmen', en: 'Get in touch', fr: 'Prendre contact' },
      ctaCv: { de: 'Lebenslauf herunterladen', en: 'Download CV', fr: 'Télécharger le CV' }
    }
  },
  caseStudy: {
    backToProjects: { de: '← Zurück zur Projektübersicht', en: '← Back to projects', fr: '← Retour aux projets' },
    role: { de: 'Meine Rolle', en: 'My Role', fr: 'Mon Rôle' },
    team: { de: 'Team & Kontext', en: 'Team & Context', fr: 'Équipe & Contexte' },
    status: { de: 'Projektstatus', en: 'Project Status', fr: 'Statut du Projet' },
    timeline: { de: 'Zeitraum', en: 'Timeline', fr: 'Période' },
    client: { de: 'Organisation / Kontext', en: 'Organization / Context', fr: 'Organisation / Contexte' },
    challengeTitle: { de: 'Die Herausforderung', en: 'The Challenge', fr: 'Le Défi' },
    constraintsTitle: { de: 'Rahmenbedingungen & Vorgaben', en: 'Constraints & Boundaries', fr: 'Contraintes & Cadre' },
    researchTitle: { de: 'Erkenntnisse & Beobachtungen', en: 'Observations & Research', fr: 'Observations & Recherche' },
    architectureTitle: { de: 'Informationsarchitektur & Nutzerführung', en: 'Information Architecture & Flows', fr: 'Architecture de l’Information & Flux' },
    decisionsTitle: { de: 'Zentrale Designentscheidungen', en: 'Key Design Decisions', fr: 'Décisions Clés de Conception' },
    implementationTitle: { de: 'Umsetzungsdetails', en: 'Implementation Details', fr: 'Détails d’Intégration' },
    resultsTitle: { de: 'Ergebnisse & verifizierte Beobachtungen', en: 'Outcomes & Validated Observations', fr: 'Résultats & Observations Validées' },
    lessonsTitle: { de: 'Was ich gelernt habe', en: 'Lessons Learned', fr: 'Enseignements Clés' },
    nextStepsTitle: { de: 'Nächste geplante Optimierungen', en: 'Next Improvements', fr: 'Prochaines Pistes d’Amélioration' },
    nextProject: { de: 'Nächstes Projekt ansehen →', en: 'View next project →', fr: 'Voir le projet suivant →' },
    viewFigma: { de: 'Figma-Design ansehen', en: 'View in Figma', fr: 'Voir sur Figma' },
    viewLive: { de: 'Live-Demo aufrufen', en: 'Open Live Demo', fr: 'Ouvrir la démo' },
    viewGithub: { de: 'Code auf GitHub', en: 'Code on GitHub', fr: 'Code sur GitHub' }
  },
  about: {
    introHeading: {
      de: 'Über mich',
      en: 'About Me',
      fr: 'À Propos de Moi'
    },
    introLead: {
      de: 'Ich bin Rayane Sbai, UI/UX Designer und Frontend Developer aus Marokko. Ich habe eine Ausbildung im Bereich UX Design abgeschlossen und praktische Erfahrungen in digitalen Projekten gesammelt.\n\nMich interessiert besonders, wie aus einer Idee eine verständliche und funktionierende Website entsteht. Ich arbeite gerne im Team, nehme Feedback an und entwickle meine Fähigkeiten kontinuierlich weiter.\n\nFür meinen nächsten beruflichen Schritt suche ich eine passende Stelle oder einen Ausbildungsplatz in Deutschland.',
      en: 'I am Rayane Sbai, a UI/UX Designer and Frontend Developer from Morocco. I completed a specialized diploma in UX Design and gained hands-on experience on real-world digital projects.\n\nWhat drives me is transforming conceptual ideas into intuitive, functional web experiences. I thrive in collaborative team environments, welcome feedback, and continuously expand my skill set.\n\nFor my next professional step, I am seeking a Junior position or an Ausbildung in Germany.',
      fr: 'Je suis Rayane Sbai, Designer UI/UX et Développeur Frontend basé au Maroc. Titulaire d’un diplôme spécialisé en Design UX, j’ai acquis une expérience concrète au travers de projets numériques variés.\n\nCe qui me passionne, c’est de transformer une idée en une interface web fluide et fonctionnelle. J’apprécie le travail en équipe, j’écoute les retours et j’approfondis sans cesse mes compétences.\n\nPour ma prochaine étape professionnelle, je recherche un premier poste ou une place d’Ausbildung en Allemagne.'
    },
    educationTitle: { de: 'Ausbildung & Qualifikation', en: 'Education & Qualification', fr: 'Formation & Diplômes' },
    experienceTitle: { de: 'Praktische Projekterfahrung', en: 'Practical Experience & Projects', fr: 'Expériences & Projets Pratiques' },
    skillsTitle: { de: 'Fachliche Kompetenzen', en: 'Core Competencies', fr: 'Compétences Techniques' },
    languagesTitle: { de: 'Sprachkenntnisse', en: 'Languages', fr: 'Langues' },
    goalsTitle: { de: 'Berufliches Ziel in Deutschland', en: 'Professional Goal in Germany', fr: 'Objectif Professionnel en Allemagne' },
    goalsText: {
      de: 'Ziel ist der Einstieg in ein deutsches Digitalunternehmen — entweder über eine fundierte Ausbildung (z.B. Mediengestalter Digital & Print, Fachinformatiker für Anwendungsentwicklung) oder eine Junior-Position im UX/UI- oder Frontend-Bereich. Ein Visum- und Umzugsprozess wird aktiv vorbereitet.',
      en: 'My objective is joining an innovative company in Germany — either through a structured dual Ausbildung (such as Mediengestalter Digital & Print or Fachinformatiker) or an entry-level Junior UX/UI / Frontend role. Visa and relocation logistics are being actively prepared.',
      fr: 'Mon objectif est d’intégrer une entreprise en Allemagne — soit par une formation en alternance (Ausbildung), soit par un poste junior en UX/UI ou Frontend. Les démarches de visa et de mobilité sont activement préparées.'
    }
  },
  contact: {
    title: { de: 'Kontakt aufnehmen', en: 'Get in Touch', fr: 'Prendre Contact' },
    subtitle: {
      de: 'Sie haben eine offene Position, einen Ausbildungsplatz oder möchten mehr über meine bisherigen Arbeiten erfahren? Ich antworte verlässlich und zeitnah.',
      en: 'Have an open position, an Ausbildung opportunity, or want to discuss my project experience? I respond promptly and reliably.',
      fr: 'Vous avez une opportunité d’emploi, une place d’Ausbildung ou souhaitez échanger sur mes travaux ? Je réponds avec plaisir et réactivité.'
    },
    emailLabel: { de: 'E-Mail-Adresse', en: 'Email Address', fr: 'Adresse E-Mail' },
    copyEmail: { de: 'E-Mail kopieren', en: 'Copy Email', fr: 'Copier l’E-Mail' },
    copied: { de: 'Kopiert!', en: 'Copied!', fr: 'Copié !' },
    locationTitle: { de: 'Aktueller Standort', en: 'Current Location', fr: 'Localisation Actuelle' },
    locationValue: {
      de: 'Rabat, Marokko · Vollständige Reise- und Umzugsbereitschaft nach Deutschland',
      en: 'Rabat, Morocco · Full readiness to relocate to Germany',
      fr: 'Rabat, Maroc · Prêt à déménager en Allemagne'
    },
    form: {
      name: { de: 'Ihr Name', en: 'Your Name', fr: 'Votre Nom' },
      email: { de: 'Ihre E-Mail-Adresse', en: 'Your Email', fr: 'Votre Adresse E-Mail' },
      opportunityType: { de: 'Art der Anfrage', en: 'Inquiry Type', fr: 'Type de Demande' },
      typeOptions: {
        ausbildung: { de: 'Ausbildungsplatz in Deutschland', en: 'Ausbildung Opportunity (Germany)', fr: 'Place d’Ausbildung en Allemagne' },
        employment: { de: 'Junior-Stelle / Festanstellung', en: 'Junior Position / Employment', fr: 'Poste Junior / Emploi' },
        internship: { de: 'Praktikum', en: 'Internship', fr: 'Stage' },
        general: { de: 'Allgemeine Anfrage', en: 'General Inquiry', fr: 'Échange Général' }
      },
      message: { de: 'Ihre Nachricht', en: 'Your Message', fr: 'Votre Message' },
      send: { de: 'Nachricht senden', en: 'Send Message', fr: 'Envoyer le Message' },
      sending: { de: 'Wird übermittelt...', en: 'Sending...', fr: 'Envoi en cours...' },
      success: {
        de: 'Vielen Dank für Ihre Nachricht! Ich werde mich schnellstmöglich bei Ihnen melden.',
        en: 'Thank you for your message! I will reply to you as soon as possible.',
        fr: 'Merci pour votre message ! Je vous répondrai dans les plus brefs délais.'
      },
      error: {
        de: 'Bitte füllen Sie alle erforderlichen Felder aus.',
        en: 'Please complete all required fields.',
        fr: 'Veuillez remplir tous les champs obligatoires.'
      },
      directEmailHint: {
        de: 'Alternativ können Sie mir direkt eine E-Mail an rayanesbai667@gmail.com senden.',
        en: 'Alternatively, you can email me directly at rayanesbai667@gmail.com.',
        fr: 'Vous pouvez également m’écrire directement à rayanesbai667@gmail.com.'
      }
    }
  },
  cvModal: {
    title: { de: 'Lebenslauf von Rayane Sbai', en: 'Curriculum Vitae — Rayane Sbai', fr: 'Curriculum Vitae — Rayane Sbai' },
    subtitle: {
      de: 'Strukturierte Übersicht für Personalverantwortliche und Ausbildungsbetriebe',
      en: 'Structured overview for hiring managers and Ausbildung recruiters',
      fr: 'Synthèse structurée pour recruteurs et entreprises formatrices'
    },
    downloadPdf: { de: 'CV als PDF herunterladen', en: 'Download CV as PDF', fr: 'Télécharger le CV au format PDF' },
    print: { de: 'Drucken / PDF speichern', en: 'Print / Save as PDF', fr: 'Imprimer / Sauvegarder' },
    close: { de: 'Schließen', en: 'Close', fr: 'Fermer' }
  },
  checklist: {
    triggerButton: { de: 'Inhalts-Prüfliste & Transparenz', en: 'Content Integrity & Checklist', fr: 'Checklist & Intégrité' },
    title: { de: 'Transparenz & Verifizierte Angaben', en: 'Candidate Transparency & Verified Data', fr: 'Transparence & Données Vérifiées' },
    subtitle: {
      de: 'Gemäß den Richtlinien werden nur belegte Fakten dargestellt. Hier ist die Übersicht verifizierter Angaben und noch zu ergänzender Unterlagen.',
      en: 'In accordance with integrity guidelines, only verified facts are displayed. Here is the status of personal assets and documents.',
      fr: 'Seuls les faits attestés sont mis en avant. Voici l’état des éléments vérifiés et des pièces complémentaires.'
    },
    verifiedTitle: { de: 'Bestätigte und verifizierte Daten', en: 'Confirmed & Verified Information', fr: 'Informations Confirmées & Vérifiées' },
    missingTitle: { de: 'Zur finalen Bereitstellung durch Rayane', en: 'Checklist for Rayane to Supply', fr: 'Éléments à Fournir par Rayane' }
  },
  footer: {
    tagline: {
      de: 'Rayane Sbai — UI/UX Designer & Frontend Developer',
      en: 'Rayane Sbai — UI/UX Designer & Frontend Developer',
      fr: 'Rayane Sbai — Designer UI/UX & Développeur Frontend'
    },
    rights: {
      de: 'Alle Rechte vorbehalten.',
      en: 'All rights reserved.',
      fr: 'Tous droits réservés.'
    },
    location: {
      de: 'Marokko · Bereit für Deutschland',
      en: 'Morocco · Germany Bound',
      fr: 'Maroc · Prêt pour l’Allemagne'
    }
  }
};

export const verifiedExperiences: ExperienceItem[] = [
  {
    period: '2023 — 2024',
    role: {
      de: 'UX/UI Designer & Projektmitwirkung (Startup Hub Maroc)',
      en: 'UX/UI Designer & Project Contributor (Startup Hub Maroc)',
      fr: 'Designer UX/UI & Contributeur Projet (Startup Hub Maroc)'
    },
    organization: 'ADD (Agence de Développement du Digital)',
    location: 'Rabat, Marokko',
    type: {
      de: 'Praxisprojekt / Öffentlicher Sektor',
      en: 'Practical Project / Public Sector',
      fr: 'Projet Pratique / Secteur Public'
    },
    description: {
      de: 'Durchführung eines UX-Audits der bestehenden Plattform, Neukonzeption der Informationsarchitektur für Startups und Partner sowie Erstellung von Figma-Prototypen.',
      en: 'Executed UX audit on the existing portal, redesigned directory information architecture for startups and accelerators, and crafted interactive Figma prototypes.',
      fr: 'Réalisation d’un audit UX, refonte de l’architecture de l’information de l’annuaire de startups et conception de prototypes Figma interactifs.'
    },
    highlights: [
      { de: 'UX-Audit des vorherigen Portalbestands', en: 'UX audit of existing portal catalog', fr: 'Audit UX de l’existant' },
      { de: 'Erstellung von Wireframes und interaktiven Komponenten', en: 'Wireframing & interactive component kit', fr: 'Wireframes et composants interactifs' },
      { de: 'Zusammenarbeit mit Fachabteilungen', en: 'Stakeholder cross-alignment', fr: 'Collaboration avec les parties prenantes' }
    ]
  },
  {
    period: '2024',
    role: {
      de: 'UI/UX & Frontend Co-Entwickler',
      en: 'UI/UX & Frontend Co-Developer',
      fr: 'Co-Développeur Frontend & UI/UX'
    },
    organization: 'Deutsch Maak',
    location: 'Rabat, Marokko',
    type: {
      de: 'Kollaboratives Teamprojekt',
      en: 'Collaborative Group Project',
      fr: 'Projet Collaboratif en Équipe'
    },
    description: {
      de: 'Konzeption und Frontend-Entwicklung einer interaktiven Web-App für das Erlernen der deutschen Grammatik. Speziell fokussiert auf nordafrikanische Lernende.',
      en: 'Conception and frontend development of an interactive web application for learning German grammar, tailored to North African students.',
      fr: 'Conception et intégration frontend d’une application d’apprentissage de la grammaire allemande adaptée aux apprenants maghrébins.'
    },
    highlights: [
      { de: 'Responsive Übungs- und Quiz-Interfaces', en: 'Responsive quiz & exercise interfaces', fr: 'Interfaces interactives de quiz et exercices' },
      { de: 'Komponenten mit HTML5, CSS & JavaScript', en: 'Components built with modern web tech', fr: 'Composants développés en HTML5, CSS et JS' },
      { de: 'Konstruktives Fehler-Feedback-System', en: 'Constructive contextual error feedback', fr: 'Système de retours contextuels sur les erreurs' }
    ]
  },
  {
    period: '2023 — 2024',
    role: {
      de: 'UI/UX Konzept & Modernisierung',
      en: 'UI/UX Concept & Portal Modernization',
      fr: 'Conception UI/UX & Modernisation'
    },
    organization: 'FOS-MATNUHPV',
    location: 'Rabat, Marokko',
    type: {
      de: 'Institutionelles Praxisprojekt',
      en: 'Institutional Practice Project',
      fr: 'Projet Pratique Institutionnel'
    },
    description: {
      de: 'Redesign-Konzept für das Stiftungsportal sozialer Dienste: Barrierefreie Gliederung von Beihilfen, Wohnungs- und Gesundheitsförderung.',
      en: 'Redesign concept for the civic social services portal: Accessible cataloging of healthcare benefits, housing allowances, and grants.',
      fr: 'Refonte conceptuelle du portail des œuvres sociales : structuration accessible des aides médicales, familiales et de logement.'
    },
    highlights: [
      { de: 'WCAG AA Kontrast- und Barrierefreiheitskonzept', en: 'WCAG AA accessibility and contrast design', fr: 'Accessibilité et contrastes conformes WCAG AA' },
      { de: 'Strukturierte Dienstleistungs-Kataloge', en: 'Structured public services catalog', fr: 'Catalogues de services publics simplifiés' }
    ]
  },
  {
    period: '2022 — 2024',
    role: {
      de: 'Ausbildung: Technicien Spécialisé en UX Design',
      en: 'Specialized Diploma in UX Design',
      fr: 'Diplôme de Technicien Spécialisé en UX Design'
    },
    organization: 'ISTA NTIC Rabat',
    location: 'Rabat, Marokko',
    type: {
      de: 'Staatliches Diplom / Berufsausbildung',
      en: 'State Technical Diploma / Vocational Program',
      fr: 'Diplôme d’État / Formation Professionnelle'
    },
    description: {
      de: 'Fundierte zweijährige Fachausbildung: Nutzerforschung, Usability-Audits, Design Thinking, Wireframing, interaktive Prototypen in Figma und Frontend-Grundlagen.',
      en: 'Comprehensive two-year vocational diploma: User research, usability audits, design thinking, wireframing, high-fidelity Figma prototyping, and frontend foundations.',
      fr: 'Formation professionnelle spécialisée de deux ans : recherche utilisateur, ergonomie, design thinking, wireframes, prototypage Figma et intégration web.'
    },
    highlights: [
      { de: 'Abschluss mit staatlichem Fachdiplom', en: 'Graduation with official specialized diploma', fr: 'Obtention du diplôme de technicien spécialisé' },
      { de: 'Schwerpunkt auf praxisnahen Digitalprojekten', en: 'Focus on applied real-world digital projects', fr: 'Orientation pratique sur projets numériques' }
    ]
  }
];

export const skillCategories: SkillCategory[] = [
  {
    id: 'ux',
    title: { de: 'UX Design & Konzeption', en: 'UX Design & Research', fr: 'Design UX & Recherche' },
    description: {
      de: 'Strukturierte Methoden, um Benutzerbedürfnisse zu verstehen und digitale Pfade klar zu gliedern.',
      en: 'Structured methodologies to analyze user requirements and shape intuitive task flows.',
      fr: 'Méthodologies structurées pour analyser les besoins et concevoir des parcours intuitifs.'
    },
    skills: [
      { name: 'User Needs Analysis', note: { de: 'Zielgruppenanalyse & Szenarien', en: 'Audience analysis & scenarios', fr: 'Analyse des publics cibles' } },
      { name: 'UX Audits', note: { de: 'Analyse bestehender Webseiten', en: 'Heuristic review of legacy sites', fr: 'Audit ergonomique de l’existant' } },
      { name: 'Information Architecture', note: { de: 'Sitemaps & Inhaltsbäume', en: 'Sitemaps & content taxonomies', fr: 'Sitemaps & arborescences' } },
      { name: 'User Flows & Wireframes', note: { de: 'Low- & Mid-Fidelity Skizzen', en: 'Low- & mid-fidelity wireframes', fr: 'Flux & wireframes basse-fidélité' } },
      { name: 'Accessibility (WCAG AA)', note: { de: 'Farbkontraste & Textlesbarkeit', en: 'Color contrast & readable hierarchy', fr: 'Contrastes et hiérarchie lisible' } }
    ]
  },
  {
    id: 'ui',
    title: { de: 'UI Design & Visual Systems', en: 'UI Design & Visual Systems', fr: 'Design UI & Systèmes Visuels' },
    description: {
      de: 'Ästhetisch präzise Oberflächen mit konsistenter Typografie, klaren Hierarchien und modularer Struktur.',
      en: 'Aesthetically refined interfaces featuring robust typography, clear hierarchy, and design tokens.',
      fr: 'Interfaces précises et soignées avec typographie maîtrisée et composants modulaires.'
    },
    skills: [
      { name: 'Figma & Auto Layout', note: { de: 'Komponenten & Varianten', en: 'Components, variants & tokens', fr: 'Composants, variantes et tokens' } },
      { name: 'Responsive Layouts', note: { de: 'Desktop & Mobile Viewports', en: 'Desktop & mobile viewports', fr: 'Mises en page desktop et mobile' } },
      { name: 'Typography & Hierarchy', note: { de: 'Typografische Rastersysteme', en: 'Type scales & line height tuning', fr: 'Échelles typographiques et rythme' } },
      { name: 'Design Tokens', note: { de: 'Farben, Spacing & Radien', en: 'Color palettes, spacing scales', fr: 'Couleurs, espacements et rayons' } },
      { name: 'Interactive Prototyping', note: { de: 'Micro-Interaktionen & Handoff', en: 'Micro-interactions & dev handoff', fr: 'Micro-interactions et passerelle dev' } }
    ]
  },
  {
    id: 'frontend',
    title: { de: 'Frontend Development', en: 'Frontend Development', fr: 'Développement Frontend' },
    description: {
      de: 'Solide Webstandards und moderne Frameworks für performante, fehlerfreie Benutzeroberflächen.',
      en: 'Rock-solid web standards and modern frameworks for performant, accessible interfaces.',
      fr: 'Standards du web rigoureux et frameworks modernes pour des interfaces fiables.'
    },
    skills: [
      { name: 'HTML5 & Semantic Markup', note: { de: 'Saubere Dokumentstruktur', en: 'Accessible semantic elements', fr: 'Structure sémantique accessible' } },
      { name: 'CSS3 & Tailwind CSS', note: { de: 'Utility-First Styling', en: 'Modern responsive utility CSS', fr: 'Styles réactifs et modernes' } },
      { name: 'JavaScript (ES6+) & TypeScript', note: { de: 'Typensichere Komponenten', en: 'Type-safe component logic', fr: 'Logique de composants typée' } },
      { name: 'React', note: { de: 'Hooks & modulares State Management', en: 'Hooks & component architecture', fr: 'Hooks et architecture modulaire' } },
      { name: 'Git & Version Control', note: { de: 'Branches, Commits & GitHub', en: 'Branching, PRs & GitHub', fr: 'Gestion de versions et branches' } }
    ]
  },
  {
    id: 'nocode',
    title: { de: 'No-Code & CMS Implementation', en: 'No-Code & CMS Implementation', fr: 'No-Code & CMS' },
    description: {
      de: 'Effiziente Umsetzung von Websites für Kunden mit schnellen Aktualisierungsbedürfnissen.',
      en: 'Rapid deployment of websites for clients requiring intuitive self-managed content.',
      fr: 'Déploiement rapide de sites web faciles à administrer par les clients.'
    },
    skills: [
      { name: 'WordPress', note: { de: 'Theme-Anpassung & Seitenstruktur', en: 'Theme setup & page structuring', fr: 'Configuration de thèmes et structure' } },
      { name: 'Elementor Pro', note: { de: 'Visuelle Modulgestaltung', en: 'Visual layout building', fr: 'Création modulaire visuelle' } },
      { name: 'Framer', note: { de: 'Landingpages & Animationen', en: 'Interactive landing pages', fr: 'Pages d’atterrissage interactives' } }
    ]
  },
  {
    id: 'collaboration',
    title: { de: 'Zusammenarbeit & Arbeitsweise', en: 'Collaboration & Soft Skills', fr: 'Collaboration & Méthodes' },
    description: {
      de: 'Verlässliche Kommunikation, Offenheit für konstruktives Feedback und kontinuierliche Lernbereitschaft.',
      en: 'Dependable communication, openness to feedback, and high motivation to learn continuously.',
      fr: 'Communication claire, écoute active des retours et volonté constante d’apprendre.'
    },
    skills: [
      { name: 'Team Player & Feedback-Kultur', note: { de: 'Konstruktiv & lösungsorientiert', en: 'Constructive & solution-oriented', fr: 'Constructif et orienté solutions' } },
      { name: 'Design Handoff', note: { de: 'Präzise Dokumentation für Entwickler', en: 'Thorough developer documentation', fr: 'Documentation claire pour développeurs' } },
      { name: 'Lernbereitschaft & Neugier', note: { de: 'Schnelle Einarbeitung in neue Tools', en: 'Rapid onboarding into new tools', fr: 'Assimilation rapide de nouveaux outils' } },
      { name: 'Ethischer KI-Einsatz', note: { de: 'Effizienztool mit menschlicher Prüfung', en: 'Speed booster with human verification', fr: 'Outil d’efficacité vérifié manuellement' } }
    ]
  }
];

export const verifiedLanguages = [
  {
    name: { de: 'Arabisch', en: 'Arabic', fr: 'Arabe' },
    level: { de: 'Muttersprache', en: 'Native Speaker', fr: 'Langue Maternelle' },
    indicator: '100%'
  },
  {
    name: { de: 'Französisch', en: 'French', fr: 'Français' },
    level: { de: 'Verhandlungssicher / C1', en: 'Full Professional Proficiency / C1', fr: 'Bilingue / C1' },
    indicator: '90%'
  },
  {
    name: { de: 'Englisch', en: 'English', fr: 'Anglais' },
    level: { de: 'Fließend in Wort & Schrift / B2–C1', en: 'Professional Working Proficiency / B2–C1', fr: 'Courant / B2–C1' },
    indicator: '85%'
  },
  {
    name: { de: 'Deutsch', en: 'German', fr: 'Allemand' },
    level: { de: 'B1 in Vorbereitung (Aktiv lernend)', en: 'B1 in progress (Active daily study)', fr: 'B1 en préparation (Étude active)' },
    indicator: '55%'
  }
];
