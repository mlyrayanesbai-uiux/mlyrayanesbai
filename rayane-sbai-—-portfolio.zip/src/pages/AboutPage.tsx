import React, { useState } from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { siteTranslations, verifiedExperiences, skillCategories, verifiedLanguages } from '../data/translations';
import { GraduationCap, Briefcase, Award, Languages, Compass, FileText, ArrowRight, UserCheck, ShieldCheck } from 'lucide-react';
import { AnimatedSection, AnimatedItem } from '../components/PageTransition';

export const AboutPage: React.FC = () => {
  const { locale, navigateTo, openCvModal, openChecklist } = usePortfolio();
  const [imgError, setImgError] = useState(false);
  const [imgLoaded, setImgLoaded] = useState(false);
  const t = siteTranslations.about;

  return (
    <div className="space-y-16 max-w-4xl mx-auto">
      
      {/* 1. Header with Portrait & Personal Introduction with entrance animation */}
      <AnimatedSection className="grid grid-cols-1 gap-8 md:grid-cols-12 md:items-center border-b border-stone-200 pb-12 dark:border-zinc-800">
        
        {/* Portrait Column with Hover zoom & shadow */}
        <div className="md:col-span-5">
          <div className="group relative aspect-4/3 sm:aspect-square w-full max-w-sm mx-auto overflow-hidden rounded-3xl border border-stone-200/90 bg-white/95 backdrop-blur-md p-2 shadow-lg hover:shadow-2xl hover:shadow-blue-500/10 hover:border-blue-500/50 hover:-translate-y-1 dark:border-zinc-800/90 dark:bg-zinc-900/90 dark:hover:border-blue-500/40 transition-all duration-300">
            <div className="relative h-full w-full overflow-hidden rounded-2xl bg-stone-100 dark:bg-zinc-800">
              {!imgError ? (
                <img
                  src="/src/assets/images/rayane_portrait_1792334375029.jpg"
                  alt="Rayane Sbai — UI/UX Designer & Frontend Developer"
                  referrerPolicy="no-referrer"
                  onLoad={() => setImgLoaded(true)}
                  onError={() => setImgError(true)}
                  className={`h-full w-full object-cover object-center transition-all duration-700 ease-out group-hover:scale-105 ${
                    imgLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-95'
                  }`}
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center text-stone-400 dark:text-zinc-600">
                  <UserCheck className="h-16 w-16 stroke-1" />
                </div>
              )}
              
              <div className="absolute bottom-2 left-2 right-2 rounded-xl bg-stone-900/80 backdrop-blur-xs px-3 py-1.5 text-[11px] text-white flex items-center justify-between border border-white/10">
                <span className="font-semibold">Rayane Sbai</span>
                <span className="font-mono text-[10px] text-blue-300">Rabat, MA ⇄ DE</span>
              </div>
            </div>
          </div>
        </div>

        {/* Introduction Text Column */}
        <div className="md:col-span-7 space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            <span>{t.introHeading[locale]}</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-stone-900 dark:text-white">
            Rayane Sbai
          </h1>

          <div className="space-y-3 text-sm sm:text-base leading-relaxed text-stone-600 dark:text-zinc-300 whitespace-pre-line">
            {t.introLead[locale]}
          </div>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={openCvModal}
              className="inline-flex items-center gap-1.5 rounded-xl bg-stone-900 px-5 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-stone-800 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-white transition-all cursor-pointer"
            >
              <FileText className="h-4 w-4" />
              <span>{siteTranslations.nav.downloadCv[locale]}</span>
            </button>

            <button
              type="button"
              onClick={() => navigateTo('contact')}
              className="inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-5 py-2.5 text-xs font-semibold text-stone-800 hover:border-stone-400 hover:bg-stone-50 hover:shadow-sm hover:-translate-y-0.5 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:border-zinc-600 transition-all cursor-pointer"
            >
              <span>{siteTranslations.nav.contact[locale]}</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>

      </AnimatedSection>

      {/* 2. Professional Goals in Germany with Hover Accent */}
      <AnimatedSection className="group rounded-2xl border border-blue-200/90 bg-blue-50/70 p-6 sm:p-8 hover:border-blue-400/80 hover:shadow-lg dark:border-blue-900/40 dark:bg-blue-950/25 dark:hover:border-blue-700/50 space-y-3 transition-all duration-300">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-700 dark:text-blue-300">
          <Compass className="h-4 w-4" />
          <span>{t.goalsTitle[locale]}</span>
        </div>
        <p className="text-sm sm:text-base text-blue-950 dark:text-blue-100 leading-relaxed">
          {t.goalsText[locale]}
        </p>
      </AnimatedSection>

      {/* 3. Verified Education & Vocational Qualification */}
      <AnimatedSection className="space-y-6">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
          <GraduationCap className="h-4 w-4" />
          <span>{t.educationTitle[locale]}</span>
        </div>

        <div className="group rounded-2xl border border-stone-200/90 bg-white/95 backdrop-blur-xs p-6 hover:-translate-y-1.5 hover:border-blue-500/50 hover:shadow-xl hover:shadow-blue-500/10 dark:border-zinc-800/90 dark:bg-zinc-900/70 dark:hover:border-blue-500/40 transition-all duration-300 space-y-2">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
            <h3 className="text-base font-bold text-stone-900 group-hover:text-blue-600 dark:text-zinc-100 dark:group-hover:text-blue-400 transition-colors">
              Diplôme de Technicien Spécialisé en UX Design
            </h3>
            <span className="font-mono text-xs text-stone-500 dark:text-zinc-400">
              2022 — 2024
            </span>
          </div>

          <div className="text-xs font-semibold text-blue-600 dark:text-blue-400">
            ISTA NTIC Rabat, Marokko
          </div>

          <p className="pt-2 text-xs sm:text-sm text-stone-600 dark:text-zinc-300 leading-relaxed">
            {locale === 'de'
              ? 'Fundierte zweijährige Fachausbildung mit staatlichem Diplom: Nutzerforschung, Heuristische Usability-Audits, Informationsarchitektur, Wireframing, interaktive Prototypen in Figma und Frontend-Entwicklung (HTML, CSS, JavaScript).'
              : locale === 'fr'
              ? 'Formation professionnelle spécialisée de deux ans validée par un diplôme d’État : recherche utilisateur, ergonomie web, architecture de l’information, wireframing, prototypage avancé sous Figma et intégration web.'
              : 'Comprehensive 2-year state technical diploma covering user research, usability heuristics, information architecture, wireframing, high-fidelity Figma prototyping, and responsive frontend foundations.'}
          </p>
        </div>
      </AnimatedSection>

      {/* 4. Practical Experience & Projects with Staggered Entrance & Hover */}
      <AnimatedSection className="space-y-6">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
          <Briefcase className="h-4 w-4" />
          <span>{t.experienceTitle[locale]}</span>
        </div>

        <div className="space-y-4">
          {verifiedExperiences.map((exp, idx) => (
            <AnimatedItem key={idx} delay={idx * 0.07}>
              <div
                className="group rounded-2xl border border-stone-200/90 bg-white/95 backdrop-blur-xs p-6 hover:-translate-y-1.5 hover:border-blue-500/50 hover:shadow-xl hover:shadow-blue-500/10 dark:border-zinc-800/90 dark:bg-zinc-900/70 dark:hover:border-blue-500/40 transition-all duration-300 space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <div>
                    <h3 className="text-base font-bold text-stone-900 group-hover:text-blue-600 dark:text-zinc-100 dark:group-hover:text-blue-400 transition-colors">
                      {exp.role[locale]}
                    </h3>
                    <div className="text-xs text-blue-600 dark:text-blue-400 font-medium">
                      {exp.organization} · {exp.location}
                    </div>
                  </div>

                  <div className="font-mono text-xs text-stone-500 dark:text-zinc-400">
                    {exp.period}
                  </div>
                </div>

                <p className="text-xs sm:text-sm text-stone-600 dark:text-zinc-300 leading-relaxed">
                  {exp.description[locale]}
                </p>

                <div className="pt-2 flex flex-wrap gap-2 text-xs text-stone-500 dark:text-zinc-400">
                  {exp.highlights.map((h, hIdx) => (
                    <span key={hIdx} className="inline-flex items-center gap-1.5">
                      <span className="h-1 w-1 rounded-full bg-blue-600 group-hover:scale-150 transition-transform" />
                      <span>{h[locale]}</span>
                    </span>
                  ))}
                </div>
              </div>
            </AnimatedItem>
          ))}
        </div>
      </AnimatedSection>

      {/* 5. Core Competencies & Skills with Hover Transform */}
      <AnimatedSection className="space-y-6">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
          <Award className="h-4 w-4" />
          <span>{t.skillsTitle[locale]}</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {skillCategories.map((cat, idx) => (
            <AnimatedItem key={cat.id} delay={idx * 0.08}>
              <div
                className="group h-full rounded-2xl border border-stone-200/90 bg-white/95 backdrop-blur-xs p-5 hover:-translate-y-1.5 hover:border-blue-500/50 hover:shadow-xl dark:border-zinc-800/90 dark:bg-zinc-900/70 dark:hover:border-blue-500/40 transition-all duration-300 space-y-3"
              >
                <h3 className="text-sm font-bold text-stone-900 group-hover:text-blue-600 dark:text-zinc-100 dark:group-hover:text-blue-400 transition-colors">
                  {cat.title[locale]}
                </h3>

                <p className="text-xs text-stone-500 dark:text-zinc-400 leading-relaxed">
                  {cat.description[locale]}
                </p>

                <div className="pt-2 space-y-1.5 border-t border-stone-100 dark:border-zinc-800 text-xs">
                  {cat.skills.map((skill, sIdx) => (
                    <div key={sIdx} className="flex items-center justify-between py-1 px-1.5 rounded-md hover:bg-blue-50/60 dark:hover:bg-zinc-800 transition-colors">
                      <span className="font-medium text-stone-800 dark:text-zinc-200">
                        {skill.name}
                      </span>
                      {skill.note && (
                        <span className="text-[11px] text-stone-500 dark:text-zinc-400">
                          {skill.note[locale]}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </AnimatedItem>
          ))}
        </div>
      </AnimatedSection>

      {/* 6. Languages with Hover Elevation */}
      <AnimatedSection className="space-y-6">
        <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
          <Languages className="h-4 w-4" />
          <span>{t.languagesTitle[locale]}</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {verifiedLanguages.map((lang, idx) => (
            <AnimatedItem key={idx} delay={idx * 0.06}>
              <div
                className="group rounded-2xl border border-stone-200/90 bg-white/95 backdrop-blur-xs p-4 hover:-translate-y-1 hover:border-blue-500/50 hover:shadow-lg dark:border-zinc-800/90 dark:bg-zinc-900/70 dark:hover:border-blue-500/40 transition-all duration-200 space-y-1"
              >
                <span className="text-xs font-bold text-stone-900 group-hover:text-blue-600 dark:text-zinc-100 dark:group-hover:text-blue-400 transition-colors block">
                  {lang.name[locale]}
                </span>
                <span className="text-xs text-blue-600 dark:text-blue-400 font-medium block">
                  {lang.level[locale]}
                </span>
              </div>
            </AnimatedItem>
          ))}
        </div>
      </AnimatedSection>

      {/* 7. Checklist / Transparency Callout with Hover Button */}
      <AnimatedSection className="rounded-2xl border border-stone-200 bg-stone-50/80 p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 dark:border-zinc-800 dark:bg-zinc-900/50 hover:border-blue-400/40 transition-all">
        <div className="space-y-1">
          <div className="text-xs font-bold text-stone-900 dark:text-zinc-100 flex items-center gap-1.5">
            <ShieldCheck className="h-4 w-4 text-blue-600" />
            <span>{siteTranslations.checklist.title[locale]}</span>
          </div>
          <p className="text-xs text-stone-600 dark:text-zinc-400">
            {siteTranslations.checklist.subtitle[locale]}
          </p>
        </div>

        <button
          type="button"
          onClick={openChecklist}
          className="rounded-xl border border-stone-300 bg-white px-4 py-2 text-xs font-semibold text-stone-800 hover:bg-stone-50 hover:shadow-sm hover:-translate-y-0.5 active:translate-y-0 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-200 whitespace-nowrap cursor-pointer transition-all"
        >
          {siteTranslations.checklist.triggerButton[locale]}
        </button>
      </AnimatedSection>

    </div>
  );
};
