import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, ExternalLink, Figma, Code, CheckCircle2, AlertCircle, Sparkles, FolderGit2 } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { projectsData } from '../data/projectsData';
import { siteTranslations } from '../data/translations';
import { AnimatedSection, AnimatedItem } from '../components/PageTransition';

interface CaseStudyPageProps {
  slug: string;
}

export const CaseStudyPage: React.FC<CaseStudyPageProps> = ({ slug }) => {
  const { locale, navigateTo } = usePortfolio();
  const [imgError, setImgError] = useState(false);
  const t = siteTranslations.caseStudy;

  const projectIndex = projectsData.findIndex((p) => p.slug === slug);
  const project = projectsData[projectIndex] || projectsData[0];

  // Next project navigation logic
  const nextProjectIndex = (projectIndex + 1) % projectsData.length;
  const nextProject = projectsData[nextProjectIndex];

  return (
    <article className="space-y-16 max-w-4xl mx-auto">
      
      {/* Top Back Navigation with hover effect */}
      <AnimatedSection>
        <button
          type="button"
          onClick={() => navigateTo('projects')}
          className="group inline-flex items-center gap-1.5 text-xs font-semibold text-stone-500 hover:text-stone-900 dark:text-zinc-400 dark:hover:text-zinc-100 transition-colors cursor-pointer py-1"
        >
          <ArrowLeft className="h-3.5 w-3.5 transition-transform group-hover:-translate-x-1" />
          <span>{t.backToProjects[locale]}</span>
        </button>
      </AnimatedSection>

      {/* 1. Project Header & Title */}
      <AnimatedSection className="space-y-4 border-b border-stone-200 pb-8 dark:border-zinc-800">
        <div className="flex flex-wrap items-center gap-2 text-xs text-stone-500 dark:text-zinc-400">
          <span className="font-semibold text-blue-600 dark:text-blue-400">
            {project.categoryLabel[locale]}
          </span>
          <span aria-hidden="true">·</span>
          <span>{project.clientOrOrg}</span>
          {project.timeline && (
            <>
              <span aria-hidden="true">·</span>
              <span className="font-mono">{project.timeline}</span>
            </>
          )}
        </div>

        <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold tracking-tight text-stone-900 dark:text-white">
          {project.title}
        </h1>

        <p className="text-base sm:text-lg leading-relaxed text-stone-600 dark:text-zinc-300">
          {project.summary[locale]}
        </p>

        {/* Key Project Metadata Grid (NO PILLS) with hover */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 pt-6 border-t border-stone-100 dark:border-zinc-800/80 text-xs">
          <div className="p-3 rounded-xl bg-stone-50/70 dark:bg-zinc-900/50 border border-stone-200/60 dark:border-zinc-800/60 transition-all hover:border-blue-400/40">
            <span className="font-semibold text-stone-900 dark:text-zinc-100 block mb-0.5">
              {t.role[locale]}:
            </span>
            <span className="text-stone-600 dark:text-zinc-400">
              {project.role[locale]}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-stone-50/70 dark:bg-zinc-900/50 border border-stone-200/60 dark:border-zinc-800/60 transition-all hover:border-blue-400/40">
            <span className="font-semibold text-stone-900 dark:text-zinc-100 block mb-0.5">
              {t.team[locale]}:
            </span>
            <span className="text-stone-600 dark:text-zinc-400">
              {project.teamContext[locale]}
            </span>
          </div>

          <div className="p-3 rounded-xl bg-stone-50/70 dark:bg-zinc-900/50 border border-stone-200/60 dark:border-zinc-800/60 transition-all hover:border-blue-400/40">
            <span className="font-semibold text-stone-900 dark:text-zinc-100 block mb-0.5">
              {t.status[locale]}:
            </span>
            <span className="text-stone-600 dark:text-zinc-400">
              {project.statusLabel[locale]}
            </span>
          </div>
        </div>
      </AnimatedSection>

      {/* 2. Main High-Fidelity Project Visual with Hover Zoom */}
      <AnimatedSection className="group overflow-hidden rounded-3xl border border-stone-200 bg-stone-100 shadow-md hover:shadow-2xl hover:shadow-blue-500/10 hover:border-blue-500/40 transition-all duration-500 dark:border-zinc-800 dark:bg-zinc-800/50">
        {!imgError && project.image ? (
          <img
            src={project.image}
            alt={project.title}
            referrerPolicy="no-referrer"
            onError={() => setImgError(true)}
            className="w-full object-cover object-top transition-transform duration-700 ease-out group-hover:scale-103"
          />
        ) : (
          <div className="flex aspect-video w-full flex-col items-center justify-center p-8 text-stone-400 dark:text-zinc-600">
            <FolderGit2 className="h-12 w-12 stroke-1 mb-2" />
            <span className="text-sm font-medium">{project.title}</span>
          </div>
        )}
      </AnimatedSection>

      {/* 3. Project Overview & Audience */}
      <AnimatedSection className="grid grid-cols-1 gap-8 md:grid-cols-12">
        <div className="md:col-span-8 space-y-4">
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900 dark:text-white">
            {locale === 'de' ? 'Projektübersicht' : locale === 'fr' ? 'Vue d’Ensemble du Projet' : 'Project Overview'}
          </h2>
          <p className="text-sm sm:text-base leading-relaxed text-stone-600 dark:text-zinc-300">
            {project.overview[locale]}
          </p>
        </div>

        <div className="md:col-span-4 rounded-2xl border border-stone-200 bg-stone-50/70 p-5 dark:border-zinc-800 dark:bg-zinc-900/40 space-y-3 hover:border-blue-400/40 transition-all">
          <h3 className="text-xs font-bold uppercase tracking-wider text-stone-900 dark:text-zinc-100">
            {locale === 'de' ? 'Zielgruppe & Kontext' : locale === 'fr' ? 'Public Cible & Contexte' : 'Audience & Context'}
          </h3>
          <p className="text-xs leading-relaxed text-stone-600 dark:text-zinc-400">
            {project.audienceAndContext[locale]}
          </p>
        </div>
      </AnimatedSection>

      {/* 4. Challenge & Constraints with Hover */}
      <AnimatedSection className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div className="group rounded-2xl border border-stone-200 bg-white/95 p-6 dark:border-zinc-800 dark:bg-zinc-900/50 space-y-3 hover:-translate-y-1 hover:border-blue-500/40 hover:shadow-lg transition-all duration-300">
          <h3 className="text-base font-bold text-stone-900 dark:text-white flex items-center gap-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
            <AlertCircle className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            <span>{t.challengeTitle[locale]}</span>
          </h3>
          <p className="text-xs sm:text-sm leading-relaxed text-stone-600 dark:text-zinc-300">
            {project.challenge[locale]}
          </p>
        </div>

        <div className="group rounded-2xl border border-stone-200 bg-white/95 p-6 dark:border-zinc-800 dark:bg-zinc-900/50 space-y-3 hover:-translate-y-1 hover:border-emerald-500/40 hover:shadow-lg transition-all duration-300">
          <h3 className="text-base font-bold text-stone-900 dark:text-white flex items-center gap-2 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
            <CheckCircle2 className="h-4 w-4 text-emerald-600 dark:text-emerald-400" />
            <span>{t.constraintsTitle[locale]}</span>
          </h3>
          <ul className="space-y-2 text-xs leading-relaxed text-stone-600 dark:text-zinc-400">
            {project.constraints.map((c, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="h-1 w-1 rounded-full bg-stone-400 dark:bg-zinc-600 mt-1.5 shrink-0" />
                <span>{c[locale]}</span>
              </li>
            ))}
          </ul>
        </div>
      </AnimatedSection>

      {/* 5. Observations & Research */}
      {project.researchAndObservations && project.researchAndObservations.length > 0 && (
        <AnimatedSection className="rounded-2xl border border-stone-200 bg-stone-50/70 p-6 sm:p-8 dark:border-zinc-800 dark:bg-zinc-900/40 space-y-3 hover:border-blue-400/40 transition-all">
          <h2 className="text-lg font-bold text-stone-900 dark:text-white">
            {t.researchTitle[locale]}
          </h2>
          <div className="space-y-2">
            {project.researchAndObservations.map((r, idx) => (
              <div key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-stone-700 dark:text-zinc-300">
                <span className="font-mono text-blue-600 dark:text-blue-400 font-bold shrink-0">0{idx + 1}.</span>
                <span>{r[locale]}</span>
              </div>
            ))}
          </div>
        </AnimatedSection>
      )}

      {/* 6. Information Architecture & User Flow */}
      <AnimatedSection className="space-y-4">
        <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900 dark:text-white">
          {t.architectureTitle[locale]}
        </h2>
        <div className="rounded-2xl border border-stone-200 bg-white/95 p-6 sm:p-8 dark:border-zinc-800 dark:bg-zinc-900/50 hover:border-blue-400/40 transition-all">
          <p className="text-sm leading-relaxed text-stone-600 dark:text-zinc-300">
            {project.userFlowAndArchitecture[locale]}
          </p>
        </div>
      </AnimatedSection>

      {/* 7. Key Design Decisions (Problem -> Solution -> Impact) */}
      <AnimatedSection className="space-y-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            {locale === 'de' ? 'Design Thinking im Detail' : 'Key Design Decisions'}
          </span>
          <h2 className="mt-1 text-xl sm:text-2xl font-bold tracking-tight text-stone-900 dark:text-white">
            {t.decisionsTitle[locale]}
          </h2>
        </div>

        <div className="space-y-4">
          {project.designDecisions.map((decision, idx) => (
            <AnimatedItem key={idx} delay={idx * 0.08}>
              <div
                className="group rounded-2xl border border-stone-200/90 bg-white/95 backdrop-blur-xs p-6 hover:-translate-y-1.5 hover:border-blue-500/50 hover:shadow-xl dark:border-zinc-800/90 dark:bg-zinc-900/60 dark:hover:border-blue-500/30 transition-all duration-300 space-y-4"
              >
                <h3 className="text-base font-bold text-stone-900 group-hover:text-blue-600 dark:text-zinc-100 dark:group-hover:text-blue-400 transition-colors flex items-center gap-2">
                  <span className="font-mono text-xs text-blue-600 dark:text-blue-400">#{idx + 1}</span>
                  <span>{decision.title[locale]}</span>
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2 border-t border-stone-100 dark:border-zinc-800 text-xs">
                  <div>
                    <span className="font-semibold text-red-600 dark:text-red-400 block mb-1">
                      {locale === 'de' ? 'Problem / Ausgangslage:' : 'Initial Friction:'}
                    </span>
                    <p className="text-stone-600 dark:text-zinc-400 leading-relaxed">
                      {decision.problem[locale]}
                    </p>
                  </div>

                  <div>
                    <span className="font-semibold text-blue-600 dark:text-blue-400 block mb-1">
                      {locale === 'de' ? 'Entscheidung & Lösung:' : 'Design Solution:'}
                    </span>
                    <p className="text-stone-600 dark:text-zinc-400 leading-relaxed">
                      {decision.solution[locale]}
                    </p>
                  </div>

                  <div>
                    <span className="font-semibold text-emerald-600 dark:text-emerald-400 block mb-1">
                      {locale === 'de' ? 'Ergebnis & Wirkung:' : 'Impact / Outcome:'}
                    </span>
                    <p className="text-stone-600 dark:text-zinc-400 leading-relaxed">
                      {decision.impact[locale]}
                    </p>
                  </div>
                </div>
              </div>
            </AnimatedItem>
          ))}
        </div>
      </AnimatedSection>

      {/* 8. Implementation Details */}
      <AnimatedSection className="rounded-2xl border border-stone-200 bg-white/95 p-6 sm:p-8 dark:border-zinc-800 dark:bg-zinc-900/50 space-y-4 hover:border-blue-400/40 transition-all">
        <h2 className="text-lg font-bold text-stone-900 dark:text-white">
          {t.implementationTitle[locale]}
        </h2>
        <ul className="space-y-2 text-xs sm:text-sm text-stone-600 dark:text-zinc-300">
          {project.implementationDetails.map((detail, idx) => (
            <li key={idx} className="flex items-start gap-2.5">
              <span className="h-1.5 w-1.5 rounded-full bg-blue-600 mt-2 shrink-0" />
              <span>{detail[locale]}</span>
            </li>
          ))}
        </ul>
      </AnimatedSection>

      {/* 9. Validated Outcomes & Lessons Learned */}
      <AnimatedSection className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div className="group rounded-2xl border border-stone-200 bg-white/95 p-6 dark:border-zinc-800 dark:bg-zinc-900/50 space-y-3 hover:-translate-y-1 hover:border-blue-500/40 hover:shadow-lg transition-all duration-300">
          <h3 className="text-base font-bold text-stone-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
            {t.resultsTitle[locale]}
          </h3>
          <ul className="space-y-2 text-xs text-stone-600 dark:text-zinc-400">
            {project.resultsAndObservations.map((res, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
                <span>{res[locale]}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="group rounded-2xl border border-stone-200 bg-white/95 p-6 dark:border-zinc-800 dark:bg-zinc-900/50 space-y-3 hover:-translate-y-1 hover:border-blue-500/40 hover:shadow-lg transition-all duration-300">
          <h3 className="text-base font-bold text-stone-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
            {t.lessonsTitle[locale]}
          </h3>
          <p className="text-xs leading-relaxed text-stone-600 dark:text-zinc-400">
            {project.lessonsLearned[locale]}
          </p>
          <div className="mt-3 pt-3 border-t border-stone-100 dark:border-zinc-800 text-[11px] text-stone-500 dark:text-zinc-400">
            <span className="font-semibold block mb-0.5">{t.nextStepsTitle[locale]}:</span>
            <span>{project.nextImprovements[locale]}</span>
          </div>
        </div>
      </AnimatedSection>

      {/* 10. Links & Next Project Navigation */}
      <AnimatedSection className="pt-8 border-t border-stone-200 dark:border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        
        <div className="flex flex-wrap items-center gap-2">
          {project.figmaUrl && (
            <a
              href={project.figmaUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-xs font-semibold text-stone-700 shadow-xs hover:border-stone-400 hover:bg-stone-50 hover:-translate-y-0.5 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-200 dark:hover:border-zinc-600 transition-all cursor-pointer"
            >
              <Figma className="h-3.5 w-3.5" />
              <span>{t.viewFigma[locale]}</span>
            </a>
          )}
          {project.liveUrl && (
            <a
              href={project.liveUrl}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-xl border border-stone-300 bg-white px-3.5 py-2 text-xs font-semibold text-stone-700 shadow-xs hover:border-stone-400 hover:bg-stone-50 hover:-translate-y-0.5 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-200 dark:hover:border-zinc-600 transition-all cursor-pointer"
            >
              <ExternalLink className="h-3.5 w-3.5" />
              <span>{t.viewLive[locale]}</span>
            </a>
          )}
        </div>

        {/* Next project trigger with hover */}
        <button
          type="button"
          onClick={() => navigateTo('case-study', nextProject.slug)}
          className="group inline-flex items-center gap-2 rounded-xl bg-stone-900 px-5 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-stone-800 hover:shadow-xl hover:-translate-y-0.5 active:translate-y-0 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-white transition-all cursor-pointer"
        >
          <span>{t.nextProject[locale]} ({nextProject.title})</span>
          <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
        </button>

      </AnimatedSection>

    </article>
  );
};
