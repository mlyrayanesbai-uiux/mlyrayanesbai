import React from 'react';
import { Mail, Check, MapPin, FileText, ArrowRight, Clock, ShieldCheck } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';
import { siteTranslations } from '../data/translations';
import { ContactForm } from '../components/ContactForm';
import { AnimatedSection, AnimatedItem } from '../components/PageTransition';

export const ContactPage: React.FC = () => {
  const { locale, openCvModal } = usePortfolio();
  const t = siteTranslations.contact;

  return (
    <div className="space-y-16 max-w-4xl mx-auto">
      
      {/* Header with entrance animation */}
      <AnimatedSection className="space-y-4 border-b border-stone-200 pb-8 dark:border-zinc-800">
        <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
          {locale === 'de' ? 'Austausch & Einstieg' : locale === 'fr' ? 'Échange & Contact' : 'Connect & Career'}
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-stone-900 dark:text-white">
          {t.title[locale]}
        </h1>
        <p className="text-sm sm:text-base leading-relaxed text-stone-600 dark:text-zinc-300 max-w-2xl">
          {t.subtitle[locale]}
        </p>
      </AnimatedSection>

      {/* Main Grid: Form + Info Cards */}
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
        
        {/* Left Column: Contact Form with entrance animation */}
        <AnimatedSection className="lg:col-span-7">
          <ContactForm />
        </AnimatedSection>

        {/* Right Column: Key Details & Relocation Readiness with Hover */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Location & Relocation Card */}
          <AnimatedItem delay={0.1}>
            <div className="group rounded-2xl border border-stone-200/90 bg-white/95 backdrop-blur-xs p-6 hover:-translate-y-1.5 hover:border-blue-500/50 hover:shadow-xl hover:shadow-blue-500/10 dark:border-zinc-800/90 dark:bg-zinc-900/70 dark:hover:border-blue-500/40 transition-all duration-300 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-stone-900 dark:text-zinc-100">
                <MapPin className="h-4 w-4 text-blue-600 group-hover:scale-125 transition-transform" />
                <span className="group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">{t.locationTitle[locale]}</span>
              </div>
              <p className="text-xs sm:text-sm text-stone-600 dark:text-zinc-300 leading-relaxed">
                {t.locationValue[locale]}
              </p>
            </div>
          </AnimatedItem>

          {/* Response Commitment Card */}
          <AnimatedItem delay={0.15}>
            <div className="group rounded-2xl border border-stone-200/90 bg-white/95 backdrop-blur-xs p-6 hover:-translate-y-1.5 hover:border-emerald-500/50 hover:shadow-xl hover:shadow-emerald-500/10 dark:border-zinc-800/90 dark:bg-zinc-900/70 dark:hover:border-emerald-500/40 transition-all duration-300 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-stone-900 dark:text-zinc-100">
                <Clock className="h-4 w-4 text-emerald-600 group-hover:rotate-45 transition-transform" />
                <span className="group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">{locale === 'de' ? 'Erreichbarkeit' : locale === 'fr' ? 'Réactivité' : 'Availability'}</span>
              </div>
              <p className="text-xs sm:text-sm text-stone-600 dark:text-zinc-300 leading-relaxed">
                {locale === 'de'
                  ? 'Ich beantworte Anfragen werktags in der Regel innerhalb von 24 Stunden per E-Mail oder vereinbare einen Termin über Google Meet.'
                  : 'I typically reply to inquiries within 24 hours on business days, and am flexible for video interviews via Google Meet.'}
              </p>
            </div>
          </AnimatedItem>

          {/* CV & Document Actions */}
          <AnimatedItem delay={0.2}>
            <div className="group rounded-2xl border border-blue-200/90 bg-blue-50/70 backdrop-blur-xs p-6 hover:-translate-y-1.5 hover:border-blue-500/60 hover:shadow-xl hover:shadow-blue-500/15 dark:border-blue-900/40 dark:bg-blue-950/25 dark:hover:border-blue-500/40 transition-all duration-300 space-y-3">
              <div className="text-xs font-bold uppercase tracking-wider text-blue-900 dark:text-blue-300 flex items-center gap-1.5">
                <FileText className="h-4 w-4 text-blue-600" />
                <span className="group-hover:text-blue-700 dark:group-hover:text-blue-200 transition-colors">{siteTranslations.nav.cv[locale]}</span>
              </div>
              <p className="text-xs text-blue-950/80 dark:text-blue-200 leading-relaxed">
                {siteTranslations.cvModal.subtitle[locale]}
              </p>
              <button
                type="button"
                onClick={openCvModal}
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 px-4 py-2.5 text-xs font-semibold text-white shadow-xs hover:bg-blue-500 hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
              >
                <span>{siteTranslations.cvModal.downloadPdf[locale]}</span>
                <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
              </button>
            </div>
          </AnimatedItem>

        </div>

      </div>

    </div>
  );
};
