import React, { useState } from 'react';
import { ArrowRight, Layout, Sparkles, CheckCircle2, UserCheck, FileText } from 'lucide-react';
import { motion, useReducedMotion, useMotionValue, useSpring } from 'motion/react';
import { usePortfolio } from '../context/PortfolioContext';
import { siteTranslations, verifiedExperiences } from '../data/translations';
import { projectsData } from '../data/projectsData';
import { ProjectCard } from '../components/ProjectCard';
import { AnimatedSection, AnimatedItem } from '../components/PageTransition';

// Clean tool icons for Design Toolkit card
const FigmaIcon = () => (
  <svg className="h-4 w-4 shrink-0" viewBox="0 0 38 57" fill="none" aria-hidden="true">
    <path d="M19 28.5C19 23.2533 23.2533 19 28.5 19C33.7467 19 38 23.2533 38 28.5C38 33.7467 33.7467 38 28.5 38C23.2533 38 19 33.7467 19 28.5Z" fill="#1ABCFE"/>
    <path d="M0 47.5C0 42.2533 4.25329 38 9.5 38H19V47.5C19 52.7467 14.7467 57 9.5 57C4.25329 57 0 52.7467 0 47.5Z" fill="#0ACF83"/>
    <path d="M19 0V19H28.5C33.7467 19 38 14.7467 38 9.5C38 4.25329 33.7467 0 28.5 0H19Z" fill="#FF7262"/>
    <path d="M0 9.5C0 14.7467 4.25329 19 9.5 19H19V0H9.5C4.25329 0 0 4.25329 0 9.5Z" fill="#F24E1E"/>
    <path d="M0 28.5C0 33.7467 4.25329 38 9.5 38H19V19H9.5C4.25329 19 0 23.2533 0 28.5Z" fill="#A259FF"/>
  </svg>
);

const FramerIcon = () => (
  <svg className="h-3.5 w-3.5 shrink-0" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M4 0h16v8h-8zM4 8h8l8 8H4zM4 16h8v8z" className="text-stone-900 dark:text-zinc-100" />
  </svg>
);

const MiroIcon = () => (
  <svg className="h-3.5 w-3.5 shrink-0" viewBox="0 0 24 24" fill="#ECA700" aria-hidden="true">
    <path d="M18.8 3.5 14.4 9.8l3.1 8.7L22 4.6c.4-.9-.3-1.9-1.3-1.8l-1.9.7zM11.5 3.5 7.1 9.8l3.1 8.7L14.7 4.6c.4-.9-.3-1.9-1.3-1.8l-1.9.7zM4.2 3.5-.2 9.8l3.1 8.7L7.4 4.6C7.8 3.7 7.1 2.7 6.1 2.8l-1.9.7z" />
  </svg>
);

// Magnetic Card: smoothly follows the user's cursor proximity using Framer Motion springs
interface MagneticCardProps {
  children: React.ReactNode;
  className?: string;
  baseRotate?: number;
  strength?: number;
  proximityRadius?: number;
  floatY?: number[];
  floatDuration?: number;
  delay?: number;
}

const MagneticCard: React.FC<MagneticCardProps> = ({
  children,
  className = '',
  baseRotate = 0,
  strength = 18,
  proximityRadius = 320,
  floatY = [0, -4, 0],
  floatDuration = 5.5,
  delay = 0,
}) => {
  const shouldReduceMotion = useReducedMotion();
  const cardRef = React.useRef<HTMLDivElement>(null);

  // Framer Motion spring values for fluid hardware-accelerated follow
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);
  const rawRotate = useMotionValue(baseRotate);

  const springConfig = { damping: 22, stiffness: 220, mass: 0.35 };
  const smoothX = useSpring(rawX, springConfig);
  const smoothY = useSpring(rawY, springConfig);
  const smoothRotate = useSpring(rawRotate, springConfig);

  React.useEffect(() => {
    if (shouldReduceMotion) return;

    const handlePointerMove = (e: MouseEvent) => {
      if (!cardRef.current) return;
      const rect = cardRef.current.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      const dx = e.clientX - centerX;
      const dy = e.clientY - centerY;
      const distance = Math.hypot(dx, dy);

      if (distance < proximityRadius) {
        // Proximity falloff: gentle attraction when cursor is near
        const ratio = 1 - distance / proximityRadius;
        const factor = ratio * ratio;

        const pullX = (dx / (distance || 1)) * strength * factor;
        const pullY = (dy / (distance || 1)) * strength * factor;
        const tilt = baseRotate + (dx / proximityRadius) * 5 * factor;

        rawX.set(pullX);
        rawY.set(pullY);
        rawRotate.set(tilt);
      } else {
        rawX.set(0);
        rawY.set(0);
        rawRotate.set(baseRotate);
      }
    };

    const handlePointerLeave = () => {
      rawX.set(0);
      rawY.set(0);
      rawRotate.set(baseRotate);
    };

    window.addEventListener('mousemove', handlePointerMove, { passive: true });
    window.addEventListener('blur', handlePointerLeave);
    document.addEventListener('mouseleave', handlePointerLeave);

    return () => {
      window.removeEventListener('mousemove', handlePointerMove);
      window.removeEventListener('blur', handlePointerLeave);
      document.removeEventListener('mouseleave', handlePointerLeave);
    };
  }, [baseRotate, proximityRadius, shouldReduceMotion, strength, rawX, rawY, rawRotate]);

  return (
    <motion.div
      animate={shouldReduceMotion ? undefined : { y: floatY }}
      transition={{ duration: floatDuration, ease: 'easeInOut', repeat: Infinity, delay }}
      className={`select-none ${className}`}
    >
      <motion.div
        ref={cardRef}
        style={shouldReduceMotion ? { rotate: baseRotate } : { x: smoothX, y: smoothY, rotate: smoothRotate }}
        whileHover={shouldReduceMotion ? undefined : { scale: 1.045 }}
        transition={{ type: 'spring', stiffness: 350, damping: 25 }}
        className="cursor-pointer"
      >
        {children}
      </motion.div>
    </motion.div>
  );
};

export const HomePage: React.FC = () => {
  const { locale, navigateTo, openCvModal } = usePortfolio();
  const shouldReduceMotion = useReducedMotion();
  const [portraitError, setPortraitError] = useState(false);
  const t = siteTranslations;

  const featuredProjects = projectsData.filter((p) => p.featured).slice(0, 4);

  // Exact reference headline text per language
  const headline = {
    en: {
      line1: 'Thoughtful Design.',
      line2: 'Intuitive Experiences.',
      line3: 'Ideas Brought to Life.'
    },
    de: {
      line1: 'Durchdachtes Design.',
      line2: 'Intuitive Erlebnisse.',
      line3: 'Ideen werden Wirklichkeit.'
    },
    fr: {
      line1: 'Un design réfléchi.',
      line2: 'Des expériences intuitives.',
      line3: 'Des idées qui prennent vie.'
    }
  }[locale];

  // Identity label above headline
  const identityLabel = {
    en: 'Rayane Sbai — UI/UX Designer & Frontend Developer',
    de: 'Rayane Sbai — UI/UX Designer & Frontend Developer',
    fr: 'Rayane Sbai — Designer UI/UX & Développeur Frontend'
  }[locale];

  // Description text per language
  const description = {
    en: 'I turn ideas into clear, usable websites through UI/UX design and frontend development. Open to a role or an Ausbildung in Germany.',
    de: 'Ich verwandle Ideen durch UI/UX-Design und Frontend-Entwicklung in klare, nutzerfreundliche Websites. Offen für eine Stelle oder eine Ausbildung in Deutschland.',
    fr: 'Je transforme des idées en sites web clairs et intuitifs grâce au design UI/UX et au développement frontend. Ouvert à un poste ou à une Ausbildung en Allemagne.'
  }[locale];

  // Buttons per language
  const cta = {
    en: { primary: 'View projects', secondary: 'Contact me' },
    de: { primary: 'Projekte ansehen', secondary: 'Kontakt aufnehmen' },
    fr: { primary: 'Voir les projets', secondary: 'Me contacter' }
  }[locale];

  // Floating cards data
  const cards = {
    en: {
      card1: { title: 'UX/UI Design', subtitle: 'Research · User Flows · Prototypes' },
      card2: { title: 'Design Toolkit', subtitle: 'Figma · Miro · Framer' },
      card3: { title: 'From idea to interface', subtitle: 'Design → Build → Improve' },
      card4: { name: 'Rayane Sbai', role: 'Designer & Developer' },
      card5: { title: 'Open to opportunities', subtitle: 'Germany · Job / Ausbildung' }
    },
    de: {
      card1: { title: 'UX/UI Design', subtitle: 'Recherche · User Flows · Prototypen' },
      card2: { title: 'Design-Toolkit', subtitle: 'Figma · Miro · Framer' },
      card3: { title: 'Von der Idee zum Interface', subtitle: 'Design → Build → Improve' },
      card4: { name: 'Rayane Sbai', role: 'Designer & Entwickler' },
      card5: { title: 'Offen für Chancen', subtitle: 'Deutschland · Stelle / Ausbildung' }
    },
    fr: {
      card1: { title: 'Design UX/UI', subtitle: 'Recherche · Flux utilisateurs · Prototypes' },
      card2: { title: 'Boîte à outils Design', subtitle: 'Figma · Miro · Framer' },
      card3: { title: 'De l’idée à l’interface', subtitle: 'Design → Build → Improve' },
      card4: { name: 'Rayane Sbai', role: 'Designer & Développeur' },
      card5: { title: 'À l’écoute d’opportunités', subtitle: 'Allemagne · Emploi / Ausbildung' }
    }
  }[locale];

  // Scroll down indicator label
  const scrollText = {
    en: 'Scroll to explore',
    de: 'Nach unten scrollen',
    fr: 'Défiler pour explorer'
  }[locale];

  const scrollToProjects = () => {
    const el = document.getElementById('featured-projects');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    } else {
      window.scrollBy({ top: 520, behavior: 'smooth' });
    }
  };

  return (
    <div className="space-y-20 md:space-y-28">
      
      {/* 1. HERO SECTION — Coherent, seamless atmospheric composition with magnetic cards and scroll guide */}
      <section className="relative -mt-4 pt-8 pb-10 sm:pt-14 sm:pb-16 md:pt-18 md:pb-20">
        
        {/* Seamless Atmospheric Illumination — 100% Coherent with the App's Canvas (Zero Box Seams) */}
        <div 
          aria-hidden="true" 
          className="absolute inset-0 pointer-events-none select-none z-0"
        >
          {/* Soft Lavender / Purple Ambient Illumination (Upper-Right Area, naturally feathered) */}
          <div 
            className="absolute -top-14 -right-10 sm:right-[4%] w-[440px] sm:w-[620px] md:w-[720px] h-[440px] sm:h-[620px] md:h-[720px] rounded-full blur-3xl opacity-60 dark:opacity-20 transition-opacity duration-300"
            style={{
              background: 'radial-gradient(circle, rgba(224, 214, 254, 0.65) 0%, rgba(238, 230, 255, 0.35) 42%, transparent 72%)'
            }}
          />

          {/* Pale Buttery-Yellow Ambient Glow (Lower-Left Area, naturally feathered) */}
          <div 
            className="absolute -bottom-10 -left-10 sm:left-[4%] w-[380px] sm:w-[560px] md:w-[660px] h-[380px] sm:h-[560px] md:h-[660px] rounded-full blur-3xl opacity-55 dark:opacity-18 transition-opacity duration-300"
            style={{
              background: 'radial-gradient(circle, rgba(254, 243, 199, 0.70) 0%, rgba(253, 230, 138, 0.30) 42%, transparent 72%)'
            }}
          />

          {/* Delicate Headline Grid Highlight (Matching page's 32px grid smoothly with radial vignette) */}
          <div
            className="absolute inset-0 opacity-45 dark:opacity-20"
            style={{
              backgroundImage: 'linear-gradient(to right, rgba(0,0,0,0.045) 1px, transparent 1px), linear-gradient(to bottom, rgba(0,0,0,0.045) 1px, transparent 1px)',
              backgroundSize: '32px 32px',
              maskImage: 'radial-gradient(ellipse 65% 55% at 50% 36%, black 15%, transparent 75%)',
              WebkitMaskImage: 'radial-gradient(ellipse 65% 55% at 50% 36%, black 15%, transparent 75%)',
            }}
          />
        </div>

        {/* Hero Container (~1150-1200px max width) */}
        <div className="relative z-10 mx-auto max-w-6xl px-4 sm:px-6">
          
          {/* DESKTOP MAGNETIC FLOATING CARDS (Subtly follows cursor movement near them) */}
          
          {/* 1. Upper-left Card: UX/UI Design (~ -6 deg rotation) */}
          <MagneticCard
            baseRotate={-6}
            strength={18}
            proximityRadius={340}
            floatY={[0, -4, 0]}
            floatDuration={5.5}
            className="hidden lg:flex absolute left-0 xl:-left-4 top-4 z-20 pointer-events-auto"
          >
            <div className="glass-card flex items-center gap-3 rounded-2xl px-4 py-3 shadow-[0_8px_30px_rgb(0,0,0,0.06)] dark:shadow-[0_8px_30px_rgb(0,0,0,0.4)] backdrop-blur-xl border border-white/85 dark:border-white/10 hover:border-purple-300 dark:hover:border-purple-500/50">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-purple-500/10 text-purple-600 dark:bg-purple-500/20 dark:text-purple-300 shrink-0">
                <Layout className="h-4 w-4" />
              </div>
              <div className="text-left">
                <div className="text-xs sm:text-sm font-bold text-stone-900 dark:text-zinc-100 leading-tight">
                  {cards.card1.title}
                </div>
                <div className="text-[11px] text-stone-500 dark:text-zinc-400 mt-0.5 whitespace-nowrap">
                  {cards.card1.subtitle}
                </div>
              </div>
            </div>
          </MagneticCard>

          {/* 2. Upper-right Card: Design Toolkit (~ +6 deg rotation) */}
          <MagneticCard
            baseRotate={6}
            strength={18}
            proximityRadius={340}
            floatY={[0, 4, 0]}
            floatDuration={6}
            delay={0.4}
            className="hidden lg:flex absolute right-0 xl:-right-4 top-3 z-20 pointer-events-auto"
          >
            <div className="glass-card flex items-center gap-3 rounded-2xl px-4 py-3 shadow-[0_8px_30px_rgb(0,0,0,0.06)] dark:shadow-[0_8px_30px_rgb(0,0,0,0.4)] backdrop-blur-xl border border-white/85 dark:border-white/10 hover:border-blue-300 dark:hover:border-blue-500/50">
              <div className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg bg-stone-100/80 dark:bg-zinc-800/80 backdrop-blur-xs shrink-0">
                <FigmaIcon />
                <MiroIcon />
                <FramerIcon />
              </div>
              <div className="text-left">
                <div className="text-xs sm:text-sm font-bold text-stone-900 dark:text-zinc-100 leading-tight">
                  {cards.card2.title}
                </div>
                <div className="text-[11px] text-stone-500 dark:text-zinc-400 mt-0.5 whitespace-nowrap">
                  {cards.card2.subtitle}
                </div>
              </div>
            </div>
          </MagneticCard>

          {/* 3. Central Accent Card: "From idea to interface" with purple gradient header & interface preview (~ +3 deg rotation) */}
          <MagneticCard
            baseRotate={3}
            strength={16}
            proximityRadius={340}
            floatY={[0, -3.5, 0]}
            floatDuration={6.5}
            delay={0.8}
            className="hidden xl:flex absolute -right-6 top-48 z-20 pointer-events-auto"
          >
            <div className="glass-card w-[220px] overflow-hidden rounded-2xl shadow-[0_12px_36px_rgb(0,0,0,0.08)] dark:shadow-[0_12px_36px_rgb(0,0,0,0.45)] backdrop-blur-xl border border-white/85 dark:border-white/10 hover:border-purple-400">
              {/* Purple Gradient Glass Header with mini window controls */}
              <div className="bg-gradient-to-r from-purple-600/90 via-indigo-600/90 to-purple-500/90 backdrop-blur-md px-3.5 py-2 flex items-center justify-between text-white border-b border-white/20">
                <span className="text-[11px] font-semibold tracking-tight truncate">
                  {cards.card3.title}
                </span>
                <div className="flex items-center gap-1 shrink-0 opacity-80">
                  <span className="h-1.5 w-1.5 rounded-full bg-white" />
                  <span className="h-1.5 w-1.5 rounded-full bg-white/70" />
                  <span className="h-1.5 w-1.5 rounded-full bg-white/50" />
                </div>
              </div>
              {/* Interface wireframe preview */}
              <div className="p-3 bg-white/40 dark:bg-zinc-950/40 backdrop-blur-md space-y-2">
                <div className="flex items-center justify-between border-b border-stone-200/60 dark:border-zinc-800/60 pb-1.5">
                  <div className="h-2 w-10 rounded bg-stone-300 dark:bg-zinc-700" />
                  <div className="h-2 w-4 rounded-full bg-purple-500/80" />
                </div>
                <div className="grid grid-cols-2 gap-1.5">
                  <div className="h-8 rounded-md bg-white/90 border border-white/80 dark:bg-zinc-800/90 dark:border-zinc-700/80 p-1 flex flex-col justify-between shadow-2xs">
                    <div className="h-1.5 w-6 rounded bg-purple-300 dark:bg-purple-800" />
                    <div className="h-1 w-8 rounded bg-stone-200 dark:bg-zinc-700" />
                  </div>
                  <div className="h-8 rounded-md bg-white/90 border border-white/80 dark:bg-zinc-800/90 dark:border-zinc-700/80 p-1 flex flex-col justify-between shadow-2xs">
                    <div className="h-1.5 w-7 rounded bg-indigo-300 dark:bg-indigo-800" />
                    <div className="h-1 w-6 rounded bg-stone-200 dark:bg-zinc-700" />
                  </div>
                </div>
                <div className="text-[10px] font-medium text-purple-700 dark:text-purple-300 pt-0.5 text-center">
                  {cards.card3.subtitle}
                </div>
              </div>
            </div>
          </MagneticCard>

          {/* 4. Lower-left Compact Badge: Rayane Sbai with circular avatar (~ -4 deg rotation) */}
          <MagneticCard
            baseRotate={-4}
            strength={18}
            proximityRadius={340}
            floatY={[0, 3.5, 0]}
            floatDuration={5.2}
            delay={0.2}
            className="hidden lg:flex absolute left-2 xl:-left-2 bottom-6 z-20 pointer-events-auto"
          >
            <div className="glass-card flex items-center gap-3 rounded-2xl p-2.5 pr-4 shadow-[0_8px_30px_rgb(0,0,0,0.06)] dark:shadow-[0_8px_30px_rgb(0,0,0,0.4)] backdrop-blur-xl border border-white/85 dark:border-white/10 hover:border-stone-400">
              {!portraitError ? (
                <img
                  src="/src/assets/images/rayane_portrait_1792334375029.jpg"
                  alt="Rayane Sbai"
                  onError={() => setPortraitError(true)}
                  className="h-10 w-10 rounded-full object-cover ring-2 ring-white/80 dark:ring-white/20 shadow-xs shrink-0"
                />
              ) : (
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-stone-900 text-xs font-bold text-white ring-2 ring-white/80 dark:bg-zinc-100 dark:text-zinc-900 shrink-0">
                  RS
                </div>
              )}
              <div className="text-left">
                <div className="text-xs sm:text-sm font-bold text-stone-900 dark:text-zinc-100 leading-tight">
                  {cards.card4.name}
                </div>
                <div className="text-[11px] text-stone-500 dark:text-zinc-400 mt-0.5 whitespace-nowrap">
                  {cards.card4.role}
                </div>
              </div>
            </div>
          </MagneticCard>

          {/* 5. Lower-right Compact Purple Badge: Open to opportunities (~ +4 deg rotation) */}
          <MagneticCard
            baseRotate={4}
            strength={18}
            proximityRadius={340}
            floatY={[0, -3.5, 0]}
            floatDuration={5.8}
            delay={0.6}
            className="hidden lg:flex absolute right-2 xl:-right-2 bottom-6 z-20 pointer-events-auto"
          >
            <div className="glass-panel flex items-center gap-3 rounded-2xl bg-purple-50/70 dark:bg-purple-950/45 px-4 py-3 shadow-[0_8px_30px_rgba(147,51,234,0.08)] dark:shadow-[0_8px_30px_rgba(0,0,0,0.4)] backdrop-blur-xl border border-purple-200/80 dark:border-purple-800/40 hover:border-purple-400">
              <span className="relative flex h-2.5 w-2.5 shrink-0">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-500" />
              </span>
              <div className="text-left">
                <div className="text-xs sm:text-sm font-bold text-purple-950 dark:text-purple-200 leading-tight">
                  {cards.card5.title}
                </div>
                <div className="text-[11px] text-purple-700/90 dark:text-purple-300/90 mt-0.5 whitespace-nowrap">
                  {cards.card5.subtitle}
                </div>
              </div>
            </div>
          </MagneticCard>

          {/* CENTERED TYPOGRAPHIC HERO CONTENT */}
          <motion.div
            initial={shouldReduceMotion ? false : { opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="mx-auto max-w-[860px] text-center flex flex-col items-center"
          >
            
            {/* Small Label above headline */}
            <span className="mb-4 sm:mb-6 text-xs sm:text-sm font-semibold tracking-wider uppercase text-stone-500 dark:text-zinc-400">
              {identityLabel}
            </span>

            {/* Large, bold, tightly spaced headline with 1 muted line */}
            <h1 className="max-w-[850px] text-center font-bold tracking-[-0.035em] text-[34px] leading-[1.10] sm:text-[48px] sm:leading-[1.08] md:text-[60px] md:leading-[1.06] lg:text-[70px] lg:leading-[1.05] xl:text-[74px] text-balance">
              <span className="block text-stone-900 dark:text-zinc-50">
                {headline.line1}
              </span>
              <span className="block text-stone-500 dark:text-zinc-400 font-semibold sm:font-bold">
                {headline.line2}
              </span>
              <span className="block text-stone-900 dark:text-white">
                {headline.line3}
              </span>
            </h1>

            {/* Short Centered Description (~580-650px wide) */}
            <p className="mt-6 sm:mt-8 max-w-[620px] text-center text-base sm:text-lg leading-relaxed text-stone-600 dark:text-zinc-400 font-normal text-balance">
              {description}
            </p>

            {/* Two Pill-Shaped CTAs */}
            <div className="mt-7 sm:mt-9 flex flex-wrap items-center justify-center gap-3.5 sm:gap-5">
              {/* Primary: Black pill with white text & small arrow */}
              <button
                type="button"
                onClick={() => navigateTo('projects')}
                className="group inline-flex items-center gap-2 rounded-full bg-stone-900 px-7 py-3 text-xs sm:text-sm font-semibold text-white shadow-md transition-all duration-200 hover:bg-black hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 dark:bg-white dark:text-stone-950 dark:hover:bg-zinc-100 cursor-pointer"
              >
                <span>{cta.primary}</span>
                <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
              </button>

              {/* Secondary: Glass pill with subtle highlight */}
              <button
                type="button"
                onClick={() => navigateTo('contact')}
                className="glass-pill group inline-flex items-center gap-2 rounded-full px-7 py-3 text-xs sm:text-sm font-semibold text-stone-900 shadow-xs transition-all duration-200 hover:bg-white/90 hover:shadow-md hover:-translate-y-0.5 active:translate-y-0 dark:text-zinc-100 dark:hover:bg-zinc-800/80 cursor-pointer"
              >
                <span>{cta.secondary}</span>
              </button>
            </div>

            {/* MOBILE & TABLET COMPACT BADGES ROW (Below CTAs, ensuring pristine view on mobile without overlap) */}
            <div className="mt-8 flex lg:hidden flex-wrap items-center justify-center gap-2.5 max-w-xl mx-auto px-2">
              {/* Badge 1: UX/UI Design */}
              <div className="glass-pill flex items-center gap-2 rounded-full px-3 py-1.5 shadow-xs text-left">
                <Layout className="h-3.5 w-3.5 text-purple-600 dark:text-purple-400" />
                <span className="text-xs font-semibold text-stone-900 dark:text-zinc-100">{cards.card1.title}</span>
              </div>

              {/* Badge 2: Design Toolkit */}
              <div className="glass-pill flex items-center gap-1.5 rounded-full px-3 py-1.5 shadow-xs">
                <FigmaIcon />
                <span className="text-xs font-semibold text-stone-900 dark:text-zinc-100">Figma · Miro · Framer</span>
              </div>

              {/* Badge 3: Rayane Sbai */}
              <div className="glass-pill flex items-center gap-2 rounded-full px-2.5 py-1 shadow-xs">
                {!portraitError ? (
                  <img
                    src="/src/assets/images/rayane_portrait_1792334375029.jpg"
                    alt="Rayane Sbai"
                    onError={() => setPortraitError(true)}
                    className="h-5 w-5 rounded-full object-cover shrink-0"
                  />
                ) : (
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-stone-900 text-[10px] font-bold text-white shrink-0">
                    RS
                  </div>
                )}
                <span className="text-xs font-semibold text-stone-900 dark:text-zinc-100">{cards.card4.name}</span>
              </div>

              {/* Badge 4: Open to opportunities */}
              <div className="glass-pill flex items-center gap-2 rounded-full bg-purple-50/70 dark:bg-purple-950/45 border-purple-200/80 dark:border-purple-900/60 px-3 py-1.5 shadow-xs">
                <span className="relative flex h-2 w-2 shrink-0">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
                </span>
                <span className="text-xs font-semibold text-purple-950 dark:text-purple-200">{cards.card5.title}</span>
              </div>
            </div>

            {/* Subtle 'Scroll Down' Indicator */}
            <motion.div
              initial={shouldReduceMotion ? false : { opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5, duration: 0.5 }}
              className="mt-12 sm:mt-16 md:mt-20 flex justify-center"
            >
              <button
                type="button"
                onClick={scrollToProjects}
                className="glass-pill group inline-flex flex-col items-center gap-2 text-stone-500 hover:text-stone-900 dark:text-zinc-400 dark:hover:text-zinc-100 transition-all cursor-pointer focus-visible:outline-hidden focus-visible:ring-2 focus-visible:ring-stone-400 rounded-full py-2 px-4 hover:shadow-md"
                aria-label={scrollText}
              >
                <span className="text-[11px] font-medium tracking-wider uppercase text-stone-500 dark:text-zinc-400 group-hover:text-stone-900 dark:group-hover:text-zinc-100 transition-colors">
                  {scrollText}
                </span>
                <motion.div
                  animate={shouldReduceMotion ? undefined : { y: [0, 5, 0] }}
                  transition={shouldReduceMotion ? undefined : { duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
                  className="flex h-7 w-4.5 items-start justify-center rounded-full border border-stone-300/90 dark:border-zinc-700/80 p-1 group-hover:border-stone-500 dark:group-hover:border-zinc-500 transition-colors"
                >
                  <motion.span
                    animate={shouldReduceMotion ? undefined : { y: [0, 6, 0] }}
                    transition={shouldReduceMotion ? undefined : { duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
                    className="h-1.5 w-1 rounded-full bg-stone-500 dark:bg-zinc-400 group-hover:bg-stone-900 dark:group-hover:bg-zinc-100 transition-colors"
                  />
                </motion.div>
              </button>
            </motion.div>

          </motion.div>

        </div>
      </section>

      {/* 2. SELECTED PROJECTS SECTION */}
      <AnimatedSection id="featured-projects" className="space-y-8 scroll-mt-24">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-stone-200 pb-5 dark:border-zinc-800">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              {t.sections.featuredProjects.kicker[locale]}
            </span>
            <h2 className="mt-1 text-2xl sm:text-3xl font-extrabold tracking-tight text-stone-900 dark:text-white">
              {t.sections.featuredProjects.title[locale]}
            </h2>
            <p className="mt-1 text-sm text-stone-600 dark:text-zinc-400 max-w-xl">
              {t.sections.featuredProjects.description[locale]}
            </p>
          </div>

          <button
            type="button"
            onClick={() => navigateTo('projects')}
            className="group inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 whitespace-nowrap cursor-pointer hover:underline"
          >
            <span>{t.sections.featuredProjects.allProjectsLink[locale]}</span>
            <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* 2x2 Grid of Featured Projects with Staggered Entrance and Hover */}
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          {featuredProjects.map((project, idx) => (
            <AnimatedItem key={project.id} delay={idx * 0.08}>
              <ProjectCard project={project} isPriority={idx === 0} />
            </AnimatedItem>
          ))}
        </div>
      </AnimatedSection>

      {/* 3. WHAT I DO (3 concise areas with glass hover cards) */}
      <AnimatedSection className="space-y-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            {t.sections.whatIDo.kicker[locale]}
          </span>
          <h2 className="mt-1 text-2xl sm:text-3xl font-extrabold tracking-tight text-stone-900 dark:text-white">
            {t.sections.whatIDo.title[locale]}
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
          {t.sections.whatIDo.items.map((item, idx) => (
            <AnimatedItem key={item.num} delay={idx * 0.1}>
              <div className="glass-card group flex h-full flex-col justify-between rounded-2xl p-6 transition-all duration-300 hover:-translate-y-2 hover:border-blue-500/50 hover:shadow-2xl hover:shadow-blue-500/10 dark:hover:border-blue-500/40 dark:hover:shadow-blue-950/30">
                <div>
                  <span className="font-mono text-xs font-semibold text-blue-600 dark:text-blue-400 group-hover:underline">
                    {item.num}
                  </span>
                  <h3 className="mt-2 text-lg font-bold text-stone-900 group-hover:text-blue-600 dark:text-zinc-100 dark:group-hover:text-blue-400 transition-colors">
                    {item.title[locale]}
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm leading-relaxed text-stone-600 dark:text-zinc-400">
                    {item.desc[locale]}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-stone-200/50 dark:border-zinc-800/80 space-y-1.5">
                  {item.points.map((pt, pIdx) => (
                    <div key={pIdx} className="flex items-center gap-2 text-xs text-stone-700 dark:text-zinc-300">
                      <span className="h-1 w-1 rounded-full bg-blue-600 group-hover:scale-150 transition-transform shrink-0" />
                      <span>{pt[locale]}</span>
                    </div>
                  ))}
                </div>
              </div>
            </AnimatedItem>
          ))}
        </div>
      </AnimatedSection>

      {/* 4. HOW I WORK (4 stages with glass cards) */}
      <AnimatedSection className="space-y-8">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            {t.sections.howIWork.kicker[locale]}
          </span>
          <h2 className="mt-1 text-2xl sm:text-3xl font-extrabold tracking-tight text-stone-900 dark:text-white">
            {t.sections.howIWork.title[locale]}
          </h2>
          <p className="mt-1 text-sm text-stone-600 dark:text-zinc-400">
            {t.sections.howIWork.subtitle[locale]}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {t.sections.howIWork.steps.map((step, idx) => (
            <AnimatedItem key={step.num} delay={idx * 0.08}>
              <div className="glass-card group h-full rounded-2xl p-5 transition-all duration-300 hover:-translate-y-1.5 hover:border-blue-500/50 hover:shadow-xl dark:hover:border-blue-500/40">
                <div className="font-mono text-xs text-blue-600 dark:text-blue-400 font-semibold mb-2 group-hover:translate-x-1 transition-transform">
                  Phase {step.num}
                </div>
                <h3 className="text-base font-bold text-stone-900 dark:text-zinc-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {step.name[locale]}
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-stone-600 dark:text-zinc-400">
                  {step.summary[locale]}
                </p>
              </div>
            </AnimatedItem>
          ))}
        </div>
      </AnimatedSection>

      {/* 5. AI-ASSISTED WORKFLOW (Glass panel with hover) */}
      <AnimatedSection className="glass-panel group rounded-3xl p-6 sm:p-8 hover:border-blue-500/40 hover:shadow-2xl hover:shadow-blue-500/5 transition-all duration-300">
        <div className="max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            <Sparkles className="h-4 w-4" />
            <span>{t.sections.aiWorkflow.kicker[locale]}</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-stone-900 dark:text-white">
            {t.sections.aiWorkflow.title[locale]}
          </h2>

          <p className="text-sm leading-relaxed text-stone-600 dark:text-zinc-300">
            {t.sections.aiWorkflow.desc[locale]}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
            {t.sections.aiWorkflow.points.map((pt, idx) => (
              <div
                key={idx}
                className="glass-pill rounded-xl p-3 text-xs text-stone-700 transition-all duration-200 hover:-translate-y-0.5 hover:border-blue-400 hover:shadow-sm dark:text-zinc-300 dark:hover:border-blue-500/40 cursor-default"
              >
                {pt[locale]}
              </div>
            ))}
          </div>
        </div>
      </AnimatedSection>

      {/* 6. COMPACT EXPERIENCE & EDUCATION TIMELINE */}
      <AnimatedSection className="space-y-8">
        <div className="flex items-center justify-between border-b border-stone-200 pb-5 dark:border-zinc-800">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              {locale === 'de' ? 'Ausbildung & Praxis' : locale === 'fr' ? 'Formation & Expérience' : 'Background'}
            </span>
            <h2 className="mt-1 text-2xl sm:text-3xl font-extrabold tracking-tight text-stone-900 dark:text-white">
              {locale === 'de' ? 'Ausbildung & Stationen im Überblick' : 'Education & Practical Experience'}
            </h2>
          </div>

          <button
            type="button"
            onClick={() => navigateTo('about')}
            className="group inline-flex items-center gap-1.5 text-xs font-semibold text-blue-600 hover:text-blue-700 dark:text-blue-400 cursor-pointer hover:underline"
          >
            <span>{locale === 'de' ? 'Vollständiges Profil' : 'Full profile'}</span>
            <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        <div className="space-y-4">
          {verifiedExperiences.map((item, idx) => (
            <AnimatedItem key={idx} delay={idx * 0.06}>
              <div className="glass-card group flex flex-col sm:flex-row sm:items-start justify-between gap-3 rounded-2xl p-5 transition-all duration-200 hover:-translate-y-1 hover:border-blue-500/40 hover:shadow-xl dark:hover:border-blue-500/30">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="font-bold text-stone-900 dark:text-zinc-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                      {item.role[locale]}
                    </span>
                    <span aria-hidden="true" className="text-stone-300 dark:text-zinc-700">·</span>
                    <span className="text-blue-600 dark:text-blue-400 font-medium">
                      {item.organization}
                    </span>
                  </div>
                  <p className="text-xs text-stone-600 dark:text-zinc-400 max-w-2xl leading-relaxed">
                    {item.description[locale]}
                  </p>
                </div>

                <div className="font-mono text-xs text-stone-500 dark:text-zinc-400 whitespace-nowrap shrink-0">
                  {item.period}
                </div>
              </div>
            </AnimatedItem>
          ))}
        </div>
      </AnimatedSection>

      {/* 7. DUAL OPPORTUNITY & CONTACT BANNER */}
      <AnimatedSection className="group rounded-3xl border border-stone-300/80 bg-stone-900/95 backdrop-blur-xs p-8 sm:p-10 text-white shadow-xl hover:shadow-2xl transition-all duration-300 hover:border-blue-500/50 dark:border-zinc-700 dark:bg-zinc-900/90">
        <div className="max-w-2xl space-y-4">
          <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
            {t.sections.opportunity.kicker[locale]}
          </span>

          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white leading-snug">
            {t.sections.opportunity.title[locale]}
          </h2>

          <p className="text-sm leading-relaxed text-stone-300">
            {t.sections.opportunity.body[locale]}
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={() => navigateTo('contact')}
              className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-xs sm:text-sm font-semibold text-white shadow-xs hover:bg-blue-500 hover:shadow-lg hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer"
            >
              <span>{t.sections.opportunity.ctaContact[locale]}</span>
              <ArrowRight className="h-4 w-4" />
            </button>

            <button
              type="button"
              onClick={openCvModal}
              className="inline-flex items-center gap-2 rounded-xl border border-stone-700 bg-stone-800 px-5 py-2.5 text-xs sm:text-sm font-semibold text-stone-200 hover:bg-stone-700 hover:border-stone-600 hover:shadow-sm hover:-translate-y-0.5 transition-all cursor-pointer"
            >
              <FileText className="h-4 w-4" />
              <span>{t.sections.opportunity.ctaCv[locale]}</span>
            </button>
          </div>
        </div>
      </AnimatedSection>

    </div>
  );
};
