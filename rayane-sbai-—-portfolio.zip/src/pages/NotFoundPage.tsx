import React from 'react';
import { ArrowLeft } from 'lucide-react';
import { usePortfolio } from '../context/PortfolioContext';

export const NotFoundPage: React.FC = () => {
  const { locale, navigateTo } = usePortfolio();

  const content = {
    de: {
      title: 'Seite nicht gefunden (404)',
      desc: 'Die gewünschte Seite oder Fallstudie existiert nicht oder wurde verschoben.',
      cta: 'Zurück zur Startseite'
    },
    en: {
      title: 'Page Not Found (404)',
      desc: 'The requested page or case study does not exist or may have been moved.',
      cta: 'Return to Homepage'
    },
    fr: {
      title: 'Page Non Trouvée (404)',
      desc: 'La page ou l’étude de cas demandée n’existe pas ou a été déplacée.',
      cta: 'Retour à l’accueil'
    }
  }[locale];

  return (
    <div className="py-24 text-center space-y-4 max-w-md mx-auto">
      <span className="font-mono text-sm font-semibold text-blue-600 dark:text-blue-400">
        Error 404
      </span>
      <h1 className="text-3xl font-extrabold text-stone-900 dark:text-white">
        {content.title}
      </h1>
      <p className="text-sm text-stone-600 dark:text-zinc-400">
        {content.desc}
      </p>
      <div className="pt-4">
        <button
          type="button"
          onClick={() => navigateTo('home')}
          className="inline-flex items-center gap-2 rounded-xl bg-stone-900 px-5 py-2.5 text-xs font-semibold text-white hover:bg-stone-800 dark:bg-zinc-100 dark:text-zinc-900 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>{content.cta}</span>
        </button>
      </div>
    </div>
  );
};
