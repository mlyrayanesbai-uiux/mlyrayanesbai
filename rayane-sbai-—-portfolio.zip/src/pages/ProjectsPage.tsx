import React, { useState } from 'react';
import { usePortfolio } from '../context/PortfolioContext';
import { projectsData, visualExplorations } from '../data/projectsData';
import { ProjectCard } from '../components/ProjectCard';
import { ProjectData } from '../types/portfolio';
import { Sparkles, ArrowRight, X } from 'lucide-react';
import { AnimatedSection, AnimatedItem } from '../components/PageTransition';

export const ProjectsPage: React.FC = () => {
  const { locale, navigateTo } = usePortfolio();
  const [activeFilter, setActiveFilter] = useState<'all' | 'ui-ux' | 'frontend' | 'full-product'>('all');
  const [selectedExploration, setSelectedExploration] = useState<string | null>(null);

  const filters: { id: 'all' | 'ui-ux' | 'frontend' | 'full-product'; label: { de: string; en: string; fr: string } }[] = [
    { id: 'all', label: { de: 'Alle Arbeiten', en: 'All Projects', fr: 'Tous les projets' } },
    { id: 'ui-ux', label: { de: 'UX/UI Design', en: 'UX/UI Design', fr: 'Design UX/UI' } },
    { id: 'frontend', label: { de: 'Frontend & Apps', en: 'Frontend & Apps', fr: 'Frontend & Apps' } },
    { id: 'full-product', label: { de: 'Komplettlösungen', en: 'Full Products', fr: 'Produits Complets' } }
  ];

  const filteredProjects = projectsData.filter((p) => {
    if (activeFilter === 'all') return true;
    return p.category === activeFilter;
  });

  const activeExp = visualExplorations.find((e) => e.id === selectedExploration);

  return (
    <div className="space-y-16">
      
      {/* Header & Filter Controls with Entrance Animation */}
      <AnimatedSection className="space-y-6 border-b border-stone-200 pb-8 dark:border-zinc-800">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            {locale === 'de' ? 'Portfolio & Fallstudien' : locale === 'fr' ? 'Portfolio & Études' : 'Portfolio & Case Studies'}
          </span>
          <h1 className="mt-1 text-3xl sm:text-4xl font-extrabold tracking-tight text-stone-900 dark:text-white">
            {locale === 'de' ? 'Ausgewählte Projekte & Umsetzungen' : locale === 'fr' ? 'Projets & Réalisations Numériques' : 'Selected Projects & Implementations'}
          </h1>
          <p className="mt-2 text-sm sm:text-base text-stone-600 dark:text-zinc-400 max-w-2xl leading-relaxed">
            {locale === 'de'
              ? 'Hier finden Sie detaillierte Einblicke in meine Arbeit: von der Problemdefinition und Recherche über Wireframes bis zum fertigen Frontend-Code. Jede Fallstudie erklärt meine konkrete Rolle und Arbeitsentscheidungen.'
              : locale === 'fr'
              ? 'Découvrez ici mes projets en détail : de la compréhension du problème aux wireframes et au code frontend. Chaque étude de cas précise mon rôle et mes choix de conception.'
              : 'Detailed case studies covering problem definition, UX audits, wireframes, and responsive frontend implementation. Each entry details my exact contribution.'}
          </p>
        </div>

        {/* Functional Segmented Filter Tabs with tactile hover */}
        <div className="flex flex-wrap items-center gap-1.5 p-1.5 rounded-xl bg-stone-100/90 border border-stone-200/90 w-fit dark:bg-zinc-900/90 dark:border-zinc-800">
          {filters.map((filter) => {
            const isActive = activeFilter === filter.id;
            return (
              <button
                key={filter.id}
                type="button"
                onClick={() => setActiveFilter(filter.id)}
                className={`rounded-lg px-3.5 py-1.5 text-xs font-medium transition-all duration-200 cursor-pointer whitespace-nowrap shrink-0 hover:-translate-y-0.5 ${
                  isActive
                    ? 'bg-white text-stone-900 shadow-sm font-semibold dark:bg-zinc-800 dark:text-white'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/50 dark:text-zinc-400 dark:hover:text-zinc-200 dark:hover:bg-zinc-800/50'
                }`}
              >
                {filter.label[locale]}
              </button>
            );
          })}
        </div>
      </AnimatedSection>

      {/* Projects Grid with Staggered Entrance Animations & Lift Hover */}
      <section>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          {filteredProjects.map((project, idx) => (
            <AnimatedItem key={project.id} delay={idx * 0.08}>
              <ProjectCard project={project} />
            </AnimatedItem>
          ))}
        </div>

        {filteredProjects.length === 0 && (
          <div className="py-16 text-center text-sm text-stone-500 dark:text-zinc-400">
            {locale === 'de' ? 'Keine Projekte in dieser Kategorie gefunden.' : 'No projects found in this category.'}
          </div>
        )}
      </section>

      {/* Visual Explorations Section */}
      <AnimatedSection className="space-y-6 pt-8 border-t border-stone-200 dark:border-zinc-800">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
            <Sparkles className="h-4 w-4" />
            <span>{locale === 'de' ? 'Experimente & Detailarbeit' : 'Visual Explorations'}</span>
          </div>
          <h2 className="mt-1 text-2xl font-bold tracking-tight text-stone-900 dark:text-white">
            {locale === 'de' ? 'Visuelle Erkundungen & Komponentenstudien' : 'Visual Explorations & Component Studies'}
          </h2>
          <p className="mt-1 text-xs sm:text-sm text-stone-600 dark:text-zinc-400 max-w-xl">
            {locale === 'de'
              ? 'Eigenständige Studien zu Typografie, Daten-Tabellen und Interaktionsmustern abseits von Kundenprojekten.'
              : 'Independent studies exploring typography systems, data table responsiveness, and accessible micro-interactions.'}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {visualExplorations.map((exp, idx) => (
            <AnimatedItem key={exp.id} delay={idx * 0.08}>
              <div
                onClick={() => setSelectedExploration(exp.id)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') setSelectedExploration(exp.id);
                }}
                role="button"
                tabIndex={0}
                className="group h-full rounded-2xl border border-stone-200/90 bg-white/95 backdrop-blur-xs p-5 text-left transition-all duration-300 hover:-translate-y-2 hover:border-blue-500/50 hover:shadow-xl hover:shadow-blue-500/10 dark:border-zinc-800/90 dark:bg-zinc-900/70 dark:hover:border-blue-500/40 cursor-pointer"
              >
                <div
                  className="mb-3 h-1.5 w-8 rounded-full transition-all duration-300 group-hover:w-16"
                  style={{ backgroundColor: exp.previewAccent }}
                />
                <span className="text-[11px] font-mono text-stone-500 dark:text-zinc-400">
                  {exp.type[locale]}
                </span>
                <h3 className="mt-1 text-sm font-bold text-stone-900 group-hover:text-blue-600 dark:text-zinc-100 dark:group-hover:text-blue-400 transition-colors">
                  {exp.title[locale]}
                </h3>
                <p className="mt-2 text-xs text-stone-600 dark:text-zinc-400 line-clamp-3">
                  {exp.description[locale]}
                </p>
                <div className="mt-4 flex flex-wrap gap-1 text-[10px] text-stone-500 font-mono dark:text-zinc-400">
                  {exp.tools.join(' · ')}
                </div>
              </div>
            </AnimatedItem>
          ))}
        </div>
      </AnimatedSection>

      {/* Exploration Detail Modal */}
      {activeExp && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs"
        >
          <div className="relative w-full max-w-lg rounded-2xl bg-white p-6 shadow-2xl border border-stone-200 dark:border-zinc-800 dark:bg-zinc-900">
            <button
              type="button"
              onClick={() => setSelectedExploration(null)}
              className="absolute top-4 right-4 rounded-lg p-1.5 text-stone-400 hover:bg-stone-100 hover:text-stone-700 dark:text-zinc-500 dark:hover:bg-zinc-800 dark:hover:text-zinc-200 cursor-pointer"
            >
              <X className="h-5 w-5" />
            </button>

            <span className="text-xs font-mono text-blue-600 dark:text-blue-400">
              {activeExp.type[locale]}
            </span>
            <h3 className="mt-1 text-lg font-bold text-stone-900 dark:text-white">
              {activeExp.title[locale]}
            </h3>
            <p className="mt-3 text-xs sm:text-sm text-stone-600 dark:text-zinc-300 leading-relaxed">
              {activeExp.description[locale]}
            </p>

            <div className="mt-5 rounded-xl border border-stone-200 bg-stone-50 p-4 dark:border-zinc-800 dark:bg-zinc-800/40">
              <span className="text-xs font-semibold text-stone-800 dark:text-zinc-200 block mb-1">
                Eingesetzte Technologien & Prinzipien:
              </span>
              <div className="flex flex-wrap gap-2 text-xs text-stone-600 dark:text-zinc-400">
                {activeExp.tools.map((tool) => (
                  <span key={tool} className="rounded bg-white px-2 py-0.5 border border-stone-200 dark:border-zinc-700 dark:bg-zinc-800">
                    {tool}
                  </span>
                ))}
              </div>
            </div>

            <div className="mt-6 text-right">
              <button
                type="button"
                onClick={() => setSelectedExploration(null)}
                className="rounded-xl bg-stone-900 px-4 py-2 text-xs font-semibold text-white hover:bg-stone-800 dark:bg-zinc-100 dark:text-zinc-900 dark:hover:bg-white cursor-pointer"
              >
                Schließen
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
