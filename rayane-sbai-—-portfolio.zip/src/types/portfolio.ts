export type Locale = 'de' | 'en' | 'fr';

export type PageType = 'home' | 'projects' | 'case-study' | 'about' | 'contact';

export interface LocalizedString {
  de: string;
  en: string;
  fr: string;
}

export interface DesignDecision {
  title: LocalizedString;
  problem: LocalizedString;
  solution: LocalizedString;
  impact: LocalizedString;
}

export interface ProjectData {
  id: string;
  slug: string;
  title: string;
  clientOrOrg: string;
  category: 'ui-ux' | 'frontend' | 'full-product' | 'design-system';
  categoryLabel: LocalizedString;
  status: 'implemented' | 'live' | 'prototype' | 'concept';
  statusLabel: LocalizedString;
  featured: boolean;
  timeline?: string;
  role: LocalizedString;
  teamContext: LocalizedString;
  summary: LocalizedString;
  overview: LocalizedString;
  audienceAndContext: LocalizedString;
  challenge: LocalizedString;
  constraints: LocalizedString[];
  researchAndObservations?: LocalizedString[];
  userFlowAndArchitecture: LocalizedString;
  designDecisions: DesignDecision[];
  implementationDetails: LocalizedString[];
  resultsAndObservations: LocalizedString[];
  lessonsLearned: LocalizedString;
  nextImprovements: LocalizedString;
  tags: string[];
  image: string;
  mobileImage?: string;
  liveUrl?: string;
  figmaUrl?: string;
  githubUrl?: string;
}

export interface VisualExploration {
  id: string;
  title: LocalizedString;
  type: LocalizedString;
  description: LocalizedString;
  tools: string[];
  previewAccent: string;
}

export interface ExperienceItem {
  period: string;
  role: LocalizedString;
  organization: string;
  location: string;
  type: LocalizedString; // Internship, Diploma, Group Project, etc.
  description: LocalizedString;
  highlights: LocalizedString[];
}

export interface SkillCategory {
  id: string;
  title: LocalizedString;
  description: LocalizedString;
  skills: {
    name: string;
    level?: string;
    note?: LocalizedString;
    featuredInProject?: string;
  }[];
}
